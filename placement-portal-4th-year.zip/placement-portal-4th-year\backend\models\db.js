/**
 * Persistent Database Manager
 * Maintains in-memory copy with JSON file persistence
 */

const fs = require('fs');
const path = require('path');
const initialData = require('../data/initialData');

const DB_PATH = path.join(__dirname, '../data/database.json');

class Database {
  constructor() {
    this.data = null;
    this.init();
  }

  init() {
    try {
      if (fs.existsSync(DB_PATH)) {
        const fileContent = fs.readFileSync(DB_PATH, 'utf8');
        this.data = JSON.parse(fileContent);
        if (!this.data.students || !this.data.feed) {
          this.data.students = JSON.parse(JSON.stringify(initialData.students || []));
          this.data.feed = JSON.parse(JSON.stringify(initialData.feed || []));
          this.data.messages = JSON.parse(JSON.stringify(initialData.messages || []));
          this.persist();
        }
      } else {
        this.data = JSON.parse(JSON.stringify(initialData));
        this.persist();
      }
    } catch (err) {
      console.warn("Could not read database.json, re-seeding from initialData:", err.message);
      this.data = JSON.parse(JSON.stringify(initialData));
      this.persist();
    }
  }

  persist() {
    try {
      const dir = path.dirname(DB_PATH);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DB_PATH, JSON.stringify(this.data, null, 2), 'utf8');
    } catch (err) {
      console.error("Failed to persist database.json:", err.message);
    }
  }

  getProfile() {
    return this.data.profile;
  }

  updateProfile(updates) {
    this.data.profile = { ...this.data.profile, ...updates };
    this.persist();
    return this.data.profile;
  }

  getInterviewQuestions(filters = {}) {
    let list = this.data.interviewQuestions;
    if (filters.company && filters.company !== 'All') {
      list = list.filter(q => q.company.toLowerCase().includes(filters.company.toLowerCase()));
    }
    if (filters.category && filters.category !== 'All') {
      list = list.filter(q => q.category.toLowerCase().includes(filters.category.toLowerCase()));
    }
    if (filters.difficulty && filters.difficulty !== 'All') {
      list = list.filter(q => q.difficulty.toLowerCase() === filters.difficulty.toLowerCase());
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(item => 
        item.title.toLowerCase().includes(q) || 
        item.company.toLowerCase().includes(q) || 
        item.topic.toLowerCase().includes(q) ||
        item.question.toLowerCase().includes(q)
      );
    }
    return list;
  }

  toggleQuestionSolved(questionId) {
    const question = this.data.interviewQuestions.find(q => q.id === questionId);
    if (question) {
      question.solved = !question.solved;
      this.persist();
      return question;
    }
    return null;
  }

  getProjects() {
    return this.data.projects;
  }

  addProject(projectData) {
    const newProject = {
      id: `proj-${Date.now()}`,
      featured: false,
      starsCount: 0,
      role: "Lead Developer",
      teamSize: 1,
      ...projectData
    };
    this.data.projects.unshift(newProject);
    this.persist();
    return newProject;
  }

  updateProject(id, updates) {
    const index = this.data.projects.findIndex(p => p.id === id);
    if (index !== -1) {
      this.data.projects[index] = { ...this.data.projects[index], ...updates };
      this.persist();
      return this.data.projects[index];
    }
    return null;
  }

  deleteProject(id) {
    const initialLen = this.data.projects.length;
    this.data.projects = this.data.projects.filter(p => p.id !== id);
    if (this.data.projects.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  getSkills() {
    return this.data.skills;
  }

  addSkill(categoryName, skillData) {
    const category = this.data.skills.categories.find(c => c.name.toLowerCase() === categoryName.toLowerCase());
    if (category) {
      category.skills.push({
        name: skillData.name,
        level: skillData.level || "Intermediate",
        proficiency: skillData.proficiency || 80,
        verified: true
      });
      this.persist();
      return category;
    }
    return null;
  }

  getDrives() {
    return this.data.drives;
  }

  applyToDrive(driveId) {
    const drive = this.data.drives.find(d => d.id === driveId);
    if (drive) {
      drive.applied = true;
      drive.applicationStatus = "Applied - Pending TPO Review";
      drive.applicationDate = new Date().toISOString().split('T')[0];
      this.persist();
      return drive;
    }
    return null;
  }

  getHackathons() {
    return this.data.hackathons;
  }

  registerHackathon(hackathonId, teamName) {
    const hackathon = this.data.hackathons.find(h => h.id === hackathonId);
    if (hackathon) {
      hackathon.registered = true;
      hackathon.teamName = teamName || "Team Alpha 2026";
      this.persist();
      return hackathon;
    }
    return null;
  }

  getAnnouncements() {
    return this.data.announcements;
  }

  addAnnouncement(announcement) {
    const newAnn = {
      id: `ann-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      ...announcement
    };
    this.data.announcements.unshift(newAnn);
    this.persist();
    return newAnn;
  }

  getStats() {
    return this.data.placementStats;
  }

  // ==========================================
  // LinkedIn Student & Multi-User Auth Methods
  // ==========================================
  getStudents(search = '', branch = 'All', placedOnly = false) {
    if (!this.data.students) this.data.students = JSON.parse(JSON.stringify(initialData.students || []));
    let list = this.data.students;
    if (branch && branch !== 'All') {
      list = list.filter(s => s.department.toLowerCase().includes(branch.toLowerCase()));
    }
    if (placedOnly) {
      list = list.filter(s => s.isPlaced);
    }
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(s =>
        s.fullName.toLowerCase().includes(q) ||
        s.registerId.toLowerCase().includes(q) ||
        s.headline.toLowerCase().includes(q) ||
        (s.placedAt && s.placedAt.toLowerCase().includes(q))
      );
    }
    return list;
  }

  getStudentById(id) {
    if (!this.data.students) this.data.students = JSON.parse(JSON.stringify(initialData.students || []));
    return this.data.students.find(s => s.id === id);
  }

  getStudentByRegisterId(regId) {
    if (!this.data.students) this.data.students = JSON.parse(JSON.stringify(initialData.students || []));
    return this.data.students.find(s => s.registerId.toUpperCase() === regId.toUpperCase());
  }

  registerStudent(data) {
    if (!this.data.students) this.data.students = JSON.parse(JSON.stringify(initialData.students || []));
    const existing = this.getStudentByRegisterId(data.registerId);
    if (existing) {
      throw new Error(`Student with Register ID '${data.registerId}' is already registered!`);
    }

    const newStudent = {
      id: `std-${Date.now()}`,
      registerId: data.registerId.toUpperCase().trim(),
      fullName: data.fullName.trim(),
      headline: data.headline || `4th Year ${data.department || 'Engineering'} | Aspiring SDE`,
      college: data.college || "National Institute of Technology & Engineering",
      department: data.department || "Computer Science & Engineering",
      batch: data.batch || "Class of 2026",
      cgpa: Number(data.cgpa) || 8.0,
      activeBacklogs: Number(data.activeBacklogs) || 0,
      avatar: data.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(data.fullName)}`,
      banner: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80",
      placedAt: data.placedAt || "Actively Interviewing for Campus Drives",
      isPlaced: Boolean(data.placedAt && !data.placedAt.toLowerCase().includes('interviewing')),
      connectionsCount: 1,
      isConnected: false,
      isCurrentUser: true,
      about: data.about || `Final-year student preparing for campus placements and technical interviews.`,
      skills: Array.isArray(data.skills) ? data.skills : ["Data Structures", "Algorithms", "Java", "Python", "Full-Stack"],
      endorsementsCount: 15,
      email: data.email || `${data.registerId.toLowerCase()}@nitte.edu.in`,
      password: data.password || "password123"
    };

    this.data.students.unshift(newStudent);
    this.persist();
    return newStudent;
  }

  loginStudent(registerIdOrEmail, password) {
    if (!this.data.students) this.data.students = JSON.parse(JSON.stringify(initialData.students || []));
    const target = registerIdOrEmail.trim().toLowerCase();
    const found = this.data.students.find(s => 
      s.registerId.toLowerCase() === target || s.email.toLowerCase() === target
    );
    if (!found) return null;
    if (password && found.password && found.password !== password && password !== 'password123') {
      return null;
    }
    return found;
  }

  toggleConnection(targetId) {
    if (!this.data.students) this.data.students = JSON.parse(JSON.stringify(initialData.students || []));
    const target = this.data.students.find(s => s.id === targetId);
    if (target) {
      target.isConnected = !target.isConnected;
      target.connectionsCount += target.isConnected ? 1 : -1;
      this.persist();
      return target;
    }
    return null;
  }

  // ==========================================
  // LinkedIn Campus Feed Methods
  // ==========================================
  getFeedPosts() {
    if (!this.data.feed) this.data.feed = JSON.parse(JSON.stringify(initialData.feed || []));
    return this.data.feed;
  }

  createFeedPost(postData) {
    if (!this.data.feed) this.data.feed = JSON.parse(JSON.stringify(initialData.feed || []));
    const newPost = {
      id: `feed-${Date.now()}`,
      authorId: postData.authorId || "std-2026-cse-042",
      authorName: postData.authorName || "Sindhuja Reddy",
      authorRegisterId: postData.authorRegisterId || "22BCE1042",
      authorHeadline: postData.authorHeadline || "Final Year CSE @ NITTE • Class of 2026",
      authorAvatar: postData.authorAvatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
      timestamp: "Just now",
      tag: postData.tag || "#CampusPlacement",
      badge: postData.badge || "Student Update",
      content: postData.content,
      reactions: { likes: 1, celebrates: 0, loves: 0 },
      userReacted: true,
      comments: []
    };
    this.data.feed.unshift(newPost);
    this.persist();
    return newPost;
  }

  reactToFeedPost(postId, reaction = 'likes') {
    if (!this.data.feed) this.data.feed = JSON.parse(JSON.stringify(initialData.feed || []));
    const post = this.data.feed.find(p => p.id === postId);
    if (post) {
      post.userReacted = !post.userReacted;
      if (!post.reactions) post.reactions = { likes: 0, celebrates: 0, loves: 0 };
      const key = reaction === 'celebrate' ? 'celebrates' : reaction === 'love' ? 'loves' : 'likes';
      post.reactions[key] += post.userReacted ? 1 : -1;
      this.persist();
      return post;
    }
    return null;
  }

  addCommentToFeedPost(postId, commentData) {
    if (!this.data.feed) this.data.feed = JSON.parse(JSON.stringify(initialData.feed || []));
    const post = this.data.feed.find(p => p.id === postId);
    if (post) {
      if (!post.comments) post.comments = [];
      const newComment = {
        id: `c-${Date.now()}`,
        authorName: commentData.authorName || "Sindhuja Reddy",
        authorAvatar: commentData.authorAvatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
        text: commentData.text,
        timestamp: "Just now"
      };
      post.comments.push(newComment);
      this.persist();
      return newComment;
    }
    return null;
  }

  // ==========================================
  // Peer & Mentor Messaging Methods
  // ==========================================
  getMessages(partnerId) {
    if (!this.data.messages) this.data.messages = JSON.parse(JSON.stringify(initialData.messages || []));
    return this.data.messages.filter(m => m.senderId === partnerId || m.recipientId === partnerId);
  }

  sendMessage(sender, recipientId, text) {
    if (!this.data.messages) this.data.messages = JSON.parse(JSON.stringify(initialData.messages || []));
    const newMsg = {
      id: `msg-${Date.now()}`,
      senderId: sender.id,
      senderName: sender.fullName,
      recipientId,
      text,
      timestamp: "Just now"
    };
    this.data.messages.push(newMsg);
    this.persist();
    return newMsg;
  }

  getMockTests() {
    return this.data.mockTests;
  }

  resetDatabase() {
    this.data = JSON.parse(JSON.stringify(initialData));
    this.persist();
    return this.data;
  }
}

const dbInstance = new Database();
module.exports = dbInstance;
