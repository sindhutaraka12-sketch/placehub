/**
 * PlaceHub - 4th Year Student Placement & Career Launch Server
 * Zero-Dependency High-Performance HTTP REST API + Static File Server
 * Works out-of-the-box on any Node.js installation (no npm install required!)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const db = require('./models/db');

const PORT = process.env.PORT || 5000;
const PUBLIC_DIR = path.join(__dirname, '../frontend/public');

// MIME types dictionary
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

// Helper to evaluate student eligibility against a drive
function evaluateEligibility(student, drive) {
  const cgpaOk = student.cgpa >= drive.eligibility.minCgpa;
  const backlogsOk = student.activeBacklogs <= drive.eligibility.allowedBacklogs;
  const tenthOk = !drive.eligibility.min10th || student.tenthPercentage >= drive.eligibility.min10th;
  const twelfthOk = !drive.eligibility.min12th || student.twelfthPercentage >= drive.eligibility.min12th;
  
  const branchOk = drive.eligibility.eligibleBranches.some(b => 
    b.toLowerCase().includes("all") || 
    student.department.toLowerCase().includes(b.toLowerCase()) ||
    (b === "CSE" && student.department.includes("Computer Science")) ||
    (b === "IT" && student.department.includes("Information")) ||
    (b === "ECE" && student.department.includes("Electronics"))
  );

  const isEligible = cgpaOk && backlogsOk && branchOk && tenthOk && twelfthOk;
  const reasons = [];
  if (!cgpaOk) reasons.push(`Requires minimum CGPA of ${drive.eligibility.minCgpa} (Current: ${student.cgpa})`);
  if (!backlogsOk) reasons.push(`Requires max ${drive.eligibility.allowedBacklogs} active backlogs (Current: ${student.activeBacklogs})`);
  if (!branchOk) reasons.push(`Branch not eligible (Requires: ${drive.eligibility.eligibleBranches.join(', ')})`);
  if (!tenthOk) reasons.push(`10th standard cutoff not met (Req: ${drive.eligibility.min10th}%)`);
  if (!twelfthOk) reasons.push(`12th standard cutoff not met (Req: ${drive.eligibility.min12th}%)`);

  return {
    isEligible,
    reasons: reasons.length ? reasons : ["All academic qualifications and criteria fulfilled!"]
  };
}

// In-memory teammate posts
let teammatePosts = [
  {
    id: "team-post-1",
    studentName: "Aditya Sharma (CSE - 8th Sem)",
    hackathonName: "Smart India Hackathon 2026",
    roleNeeded: "Frontend / React + UI Specialist",
    description: "Building an automated AI water leakage detection system. ML model is trained, looking for React + Mapbox developer.",
    contact: "aditya.sharma@nitte.edu.in",
    date: "2026-11-04"
  },
  {
    id: "team-post-2",
    studentName: "Pooja Hegde (IT - 8th Sem)",
    hackathonName: "Google Solution Challenge 2026",
    roleNeeded: "Cloud & Firebase / Backend Developer",
    description: "Designing an accessible voice-guided shopping assistant for visually impaired users. Need 1 backend engineer.",
    contact: "pooja.h@nitte.edu.in",
    date: "2026-11-03"
  }
];

// JSON response helper
function sendJSON(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

// Parse request body
function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        resolve({});
      }
    });
  });
}

// Main HTTP Server
const server = http.createServer(async (req, res) => {
  // Handle CORS Pre-flight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    return res.end();
  }

  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const query = parsedUrl.query;
  const method = req.method;

  // Log incoming API calls
  if (pathname.startsWith('/api')) {
    console.log(`[${new Date().toISOString().split('T')[1].slice(0, 8)}] ${method} ${pathname}`);
  }

  // ==========================================
  // API ROUTING
  // ==========================================
  try {
    // 0. LinkedIn Student Auth Routes
    if (pathname === '/api/auth/register' && method === 'POST') {
      const body = await parseBody(req);
      if (!body.registerId || !body.fullName) {
        return sendJSON(res, 400, { success: false, error: "Student Register ID (USN/Roll No) and Full Name are required." });
      }
      try {
        const student = db.registerStudent(body);
        return sendJSON(res, 201, { success: true, data: student, message: "Student account successfully registered with University ID!" });
      } catch (e) {
        return sendJSON(res, 400, { success: false, error: e.message });
      }
    }

    if (pathname === '/api/auth/login' && method === 'POST') {
      const body = await parseBody(req);
      if (!body.registerId) {
        return sendJSON(res, 400, { success: false, error: "Please enter your Student Register ID (e.g. 22BCE1042)." });
      }
      const student = db.loginStudent(body.registerId, body.password);
      if (!student) {
        return sendJSON(res, 401, { success: false, error: "Invalid Student Register ID or Password." });
      }
      return sendJSON(res, 200, { success: true, data: student, message: `Welcome back, ${student.fullName}!` });
    }

    // 0.1 LinkedIn Student Network & Directory
    if (pathname === '/api/students' && method === 'GET') {
      const students = db.getStudents(query.search, query.branch, query.placed === 'true');
      return sendJSON(res, 200, { success: true, data: students });
    }

    if (pathname.startsWith('/api/students/') && pathname.endsWith('/connect') && method === 'POST') {
      const targetId = pathname.replace('/api/students/', '').replace('/connect', '');
      const student = db.toggleConnection(targetId);
      if (!student) return sendJSON(res, 404, { success: false, error: "Student not found" });
      return sendJSON(res, 200, {
        success: true,
        data: student,
        message: student.isConnected ? `Connected with ${student.fullName}!` : `Disconnected from ${student.fullName}`
      });
    }

    // 0.2 LinkedIn Campus Feed Routes
    if (pathname === '/api/feed' && method === 'GET') {
      return sendJSON(res, 200, { success: true, data: db.getFeedPosts() });
    }

    if (pathname === '/api/feed' && method === 'POST') {
      const body = await parseBody(req);
      if (!body.content) {
        return sendJSON(res, 400, { success: false, error: "Post content cannot be empty." });
      }
      const post = db.createFeedPost(body);
      return sendJSON(res, 201, { success: true, data: post, message: "Post shared with campus network!" });
    }

    if (pathname.startsWith('/api/feed/') && pathname.endsWith('/react') && method === 'POST') {
      const pId = pathname.replace('/api/feed/', '').replace('/react', '');
      const body = await parseBody(req);
      const post = db.reactToFeedPost(pId, body.reaction || 'likes');
      if (!post) return sendJSON(res, 404, { success: false, error: "Post not found" });
      return sendJSON(res, 200, { success: true, data: post });
    }

    if (pathname.startsWith('/api/feed/') && pathname.endsWith('/comment') && method === 'POST') {
      const pId = pathname.replace('/api/feed/', '').replace('/comment', '');
      const body = await parseBody(req);
      if (!body.text) return sendJSON(res, 400, { success: false, error: "Comment text required." });
      const comment = db.addCommentToFeedPost(pId, body);
      if (!comment) return sendJSON(res, 404, { success: false, error: "Post not found" });
      return sendJSON(res, 201, { success: true, data: comment });
    }

    // 0.3 Direct Messaging Routes
    if (pathname.startsWith('/api/messages/') && method === 'GET') {
      const partnerId = pathname.replace('/api/messages/', '');
      return sendJSON(res, 200, { success: true, data: db.getMessages(partnerId) });
    }

    if (pathname.startsWith('/api/messages/') && method === 'POST') {
      const partnerId = pathname.replace('/api/messages/', '');
      const body = await parseBody(req);
      const msg = db.sendMessage(body.sender || { id: "std-2026-cse-042", fullName: "Sindhuja Reddy" }, partnerId, body.text);
      return sendJSON(res, 201, { success: true, data: msg });
    }

    // 1. Profile Routes
    if (pathname === '/api/profile' && method === 'GET') {
      const profile = db.getProfile();
      const projects = db.getProjects();
      const questions = db.getInterviewQuestions();
      const drives = db.getDrives();
      const totalSolved = questions.filter(q => q.solved).length;
      const appliedDrives = drives.filter(d => d.applied).length;
      const eligibleDrives = drives.filter(d => evaluateEligibility(profile, d).isEligible).length;

      return sendJSON(res, 200, {
        success: true,
        data: {
          ...profile,
          metricsSummary: {
            totalSolvedQuestions: totalSolved,
            totalProjects: projects.length,
            appliedDrivesCount: appliedDrives,
            eligibleDrivesCount: eligibleDrives,
            readinessScore: 94
          }
        }
      });
    }

    if (pathname === '/api/profile' && method === 'PUT') {
      const body = await parseBody(req);
      const updated = db.updateProfile(body);
      return sendJSON(res, 200, { success: true, data: updated, message: "Profile updated successfully." });
    }

    if (pathname === '/api/profile/calculate-ats' && method === 'POST') {
      const body = await parseBody(req);
      const profile = db.getProfile();
      const projects = db.getProjects();
      const skillsData = db.getSkills();

      let score = 70;
      const feedback = [];
      const hasMetrics = projects.some(p => p.metrics && /\d+%|\d+x|\d+ms/i.test(p.metrics));
      if (hasMetrics) {
        score += 10;
        feedback.push({ type: "positive", message: "Quantifiable project metrics detected (percentages, latency, throughput)." });
      } else {
        feedback.push({ type: "warning", message: "Add quantifiable impact (e.g. 'Reduced latency by 40%') to projects." });
      }

      const hasCoreCS = skillsData.categories.some(c => c.name.includes("Core CS") && c.skills.length >= 4);
      if (hasCoreCS) {
        score += 8;
        feedback.push({ type: "positive", message: "Essential CS fundamentals (OS, DBMS, Networks, OOP) verified." });
      }

      if (profile.leetcodeUrl && profile.githubUrl && profile.linkedinUrl) {
        score += 7;
        feedback.push({ type: "positive", message: "All essential recruiter links verified (LeetCode, GitHub, LinkedIn)." });
      }

      score = Math.min(score, 98);
      db.updateProfile({ atsScore: score, atsFeedback: feedback });

      return sendJSON(res, 200, {
        success: true,
        score,
        feedback,
        targetCompany: body.targetCompany || "Amazon SDE-1"
      });
    }

    if (pathname === '/api/profile/portfolio' && method === 'GET') {
      const profile = db.getProfile();
      const projects = db.getProjects();
      const skills = db.getSkills();
      return sendJSON(res, 200, {
        success: true,
        data: {
          student: {
            fullName: profile.fullName,
            degree: profile.degree,
            college: profile.college,
            cgpa: profile.cgpa,
            bio: profile.bio,
            avatar: profile.avatar,
            links: {
              portfolio: profile.portfolioUrl,
              github: profile.githubUrl,
              linkedin: profile.linkedinUrl,
              leetcode: profile.leetcodeUrl
            }
          },
          featuredProjects: projects.filter(p => p.featured),
          allProjects: projects,
          skillsMatrix: skills.categories,
          certifications: profile.certifications,
          academicHistory: profile.semesters
        }
      });
    }

    // 2. Interview Questions Routes
    if (pathname === '/api/questions' && method === 'GET') {
      const questions = db.getInterviewQuestions({
        company: query.company,
        category: query.category,
        difficulty: query.difficulty,
        search: query.search
      });
      const total = questions.length;
      const solvedCount = questions.filter(q => q.solved).length;
      return sendJSON(res, 200, {
        success: true,
        data: questions,
        meta: {
          total,
          solvedCount,
          progressPercentage: total > 0 ? Math.round((solvedCount / total) * 100) : 0
        }
      });
    }

    if (pathname === '/api/questions/meta/filters' && method === 'GET') {
      const all = db.getInterviewQuestions();
      const companies = [...new Set(all.map(q => q.company))];
      const categories = [...new Set(all.map(q => q.category))];
      const topics = [...new Set(all.map(q => q.topic))];
      return sendJSON(res, 200, {
        success: true,
        companies,
        categories,
        topics
      });
    }

    if (pathname.startsWith('/api/questions/') && pathname.endsWith('/toggle-solve') && method === 'POST') {
      const qId = pathname.replace('/api/questions/', '').replace('/toggle-solve', '');
      const question = db.toggleQuestionSolved(qId);
      if (!question) return sendJSON(res, 404, { success: false, error: "Question not found" });
      return sendJSON(res, 200, {
        success: true,
        data: question,
        message: question.solved ? "Marked as Mastered!" : "Marked as Unsolved"
      });
    }

    // 3. Placement Drives & Qualifications
    if (pathname === '/api/drives/eligibility-matrix' && method === 'GET') {
      const student = db.getProfile();
      const drives = db.getDrives();
      const matrix = drives.map(drive => {
        const evalResult = evaluateEligibility(student, drive);
        return {
          driveId: drive.id,
          company: drive.company,
          role: drive.role,
          ctc: drive.ctcPackage,
          criteria: {
            minCgpa: drive.eligibility.minCgpa,
            studentCgpa: student.cgpa,
            cgpaPassed: student.cgpa >= drive.eligibility.minCgpa,
            allowedBacklogs: drive.eligibility.allowedBacklogs,
            studentBacklogs: student.activeBacklogs,
            backlogsPassed: student.activeBacklogs <= drive.eligibility.allowedBacklogs,
            branches: drive.eligibility.eligibleBranches
          },
          isEligible: evalResult.isEligible,
          reasons: evalResult.reasons,
          applied: drive.applied,
          applicationStatus: drive.applicationStatus
        };
      });

      return sendJSON(res, 200, {
        success: true,
        studentOverview: {
          name: student.fullName,
          cgpa: student.cgpa,
          department: student.department,
          backlogs: student.activeBacklogs,
          tenth: student.tenthPercentage,
          twelfth: student.twelfthPercentage
        },
        matrix
      });
    }

    if (pathname === '/api/drives' && method === 'GET') {
      const student = db.getProfile();
      const drives = db.getDrives();
      const categoryFilter = query.category;
      let filtered = drives;
      if (categoryFilter && categoryFilter !== 'All') {
        filtered = filtered.filter(d => d.category.toLowerCase().includes(categoryFilter.toLowerCase()));
      }
      const enhanced = filtered.map(drive => ({
        ...drive,
        qualificationStatus: evaluateEligibility(student, drive)
      }));

      return sendJSON(res, 200, {
        success: true,
        data: enhanced,
        summary: {
          totalDrives: drives.length,
          eligibleCount: drives.filter(d => evaluateEligibility(student, d).isEligible).length,
          appliedCount: drives.filter(d => d.applied).length
        }
      });
    }

    if (pathname.startsWith('/api/drives/') && pathname.endsWith('/apply') && method === 'POST') {
      const driveId = pathname.replace('/api/drives/', '').replace('/apply', '');
      const student = db.getProfile();
      const drive = db.getDrives().find(d => d.id === driveId);
      if (!drive) return sendJSON(res, 404, { success: false, error: "Placement drive not found" });

      const evalResult = evaluateEligibility(student, drive);
      if (!evalResult.isEligible) {
        return sendJSON(res, 400, {
          success: false,
          error: "Eligibility criteria not met for this drive.",
          details: evalResult.reasons
        });
      }

      const appliedDrive = db.applyToDrive(driveId);
      return sendJSON(res, 200, {
        success: true,
        data: appliedDrive,
        message: `Successfully applied to ${drive.company} (${drive.role})!`
      });
    }

    if (pathname === '/api/drives' && method === 'POST') {
      const body = await parseBody(req);
      const newDrive = {
        id: `drv-${Date.now()}`,
        company: body.company,
        role: body.role,
        logo: "https://upload.wikimedia.org/wikipedia/commons/a/ac/Default_pfp.svg",
        ctcPackage: body.ctcPackage,
        stipend: body.stipend || "Competitive Stipend",
        type: "Full-Time Offer",
        category: "Dream Tier (₹10 - ₹25 LPA)",
        location: "Bengaluru / Pan India",
        deadline: body.deadline || "2026-12-15",
        driveDate: "2026-12-20",
        status: "Open - Applications Live",
        eligibility: {
          minCgpa: Number(body.minCgpa) || 7.0,
          allowedBacklogs: 0,
          eligibleBranches: body.eligibleBranches ? body.eligibleBranches.split(',').map(b => b.trim()) : ["CSE", "IT", "ECE"],
          min10th: 60.0,
          min12th: 60.0
        },
        selectionProcess: [
          { round: "Round 1", name: "Online Aptitude & Code Test", duration: "90 Mins", format: "MCQs + Coding" },
          { round: "Round 2", name: "Technical Interview", duration: "45 Mins", format: "Core CS & DSA" }
        ],
        description: body.description || "Exciting engineering role at tier-1 campus recruiter.",
        requirements: ["Strong problem solving abilities and foundational CS skills."],
        applied: false,
        applicationStatus: "Not Applied",
        applicationDate: null
      };
      db.data.drives.unshift(newDrive);
      db.persist();
      return sendJSON(res, 201, { success: true, data: newDrive, message: `Campus drive for ${body.company} published!` });
    }

    // 4. Projects Showcase
    if (pathname === '/api/projects' && method === 'GET') {
      return sendJSON(res, 200, { success: true, data: db.getProjects() });
    }

    if (pathname === '/api/projects' && method === 'POST') {
      const body = await parseBody(req);
      const techArray = Array.isArray(body.technologies) 
        ? body.technologies 
        : (body.technologies || '').split(',').map(t => t.trim()).filter(Boolean);

      const created = db.addProject({
        title: body.title,
        category: body.category || "Final Year Project",
        tagline: body.tagline || "Built scalable technical solution.",
        technologies: techArray,
        solution: body.solution || "Architected distributed system with microservices.",
        metrics: body.metrics || "Optimized response time by 40%.",
        githubUrl: body.githubUrl || "",
        liveDemoUrl: body.liveDemoUrl || "",
        featured: Boolean(body.featured)
      });
      return sendJSON(res, 201, { success: true, data: created, message: "Project added to your portfolio showcase!" });
    }

    if (pathname.startsWith('/api/projects/') && pathname.endsWith('/toggle-featured') && method === 'POST') {
      const pId = pathname.replace('/api/projects/', '').replace('/toggle-featured', '');
      const project = db.getProjects().find(p => p.id === pId);
      if (!project) return sendJSON(res, 404, { success: false, error: "Project not found" });
      project.featured = !project.featured;
      db.persist();
      return sendJSON(res, 200, {
        success: true,
        data: project,
        message: project.featured ? "Pinned to Resume & Featured Portfolio" : "Unpinned from Featured"
      });
    }

    if (pathname.startsWith('/api/projects/') && method === 'DELETE') {
      const pId = pathname.replace('/api/projects/', '');
      const deleted = db.deleteProject(pId);
      if (!deleted) return sendJSON(res, 404, { success: false, error: "Project not found" });
      return sendJSON(res, 200, { success: true, message: "Project deleted from portfolio." });
    }

    // 5. Skills & Benchmarks
    if (pathname === '/api/skills' && method === 'GET') {
      return sendJSON(res, 200, { success: true, data: db.getSkills() });
    }

    if (pathname === '/api/skills/gap-analysis' && method === 'GET') {
      const company = query.company || "Google";
      const skills = db.getSkills();
      const benchmark = skills.dreamCompanyBenchmarks[company] || {
        match: 88,
        missing: ["Distributed Spanner internals", "High-throughput messaging"]
      };
      return sendJSON(res, 200, {
        success: true,
        targetCompany: company,
        matchPercentage: benchmark.match,
        missingSkills: benchmark.missing,
        recommendations: [
          `Complete 5 Hard problems on ${benchmark.missing[0] || 'System Design'}.`,
          `Review past interview experiences for ${company} in the Interview Questions tab.`,
          `Take the timed Mock Assessment to test OA readiness.`
        ]
      });
    }

    // 6. Hackathons & Teammates
    if (pathname === '/api/hackathons' && method === 'GET') {
      return sendJSON(res, 200, {
        success: true,
        data: db.getHackathons(),
        teammateBoard: teammatePosts
      });
    }

    if (pathname.startsWith('/api/hackathons/') && pathname.endsWith('/register') && method === 'POST') {
      const hId = pathname.replace('/api/hackathons/', '').replace('/register', '');
      const body = await parseBody(req);
      const hackathon = db.registerHackathon(hId, body.teamName);
      if (!hackathon) return sendJSON(res, 404, { success: false, error: "Hackathon not found" });
      return sendJSON(res, 200, {
        success: true,
        data: hackathon,
        message: `Team '${hackathon.teamName}' registered for ${hackathon.name}!`
      });
    }

    if (pathname === '/api/hackathons/find-teammates' && method === 'POST') {
      const body = await parseBody(req);
      const student = db.getProfile();
      const newPost = {
        id: `team-post-${Date.now()}`,
        studentName: `${student.fullName} (${student.department.split(' ')[0]} - 8th Sem)`,
        hackathonName: body.hackathonName || "Smart India Hackathon 2026",
        roleNeeded: body.roleNeeded || "Full-Stack Developer",
        description: body.description || "Looking for committed teammate to build hackathon prototype.",
        contact: body.contact || student.email,
        date: new Date().toISOString().split('T')[0]
      };
      teammatePosts.unshift(newPost);
      return sendJSON(res, 201, { success: true, data: newPost, message: "Teammate request published on campus board!" });
    }

    // 7. Applications Pipeline
    if (pathname === '/api/applications' && method === 'GET') {
      const drives = db.getDrives();
      const applied = drives.filter(d => d.applied);
      const stages = [
        { id: "applied", name: "Applied / Review", count: 0, drives: [] },
        { id: "oa", name: "OA Scheduled", count: 0, drives: [] },
        { id: "interview", name: "Technical Interview", count: 0, drives: [] },
        { id: "hr", name: "HR / Bar Raiser", count: 0, drives: [] },
        { id: "offered", name: "Offer Extended", count: 0, drives: [] }
      ];

      applied.forEach(drive => {
        const s = (drive.applicationStatus || '').toLowerCase();
        if (s.includes("offer") || s.includes("selected") || s.includes("placed")) {
          stages[4].count++; stages[4].drives.push(drive);
        } else if (s.includes("bar raiser") || s.includes("managerial") || s.includes("hr")) {
          stages[3].count++; stages[3].drives.push(drive);
        } else if (s.includes("technical") || s.includes("cleared")) {
          stages[2].count++; stages[2].drives.push(drive);
        } else if (s.includes("shortlisted") || s.includes("oa") || s.includes("assessment")) {
          stages[1].count++; stages[1].drives.push(drive);
        } else {
          stages[0].count++; stages[0].drives.push(drive);
        }
      });

      return sendJSON(res, 200, {
        success: true,
        totalApplied: applied.length,
        pipeline: stages,
        rawList: applied
      });
    }

    // 8. Announcements
    if (pathname === '/api/announcements' && method === 'GET') {
      return sendJSON(res, 200, { success: true, data: db.getAnnouncements() });
    }

    // 9. Stats
    if (pathname === '/api/stats' && method === 'GET') {
      return sendJSON(res, 200, { success: true, data: db.getStats() });
    }

    // 10. Mock Placement Tests
    if (pathname === '/api/mock-tests' && method === 'GET') {
      const tests = db.getMockTests().map(t => ({
        id: t.id,
        title: t.title,
        durationMins: t.durationMins,
        totalQuestions: t.questions.length,
        category: t.category,
        targetCompanies: t.targetCompanies
      }));
      return sendJSON(res, 200, { success: true, data: tests });
    }

    if (pathname.startsWith('/api/mock-tests/') && method === 'GET') {
      const tId = pathname.replace('/api/mock-tests/', '');
      const test = db.getMockTests().find(t => t.id === tId);
      if (!test) return sendJSON(res, 404, { success: false, error: "Mock test not found" });

      const sanitizedQuestions = test.questions.map(q => ({
        id: q.id,
        question: q.question,
        options: q.options
      }));
      return sendJSON(res, 200, {
        success: true,
        data: {
          id: test.id,
          title: test.title,
          durationMins: test.durationMins,
          totalQuestions: test.questions.length,
          category: test.category,
          questions: sanitizedQuestions
        }
      });
    }

    if (pathname.startsWith('/api/mock-tests/') && pathname.endsWith('/submit') && method === 'POST') {
      const tId = pathname.replace('/api/mock-tests/', '').replace('/submit', '');
      const test = db.getMockTests().find(t => t.id === tId);
      if (!test) return sendJSON(res, 404, { success: false, error: "Mock test not found" });

      const body = await parseBody(req);
      const userAnswers = body.userAnswers || {};
      let correctCount = 0;

      const review = test.questions.map(q => {
        const selected = userAnswers[q.id];
        const hasAnswered = selected !== undefined && selected !== null && selected !== '';
        const isCorrect = hasAnswered && Number(selected) === Number(q.correctIndex);
        if (isCorrect) correctCount++;
        return {
          id: q.id,
          question: q.question,
          options: q.options,
          userSelected: hasAnswered ? Number(selected) : null,
          correctIndex: q.correctIndex,
          isCorrect,
          explanation: q.explanation || "Review relevant concepts in the preparation modules."
        };
      });

      const percentage = Math.round((correctCount / test.questions.length) * 100);
      return sendJSON(res, 200, {
        success: true,
        score: {
          total: test.questions.length,
          correct: correctCount,
          percentage,
          passed: percentage >= 60,
          performanceBadge: percentage >= 80 ? "Exemplary (Day 1 Ready)" : percentage >= 60 ? "Proficient" : "Needs Practice"
        },
        review
      });
    }

    // Health & Reset
    if (pathname === '/api/health') {
      return sendJSON(res, 200, {
        status: 'online',
        version: '1.0.0',
        platform: 'PlaceHub 4th Year Placement Platform',
        timestamp: new Date().toISOString()
      });
    }

    if (pathname === '/api/reset' && method === 'POST') {
      const fresh = db.resetDatabase();
      return sendJSON(res, 200, {
        success: true,
        message: 'Database reset to initial 4th-year state successfully.',
        data: fresh
      });
    }

  } catch (err) {
    console.error("API Error:", err);
    return sendJSON(res, 500, { success: false, error: err.message });
  }

  // ==========================================
  // STATIC FILE SERVING
  // ==========================================
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html for Single Page Application routing
      filePath = path.join(PUBLIC_DIR, 'index.html');
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        return res.end('Server File Error');
      }
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    });
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('======================================================');
  console.log(`🚀 PlaceHub 4th Year Placement Platform is live!`);
  console.log(`   URL: http://localhost:${PORT}`);
  console.log(`📡 REST API available at http://localhost:${PORT}/api/`);
  console.log(`✨ Zero External Dependencies Required! Ready to run anywhere.`);
  console.log('======================================================');
});
