/**
 * PlaceHub - Main Application Controller
 * Interactive logic for all 4th-year placement platform features
 */

const state = {
  role: 'student', // 'student' or 'tpo'
  profile: null,
  currentStudent: null, // Logged in student with Student Register ID
  activeTab: 'dashboard',
  drives: [],
  questions: [],
  projects: [],
  skills: null,
  hackathons: [],
  announcements: [],
  stats: null,
  feed: [],
  networkStudents: [],
  activeChatPartner: { id: "std-2026-cse-089", fullName: "Rahul Verma (Amazon)" },
  activeTest: null,
  testTimer: null,
  testRemainingSeconds: 0,
  testUserAnswers: {}
};

// ==========================================
// Toast Notifications
// ==========================================
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  let icon = 'info-circle';
  if (type === 'success') icon = 'check-circle';
  if (type === 'error') icon = 'exclamation-circle';

  toast.innerHTML = `
    <i class="fas fa-${icon}"></i>
    <span>${message}</span>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ==========================================
// Initialization
// ==========================================
document.addEventListener('DOMContentLoaded', async () => {
  setupNavigation();
  setupRoleSwitcher();
  setupModals();
  await loadInitialData();
});

async function loadInitialData() {
  try {
    await Promise.all([
      loadProfile(),
      loadAnnouncements(),
      loadStats(),
      loadDashboardOverview()
    ]);
  } catch (err) {
    console.error("Initialization error:", err);
    showToast("Could not load initial placement data: " + err.message, "error");
  }
}

// ==========================================
// Navigation & Tab Switching
// ==========================================
function setupNavigation() {
  const navLinks = document.querySelectorAll('.sidebar-nav .nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetTab = link.getAttribute('data-tab');
      switchTab(targetTab);
    });
  });
}

function switchTab(tabId) {
  state.activeTab = tabId;

  // Update nav links
  document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
    link.classList.toggle('active', link.getAttribute('data-tab') === tabId);
  });

  // Update tab contents
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.toggle('active', content.id === `tab-${tabId}`);
  });

  // Lazy load tab data
  if (tabId === 'dashboard') loadDashboardOverview();
  if (tabId === 'feed') loadFeedTab();
  if (tabId === 'network') loadNetworkTab();
  if (tabId === 'questions') loadQuestionsTab();
  if (tabId === 'qualifications') loadQualificationsTab();
  if (tabId === 'drives') loadDrivesTab();
  if (tabId === 'projects') loadProjectsTab();
  if (tabId === 'skills') loadSkillsTab();
  if (tabId === 'hackathons') loadHackathonsTab();
  if (tabId === 'profile') loadProfileTab();
  if (tabId === 'mock-tests') loadMockTestsTab();
  if (tabId === 'tpo-admin') loadTpoAdminTab();

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ==========================================
// Role Switcher (Student <-> TPO Admin)
// ==========================================
function setupRoleSwitcher() {
  const studentBtn = document.getElementById('role-student-btn');
  const tpoBtn = document.getElementById('role-tpo-btn');

  if (studentBtn && tpoBtn) {
    studentBtn.addEventListener('click', () => {
      state.role = 'student';
      studentBtn.classList.add('active');
      tpoBtn.classList.remove('active');
      document.body.classList.remove('tpo-mode');
      showToast("Switched to 4th Year Student View (Sindhuja Reddy)", "info");
      switchTab('dashboard');
    });

    tpoBtn.addEventListener('click', () => {
      state.role = 'tpo';
      tpoBtn.classList.add('active');
      studentBtn.classList.remove('active');
      document.body.classList.add('tpo-mode');
      showToast("Switched to Placement Officer (TPO) Admin View", "info");
      switchTab('tpo-admin');
    });
  }
}

// ==========================================
// Profile & Sidebar Updates
// ==========================================
async function loadProfile() {
  const res = await api.getProfile();
  if (res.success) {
    state.profile = res.data;
    renderSidebarProfile(res.data);
  }
}

function renderSidebarProfile(profile) {
  const nameEl = document.getElementById('sidebar-student-name');
  const detailsEl = document.getElementById('sidebar-student-details');
  const avatarEl = document.getElementById('sidebar-student-avatar');
  const regIdSidebar = document.getElementById('sidebar-student-regid');
  const regIdNav = document.getElementById('nav-regid-label');
  const feedAvatar = document.getElementById('feed-user-avatar');

  const regId = profile.rollNumber || profile.registerId || '22BCE1042';
  if (nameEl) nameEl.textContent = profile.fullName;
  if (detailsEl) {
    detailsEl.innerHTML = `${profile.department.split(' ')[0]} • CGPA <span>${profile.cgpa}</span>`;
  }
  if (avatarEl && profile.avatar) avatarEl.src = profile.avatar;
  if (feedAvatar && profile.avatar) feedAvatar.src = profile.avatar;
  if (regIdSidebar) regIdSidebar.textContent = regId;
  if (regIdNav) regIdNav.textContent = `ID: ${regId}`;
}

// ==========================================
// Student Identification & Auth Modals
// ==========================================
function openAuthModal() {
  const modal = document.getElementById('modal-student-auth');
  if (modal) modal.classList.add('active');
}

function switchAuthTab(tab) {
  const loginForm = document.getElementById('form-auth-login');
  const regForm = document.getElementById('form-auth-register');
  const loginBtn = document.getElementById('auth-tab-login-btn');
  const regBtn = document.getElementById('auth-tab-reg-btn');

  if (tab === 'login') {
    loginForm.style.display = 'block';
    regForm.style.display = 'none';
    loginBtn.style.borderBottom = '2px solid var(--primary-blue)';
    loginBtn.style.color = '#fff';
    regBtn.style.borderBottom = 'none';
    regBtn.style.color = 'var(--text-muted)';
  } else {
    loginForm.style.display = 'none';
    regForm.style.display = 'block';
    regBtn.style.borderBottom = '2px solid var(--accent-emerald)';
    regBtn.style.color = '#fff';
    loginBtn.style.borderBottom = 'none';
    loginBtn.style.color = 'var(--text-muted)';
  }
}

function fillLoginDemo(regId) {
  const input = document.getElementById('login-input-regid');
  if (input) {
    input.value = regId;
    input.focus();
  }
}

// ==========================================
// LinkedIn Campus Feed
// ==========================================
async function loadFeedTab() {
  const [feedRes, studentsRes] = await Promise.all([
    api.getFeed(),
    api.getStudents({ placed: true })
  ]);

  if (feedRes.success) {
    state.feed = feedRes.data;
    renderFeedPosts(feedRes.data);
  }

  if (studentsRes.success) {
    renderPlacedSpotlight(studentsRes.data.slice(0, 4));
  }
}

function renderFeedPosts(posts) {
  const container = document.getElementById('feed-posts-stream');
  if (!container) return;

  container.innerHTML = posts.map(post => `
    <div class="linkedin-post-card" id="post-${post.id}">
      <div class="post-header">
        <div class="post-author-box">
          <img src="${post.authorAvatar}" class="post-author-avatar" alt="${post.authorName}" />
          <div>
            <div class="post-author-name">
              <span>${post.authorName}</span>
              <span class="register-id-badge"><i class="fas fa-id-card"></i> ${post.authorRegisterId}</span>
              ${post.badge ? `<span class="pill-badge pill-emerald">${post.badge}</span>` : ''}
            </div>
            <div class="post-author-headline">${post.authorHeadline}</div>
            <div class="post-timestamp"><i class="fas fa-clock"></i> ${post.timestamp} • 4th Year Network</div>
          </div>
        </div>
      </div>

      <span class="post-tag-badge">${post.tag}</span>

      <div class="post-content">${escapeHtml(post.content)}</div>

      <div class="post-reactions-bar">
        <div class="reactions-icons-stack">
          <span>👍</span><span>🎉</span><span>💡</span>
          <span>${(post.reactions?.likes || 0) + (post.reactions?.celebrates || 0)} reactions</span>
        </div>
        <div>${(post.comments?.length || 0)} comments</div>
      </div>

      <div class="post-actions-row">
        <button class="post-react-btn ${post.userReacted ? 'active' : ''}" onclick="reactToFeedPost('${post.id}', 'likes')">
          <i class="fas fa-thumbs-up"></i> ${post.userReacted ? 'Liked' : 'Like'}
        </button>
        <button class="post-react-btn" onclick="reactToFeedPost('${post.id}', 'celebrate')">
          <i class="fas fa-hands-clapping"></i> Celebrate
        </button>
        <button class="post-react-btn" onclick="document.getElementById('comment-input-${post.id}').focus()">
          <i class="fas fa-comment"></i> Comment
        </button>
        <button class="post-react-btn" onclick="navigator.clipboard.writeText(window.location.href); showToast('Post link copied to clipboard!', 'info');">
          <i class="fas fa-share"></i> Share
        </button>
      </div>

      <div class="post-comments-box">
        <div class="add-comment-row">
          <input type="text" id="comment-input-${post.id}" class="comment-input" placeholder="Add a congratulatory note or question..." onkeypress="handleCommentKeypress(event, '${post.id}')" />
          <button class="btn btn-sm btn-primary" onclick="submitFeedComment('${post.id}')"><i class="fas fa-paper-plane"></i></button>
        </div>
        <div id="comments-list-${post.id}">
          ${(post.comments || []).map(c => `
            <div class="comment-bubble">
              <div class="comment-bubble-header">
                <strong style="color:#fff;">${c.authorName}</strong>
                <span style="font-size:0.7rem;color:var(--text-muted);">${c.timestamp}</span>
              </div>
              <div style="color:var(--text-main);">${escapeHtml(c.text)}</div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `).join('');
}

function renderPlacedSpotlight(students) {
  const container = document.getElementById('feed-placed-spotlight');
  if (!container) return;

  container.innerHTML = students.map(s => `
    <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg-card-alt);border-radius:var(--radius-md);margin-bottom:8px;border:1px solid var(--border-subtle);">
      <img src="${s.avatar}" style="width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid var(--primary-blue);" />
      <div style="flex:1;min-width:0;">
        <div style="font-size:0.85rem;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${s.fullName}</div>
        <div style="font-size:0.72rem;color:#34d399;font-weight:600;"><i class="fas fa-check-circle"></i> ${s.placedAt}</div>
      </div>
      <button class="btn btn-sm btn-outline" onclick="openStudentChat('${s.id}', '${s.fullName}')" title="Message for Placement Tips">
        <i class="fas fa-comment"></i>
      </button>
    </div>
  `).join('');
}

async function reactToFeedPost(postId, reaction) {
  const res = await api.reactToPost(postId, reaction);
  if (res.success) {
    loadFeedTab();
  }
}

function handleCommentKeypress(e, postId) {
  if (e.key === 'Enter') {
    submitFeedComment(postId);
  }
}

async function submitFeedComment(postId) {
  const input = document.getElementById(`comment-input-${postId}`);
  if (!input || !input.value.trim()) return;

  const currentStudent = state.currentStudent || state.profile;
  const res = await api.commentOnPost(postId, {
    text: input.value.trim(),
    authorName: currentStudent ? currentStudent.fullName : "Sindhuja Reddy",
    authorAvatar: currentStudent ? currentStudent.avatar : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80"
  });

  if (res.success) {
    input.value = '';
    loadFeedTab();
  }
}

function openCreatePostModal(presetTag) {
  const modal = document.getElementById('modal-create-post');
  if (!modal) return;

  const currentStudent = state.currentStudent || state.profile;
  if (currentStudent) {
    document.getElementById('post-author-name-preview').textContent = currentStudent.fullName;
    document.getElementById('post-author-regid-preview').textContent = currentStudent.registerId || currentStudent.rollNumber || '22BCE1042';
    if (currentStudent.avatar) {
      document.getElementById('post-author-avatar-preview').src = currentStudent.avatar;
    }
  }

  if (presetTag) {
    const tagSelect = document.getElementById('post-input-tag');
    if (tagSelect) tagSelect.value = presetTag;
  }

  modal.classList.add('active');
}

// ==========================================
// Student & Alumni Network (LinkedIn Style)
// ==========================================
async function loadNetworkTab() {
  const searchInput = document.getElementById('filter-network-search')?.value || '';
  const branchSelect = document.getElementById('filter-network-branch')?.value || 'All';
  const placedSelect = document.getElementById('filter-network-placed')?.value || 'All';

  const res = await api.getStudents({
    search: searchInput,
    branch: branchSelect,
    placed: placedSelect === 'Placed'
  });

  if (res.success) {
    state.networkStudents = res.data;
    renderNetworkGrid(res.data);
  }

  setupNetworkFilterListeners();
}

function setupNetworkFilterListeners() {
  const searchInput = document.getElementById('filter-network-search');
  const branchSelect = document.getElementById('filter-network-branch');
  const placedSelect = document.getElementById('filter-network-placed');

  const runFilter = () => loadNetworkTab();
  if (branchSelect) branchSelect.onchange = runFilter;
  if (placedSelect) placedSelect.onchange = runFilter;
  if (searchInput) {
    let timeout;
    searchInput.oninput = () => {
      clearTimeout(timeout);
      timeout = setTimeout(runFilter, 300);
    };
  }
}

function renderNetworkGrid(students) {
  const container = document.getElementById('network-cards-container');
  if (!container) return;

  container.innerHTML = students.map(s => `
    <div class="student-network-card" id="student-card-${s.id}">
      <div class="network-cover-banner" style="background-image:url('${s.banner}');"></div>
      <div class="network-avatar-wrap">
        <img src="${s.avatar}" class="network-card-avatar" alt="${s.fullName}" />
      </div>
      <div class="network-card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px;">
          <h4 class="network-student-name">${s.fullName}</h4>
          <span class="register-id-badge"><i class="fas fa-id-card"></i> ${s.registerId}</span>
        </div>
        <div class="network-student-headline">${s.headline}</div>

        <div class="network-placed-badge">
          <i class="fas ${s.isPlaced ? 'fa-award' : 'fa-hourglass-half'}"></i>
          <span>${s.placedAt}</span>
        </div>

        <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:12px;">
          <i class="fas fa-link"></i> ${s.connectionsCount} campus connections • CGPA ${s.cgpa}
        </div>

        <div class="network-actions">
          <button class="btn btn-sm ${s.isConnected ? 'btn-outline' : 'btn-primary'}" style="flex:1;" onclick="toggleConnectWithStudent('${s.id}')">
            <i class="fas ${s.isConnected ? 'fa-check' : 'fa-user-plus'}"></i>
            ${s.isConnected ? 'Connected' : 'Connect'}
          </button>
          <button class="btn btn-sm btn-outline" onclick="openStudentChat('${s.id}', '${s.fullName}')" title="Message">
            <i class="fas fa-comment"></i>
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

async function toggleConnectWithStudent(studentId) {
  const res = await api.toggleConnectStudent(studentId);
  if (res.success) {
    showToast(res.message, "success");
    loadNetworkTab();
  }
}

// ==========================================
// Slide-out Peer Chat Drawer Logic
// ==========================================
let isChatOpen = false;

function toggleChatDrawer() {
  const drawer = document.getElementById('chat-drawer');
  const icon = document.getElementById('chat-drawer-icon');
  if (!drawer) return;

  isChatOpen = !isChatOpen;
  drawer.style.transform = isChatOpen ? 'translateY(0)' : 'translateY(calc(100% - 46px))';
  if (icon) {
    icon.className = isChatOpen ? 'fas fa-chevron-down' : 'fas fa-chevron-up';
  }
}

function openStudentChat(studentId, studentName) {
  const title = document.getElementById('chat-peer-name');
  if (title) title.textContent = studentName;
  const input = document.getElementById('chat-input-text');
  if (input) input.placeholder = `Write a message to ${studentName}...`;

  const drawer = document.getElementById('chat-drawer');
  const icon = document.getElementById('chat-drawer-icon');
  isChatOpen = true;
  if (drawer) drawer.style.transform = 'translateY(0)';
  if (icon) icon.className = 'fas fa-chevron-down';
}

function sendPeerChat(e) {
  e.preventDefault();
  const input = document.getElementById('chat-input-text');
  const container = document.getElementById('chat-messages-container');
  if (!input || !input.value.trim() || !container) return;

  const text = input.value.trim();
  const myBubble = document.createElement('div');
  myBubble.className = 'chat-bubble chat-bubble-me';
  myBubble.innerHTML = `${escapeHtml(text)}<div style="font-size:0.65rem;opacity:0.75;margin-top:4px;">Just now</div>`;
  container.appendChild(myBubble);
  input.value = '';
  container.scrollTop = container.scrollHeight;

  // Simulated peer response
  setTimeout(() => {
    const peerBubble = document.createElement('div');
    peerBubble.className = 'chat-bubble chat-bubble-peer';
    peerBubble.innerHTML = `Thanks for connecting! Absolutely, let's exchange interview questions and do a mock round. I'll share my Google/Amazon prep notes.<div style="font-size:0.65rem;color:var(--text-muted);margin-top:4px;">Just now</div>`;
    container.appendChild(peerBubble);
    container.scrollTop = container.scrollHeight;
  }, 1200);
}

// ==========================================
// Announcements & Top Ticker
// ==========================================
async function loadAnnouncements() {
  const res = await api.getAnnouncements();
  if (res.success && res.data.length > 0) {
    state.announcements = res.data;
    const tickerText = document.getElementById('top-ticker-text');
    if (tickerText) {
      tickerText.textContent = `${res.data[0].title} — ${res.data[0].content.slice(0, 95)}...`;
    }
  }
}

async function loadStats() {
  const res = await api.getPlacementStats();
  if (res.success) {
    state.stats = res.data;
  }
}

// ==========================================
// Tab 1: Dashboard Overview
// ==========================================
async function loadDashboardOverview() {
  const [profileRes, drivesRes, pipeRes] = await Promise.all([
    api.getProfile(),
    api.getDrives(),
    api.getApplicationsPipeline()
  ]);

  if (profileRes.success) {
    state.profile = profileRes.data;
    const p = profileRes.data;

    // Metrics Cards
    const cgpaEl = document.getElementById('dash-cgpa-val');
    const eligibleEl = document.getElementById('dash-eligible-val');
    const appliedEl = document.getElementById('dash-applied-val');
    const readinessEl = document.getElementById('dash-readiness-val');

    if (cgpaEl) cgpaEl.textContent = p.cgpa;
    if (eligibleEl) eligibleEl.textContent = `${p.metricsSummary.eligibleDrivesCount} / ${drivesRes.summary?.totalDrives || 7}`;
    if (appliedEl) appliedEl.textContent = p.metricsSummary.appliedDrivesCount;
    if (readinessEl) readinessEl.textContent = `${p.metricsSummary.readinessScore}%`;
  }

  // Render Application Pipeline
  if (pipeRes.success) {
    renderPipelineTracker(pipeRes.pipeline);
  }

  // Render Recent Urgent Announcements
  renderDashboardAnnouncements();

  // Render Upcoming Drives preview
  if (drivesRes.success) {
    state.drives = drivesRes.data;
    renderDashboardUpcomingDrives(drivesRes.data.slice(0, 3));
  }
}

function renderPipelineTracker(pipeline) {
  const container = document.getElementById('dash-pipeline-track');
  if (!container) return;

  container.innerHTML = pipeline.map(stage => `
    <div class="pipeline-stage">
      <div class="pipeline-stage-header">
        <span>${stage.name}</span>
        <span class="stage-badge">${stage.count}</span>
      </div>
      <div class="pipeline-drives-list">
        ${stage.drives.length === 0 ? '<div style="color:var(--text-muted);font-size:0.75rem;padding:10px 0;">No active drives</div>' : 
          stage.drives.map(d => `
            <div class="pipeline-item">
              <div class="company-name">${d.company}</div>
              <div class="role-ctc">${d.role.slice(0, 24)}...</div>
              <div style="font-size:0.68rem;color:var(--accent-emerald);margin-top:2px;">${d.applicationStatus}</div>
            </div>
          `).join('')
        }
      </div>
    </div>
  `).join('');
}

function renderDashboardAnnouncements() {
  const container = document.getElementById('dash-announcements-list');
  if (!container || !state.announcements) return;

  container.innerHTML = state.announcements.map(ann => `
    <div style="padding:14px;border-bottom:1px solid var(--border-subtle);">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px;gap:8px;">
        <span class="pill-badge pill-blue">${ann.category}</span>
        <span style="font-size:0.75rem;color:var(--text-muted);">${ann.date}</span>
      </div>
      <h4 style="font-size:0.9rem;font-weight:600;color:#fff;margin-bottom:4px;">${ann.title}</h4>
      <p style="font-size:0.8rem;color:var(--text-secondary);">${ann.content}</p>
      <div style="font-size:0.72rem;color:var(--text-muted);margin-top:6px;">By: ${ann.author}</div>
    </div>
  `).join('');
}

function renderDashboardUpcomingDrives(drives) {
  const container = document.getElementById('dash-upcoming-drives');
  if (!container) return;

  container.innerHTML = drives.map(drive => `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--bg-card-alt);border-radius:var(--radius-md);border:1px solid var(--border-subtle);margin-bottom:10px;">
      <div style="display:flex;align-items:center;gap:12px;">
        <div class="company-logo-placeholder" style="width:36px;height:36px;font-size:0.9rem;">${drive.company.slice(0, 2)}</div>
        <div>
          <div style="font-weight:600;font-size:0.88rem;color:#fff;">${drive.company}</div>
          <div style="font-size:0.75rem;color:var(--text-secondary);">${drive.role}</div>
        </div>
      </div>
      <div style="text-align:right;">
        <div style="font-weight:700;color:#fbbf24;font-size:0.88rem;">${drive.ctcPackage.split(' ')[0]}</div>
        <div style="font-size:0.7rem;color:var(--text-muted);">Deadline: ${drive.deadline}</div>
      </div>
    </div>
  `).join('');
}

// ==========================================
// Tab 2: Top Companies Interview Questions
// ==========================================
async function loadQuestionsTab() {
  const [qRes, metaRes] = await Promise.all([
    api.getQuestions(),
    api.getQuestionFilters()
  ]);

  if (metaRes.success) {
    populateQuestionFilters(metaRes);
  }
  if (qRes.success) {
    state.questions = qRes.data;
    renderQuestionsList(qRes.data);
    updateQuestionsMeta(qRes.meta);
  }

  setupQuestionListeners();
}

function populateQuestionFilters(meta) {
  const companySelect = document.getElementById('filter-q-company');
  const categorySelect = document.getElementById('filter-q-category');

  if (companySelect) {
    companySelect.innerHTML = '<option value="All">All Top Companies</option>' + 
      meta.companies.map(c => `<option value="${c}">${c}</option>`).join('');
  }
  if (categorySelect) {
    categorySelect.innerHTML = '<option value="All">All Categories</option>' + 
      meta.categories.map(c => `<option value="${c}">${c}</option>`).join('');
  }
}

function setupQuestionListeners() {
  const companySelect = document.getElementById('filter-q-company');
  const categorySelect = document.getElementById('filter-q-category');
  const diffSelect = document.getElementById('filter-q-diff');
  const searchInput = document.getElementById('filter-q-search');

  const executeFilter = async () => {
    const filters = {
      company: companySelect?.value || 'All',
      category: categorySelect?.value || 'All',
      difficulty: diffSelect?.value || 'All',
      search: searchInput?.value || ''
    };
    const res = await api.getQuestions(filters);
    if (res.success) {
      state.questions = res.data;
      renderQuestionsList(res.data);
      updateQuestionsMeta(res.meta);
    }
  };

  if (companySelect) companySelect.onchange = executeFilter;
  if (categorySelect) categorySelect.onchange = executeFilter;
  if (diffSelect) diffSelect.onchange = executeFilter;
  if (searchInput) {
    let debounce;
    searchInput.oninput = () => {
      clearTimeout(debounce);
      debounce = setTimeout(executeFilter, 300);
    };
  }
}

function updateQuestionsMeta(meta) {
  const progressEl = document.getElementById('q-progress-bar');
  const textEl = document.getElementById('q-progress-text');
  if (progressEl) progressEl.style.width = `${meta.progressPercentage}%`;
  if (textEl) textEl.textContent = `${meta.solvedCount} of ${meta.total} Mastered (${meta.progressPercentage}%)`;
}

function renderQuestionsList(questions) {
  const container = document.getElementById('questions-list-container');
  if (!container) return;

  if (questions.length === 0) {
    container.innerHTML = `
      <div style="text-align:center;padding:40px;color:var(--text-muted);background:var(--bg-card);border-radius:var(--radius-md);">
        <i class="fas fa-search" style="font-size:2rem;margin-bottom:12px;opacity:0.4;"></i>
        <p>No interview questions found matching the selected filter criteria.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = questions.map(q => {
    const diffClass = q.difficulty.toLowerCase() === 'hard' ? 'diff-hard' :
                      q.difficulty.toLowerCase() === 'medium' ? 'diff-medium' : 'diff-easy';

    return `
      <div class="question-card" id="q-card-${q.id}">
        <div class="question-header">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
            <span class="company-tag"><i class="fas fa-building"></i> ${q.company}</span>
            <span class="diff-badge ${diffClass}">${q.difficulty}</span>
            <span style="font-size:0.75rem;color:var(--text-muted);">${q.round}</span>
          </div>
          <div style="display:flex;align-items:center;gap:8px;">
            <button class="btn btn-sm ${q.solved ? 'btn-success' : 'btn-outline'}" onclick="toggleSolveQuestion('${q.id}')">
              <i class="fas ${q.solved ? 'fa-check-circle' : 'fa-circle'}"></i>
              ${q.solved ? 'Mastered' : 'Mark as Solved'}
            </button>
          </div>
        </div>

        <h4 class="question-title">${q.title}</h4>
        <p class="question-prompt">${q.question}</p>

        <div class="tags-row">
          ${q.keyConcepts.map(c => `<span class="tech-chip">${c}</span>`).join('')}
          <span class="tech-chip" style="color:#fbbf24;"><i class="fas fa-clock"></i> ${q.timeComplexity}</span>
          <span class="tech-chip" style="color:#60a5fa;"><i class="fas fa-memory"></i> ${q.spaceComplexity}</span>
        </div>

        <div style="display:flex;gap:10px;margin-top:10px;">
          <button class="btn btn-sm btn-outline" onclick="toggleSolutionBox('${q.id}')">
            <i class="fas fa-code"></i> View Optimal Solution & Code
          </button>
          <button class="btn btn-sm btn-outline" onclick="openPracticeModal('${q.id}')">
            <i class="fas fa-terminal"></i> Practice Scratchpad
          </button>
        </div>

        <div class="question-solution-box" id="sol-box-${q.id}">
          <div style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:8px;">
            <strong style="color:#fff;">Interview Approach:</strong> ${q.explanation}
          </div>
          <div style="font-size:0.75rem;color:var(--accent-cyan);margin-bottom:4px;">
            <i class="fas fa-lightbulb"></i> <strong>Pro Hint:</strong> ${q.hints[0] || 'Focus on time complexity bounds.'}
          </div>
          <pre class="code-snippet"><code>${escapeHtml(q.solutionSnippet)}</code></pre>
        </div>
      </div>
    `;
  }).join('');
}

function toggleSolutionBox(id) {
  const box = document.getElementById(`sol-box-${id}`);
  if (box) box.classList.toggle('active');
}

async function toggleSolveQuestion(id) {
  const res = await api.toggleQuestionSolve(id);
  if (res.success) {
    showToast(res.message, "success");
    // Refresh question list
    const filters = {
      company: document.getElementById('filter-q-company')?.value || 'All',
      category: document.getElementById('filter-q-category')?.value || 'All',
      difficulty: document.getElementById('filter-q-diff')?.value || 'All'
    };
    const refreshed = await api.getQuestions(filters);
    if (refreshed.success) {
      renderQuestionsList(refreshed.data);
      updateQuestionsMeta(refreshed.meta);
    }
  }
}

function openPracticeModal(id) {
  const question = state.questions.find(q => q.id === id);
  if (!question) return;

  const modal = document.getElementById('modal-practice-code');
  if (!modal) return;

  document.getElementById('practice-modal-title').textContent = `${question.company} Interview Practice: ${question.title}`;
  document.getElementById('practice-modal-question').textContent = question.question;
  document.getElementById('practice-code-input').value = `// Write your ${question.company} solution here in JavaScript / C++ / Python\nfunction solve(input) {\n    // Code here\n    return true;\n}`;
  document.getElementById('practice-code-output').textContent = "Ready to test. Click 'Run Code' to simulate test cases.";

  modal.classList.add('active');
}

// ==========================================
// Tab 3: Qualifications & Eligibility Matrix
// ==========================================
async function loadQualificationsTab() {
  const res = await api.getEligibilityMatrix();
  if (res.success) {
    renderEligibilityOverview(res.studentOverview);
    renderEligibilityMatrixTable(res.matrix);
  }
}

function renderEligibilityOverview(student) {
  const container = document.getElementById('eligibility-student-summary');
  if (!container) return;

  container.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));gap:14px;">
      <div style="background:var(--bg-card-alt);padding:14px;border-radius:var(--radius-md);border:1px solid var(--border-subtle);">
        <div style="font-size:0.75rem;color:var(--text-muted);">Current Cumulative GPA</div>
        <div style="font-size:1.4rem;font-weight:700;color:#34d399;">${student.cgpa} / 10.0</div>
        <div style="font-size:0.7rem;color:var(--text-secondary);">Tier 1 Eligible (> 8.0)</div>
      </div>
      <div style="background:var(--bg-card-alt);padding:14px;border-radius:var(--radius-md);border:1px solid var(--border-subtle);">
        <div style="font-size:0.75rem;color:var(--text-muted);">Active Backlogs</div>
        <div style="font-size:1.4rem;font-weight:700;color:#34d399;">${student.backlogs} Backlogs</div>
        <div style="font-size:0.7rem;color:var(--text-secondary);">Clean Academic Slate</div>
      </div>
      <div style="background:var(--bg-card-alt);padding:14px;border-radius:var(--radius-md);border:1px solid var(--border-subtle);">
        <div style="font-size:0.75rem;color:var(--text-muted);">Department / Branch</div>
        <div style="font-size:1.1rem;font-weight:700;color:#60a5fa;margin-top:4px;">${student.department}</div>
        <div style="font-size:0.7rem;color:var(--text-secondary);">Class of 2026</div>
      </div>
      <div style="background:var(--bg-card-alt);padding:14px;border-radius:var(--radius-md);border:1px solid var(--border-subtle);">
        <div style="font-size:0.75rem;color:var(--text-muted);">10th & 12th Academic %</div>
        <div style="font-size:1.4rem;font-weight:700;color:#fbbf24;">${student.tenth}% / ${student.twelfth}%</div>
        <div style="font-size:0.7rem;color:var(--text-secondary);">Meets all corporate cutoffs</div>
      </div>
    </div>
  `;
}

function renderEligibilityMatrixTable(matrix) {
  const container = document.getElementById('eligibility-matrix-body');
  if (!container) return;

  container.innerHTML = matrix.map(item => `
    <tr>
      <td style="font-weight:600;">
        <div style="color:#fff;">${item.company}</div>
        <div style="font-size:0.75rem;color:var(--text-secondary);">${item.role}</div>
      </td>
      <td><span style="color:#fbbf24;font-weight:700;">${item.ctc}</span></td>
      <td>
        <span style="color:${item.criteria.cgpaPassed ? '#34d399' : '#fb7185'};font-weight:600;">
          Cutoff: ${item.criteria.minCgpa}
        </span>
        <span style="font-size:0.72rem;color:var(--text-muted);display:block;">You: ${item.criteria.studentCgpa}</span>
      </td>
      <td>
        <span style="color:${item.criteria.backlogsPassed ? '#34d399' : '#fb7185'};">
          Max ${item.criteria.allowedBacklogs} allowed
        </span>
      </td>
      <td>
        <div style="font-size:0.75rem;color:var(--text-secondary);max-width:180px;">
          ${item.criteria.branches.join(', ')}
        </div>
      </td>
      <td>
        ${item.isEligible ? 
          `<span class="pill-badge pill-emerald"><i class="fas fa-check-circle"></i> Fully Eligible</span>` : 
          `<span class="pill-badge" style="background:var(--rose-bg);color:#fb7185;border:1px solid rgba(244,63,94,0.3);"><i class="fas fa-times-circle"></i> Ineligible</span>`
        }
      </td>
      <td>
        ${item.applied ? 
          `<span style="color:var(--accent-cyan);font-weight:600;font-size:0.78rem;">${item.applicationStatus}</span>` : 
          (item.isEligible ? 
            `<button class="btn btn-sm btn-primary" onclick="openApplyModal('${item.driveId}')">Apply Now</button>` : 
            `<button class="btn btn-sm btn-outline" disabled style="opacity:0.4;">Locked</button>`
          )
        }
      </td>
    </tr>
  `).join('');
}

// ==========================================
// Tab 4: Placement Drives & Internships
// ==========================================
async function loadDrivesTab() {
  const categoryFilter = document.getElementById('filter-drive-tier')?.value || 'All';
  const res = await api.getDrives(categoryFilter);
  if (res.success) {
    state.drives = res.data;
    renderDrivesGrid(res.data);
  }

  const tierSelect = document.getElementById('filter-drive-tier');
  if (tierSelect) {
    tierSelect.onchange = () => loadDrivesTab();
  }
}

function renderDrivesGrid(drives) {
  const container = document.getElementById('drives-grid-container');
  if (!container) return;

  container.innerHTML = drives.map(drive => {
    const isEligible = drive.qualificationStatus.isEligible;
    return `
      <div class="drive-card ${isEligible ? 'eligible-drive' : 'ineligible-drive'}">
        <div>
          <div class="drive-top">
            <div class="drive-company-info">
              <div class="company-logo-placeholder">${drive.company.slice(0, 2)}</div>
              <div>
                <div class="drive-company-name">${drive.company}</div>
                <div class="drive-role-name">${drive.role}</div>
              </div>
            </div>
            <span class="pill-badge ${drive.category.includes('Super') ? 'pill-purple' : 'pill-blue'}">
              ${drive.category}
            </span>
          </div>

          <div class="package-highlight">
            <div class="ctc-amount">${drive.ctcPackage}</div>
            <div class="stipend-text">Internship Stipend: ${drive.stipend}</div>
          </div>

          <div style="font-size:0.82rem;color:var(--text-secondary);margin-bottom:12px;line-height:1.5;">
            ${drive.description}
          </div>

          <div class="eligibility-check-box">
            <div style="font-weight:600;margin-bottom:4px;color:${isEligible ? '#34d399' : '#fb7185'};">
              <i class="fas ${isEligible ? 'fa-check-circle' : 'fa-exclamation-triangle'}"></i>
              ${isEligible ? 'Academic Eligibility: PASSED' : 'Eligibility Criteria Mismatch'}
            </div>
            <div style="font-size:0.75rem;color:var(--text-muted);">
              Cutoff: Min CGPA ${drive.eligibility.minCgpa} • Max ${drive.eligibility.allowedBacklogs} Backlogs • ${drive.eligibility.eligibleBranches.join(', ')}
            </div>
          </div>

          <div style="display:flex;justify-content:space-between;font-size:0.75rem;color:var(--text-muted);margin-bottom:14px;">
            <span><i class="fas fa-map-marker-alt"></i> ${drive.location}</span>
            <span><i class="fas fa-calendar-alt"></i> Deadline: ${drive.deadline}</span>
          </div>
        </div>

        <div style="display:flex;gap:10px;align-items:center;margin-top:10px;">
          ${drive.applied ? `
            <div style="background:rgba(6,182,212,0.15);border:1px solid rgba(6,182,212,0.3);color:#22d3ee;padding:8px 12px;border-radius:var(--radius-md);width:100%;text-align:center;font-weight:600;font-size:0.8rem;">
              <i class="fas fa-check-double"></i> ${drive.applicationStatus}
            </div>
          ` : (isEligible ? `
            <button class="btn btn-primary" style="width:100%;" onclick="openApplyModal('${drive.id}')">
              <i class="fas fa-paper-plane"></i> 1-Click Apply
            </button>
          ` : `
            <button class="btn btn-outline" style="width:100%;opacity:0.5;" disabled>
              <i class="fas fa-lock"></i> Ineligible for this Drive
            </button>
          `)}
        </div>
      </div>
    `;
  }).join('');
}

function openApplyModal(driveId) {
  const drive = state.drives.find(d => d.id === driveId);
  if (!drive || !state.profile) return;

  const modal = document.getElementById('modal-apply-drive');
  if (!modal) return;

  document.getElementById('apply-modal-company').textContent = drive.company;
  document.getElementById('apply-modal-role').textContent = drive.role;
  document.getElementById('apply-modal-package').textContent = drive.ctcPackage;
  document.getElementById('apply-modal-student').textContent = `${state.profile.fullName} (${state.profile.rollNumber})`;
  document.getElementById('apply-modal-cgpa').textContent = `CGPA: ${state.profile.cgpa} (Cutoff: ${drive.eligibility.minCgpa})`;
  document.getElementById('apply-modal-resume').textContent = state.profile.resumeFilename;

  const submitBtn = document.getElementById('apply-modal-submit-btn');
  submitBtn.onclick = async () => {
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Submitting...`;
    const res = await api.applyToDrive(driveId);
    if (res.success) {
      showToast(res.message, "success");
      modal.classList.remove('active');
      loadDrivesTab();
      loadDashboardOverview();
    } else {
      showToast(res.error || "Application submission failed", "error");
    }
    submitBtn.disabled = false;
    submitBtn.innerHTML = `Confirm Application`;
  };

  modal.classList.add('active');
}

// ==========================================
// Tab 5: Your Projects Hub
// ==========================================
async function loadProjectsTab() {
  const res = await api.getProjects();
  if (res.success) {
    state.projects = res.data;
    renderProjectsGrid(res.data);
  }
}

function renderProjectsGrid(projects) {
  const container = document.getElementById('projects-grid-container');
  if (!container) return;

  container.innerHTML = projects.map(proj => `
    <div class="project-card ${proj.featured ? 'featured-project' : ''}" id="proj-${proj.id}">
      <div>
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
          <span class="pill-badge pill-blue">${proj.category}</span>
          <button class="btn btn-sm ${proj.featured ? 'btn-amber' : 'btn-outline'}" onclick="toggleFeaturedProject('${proj.id}')" title="Pin to Resume">
            <i class="fas fa-star"></i> ${proj.featured ? 'Pinned on Resume' : 'Pin'}
          </button>
        </div>

        <h4 class="project-title">${proj.title}</h4>
        <p class="project-tagline">${proj.tagline}</p>

        <div class="project-metrics-banner">
          <i class="fas fa-chart-line"></i>
          <span>${proj.metrics}</span>
        </div>

        <div style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:12px;">
          <strong style="color:#fff;">Problem & Architecture:</strong> ${proj.solution}
        </div>

        <div class="tags-row">
          ${proj.technologies.map(t => `<span class="tech-chip">${t}</span>`).join('')}
        </div>
      </div>

      <div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px;padding-top:12px;border-top:1px solid var(--border-subtle);">
        <div style="display:flex;gap:12px;">
          ${proj.githubUrl ? `
            <a href="${proj.githubUrl}" target="_blank" class="btn btn-sm btn-outline">
              <i class="fab fa-github"></i> Repository
            </a>
          ` : ''}
          ${proj.liveDemoUrl ? `
            <a href="${proj.liveDemoUrl}" target="_blank" class="btn btn-sm btn-primary">
              <i class="fas fa-external-link-alt"></i> Live Demo
            </a>
          ` : ''}
        </div>
        <button class="btn btn-sm btn-outline" style="color:var(--accent-rose);border-color:rgba(244,63,94,0.3);" onclick="deleteProject('${proj.id}')" title="Delete Project">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join('');
}

async function toggleFeaturedProject(id) {
  const res = await api.toggleProjectFeatured(id);
  if (res.success) {
    showToast(res.message, "success");
    loadProjectsTab();
  }
}

async function deleteProject(id) {
  if (!confirm("Are you sure you want to remove this project from your placement portfolio?")) return;
  const res = await api.deleteProject(id);
  if (res.success) {
    showToast(res.message, "info");
    loadProjectsTab();
  }
}

function openAddProjectModal() {
  const modal = document.getElementById('modal-add-project');
  if (modal) modal.classList.add('active');
}

// ==========================================
// Tab 6: Skills & Dream Company Benchmarks
// ==========================================
async function loadSkillsTab() {
  const res = await api.getSkills();
  if (res.success) {
    state.skills = res.data;
    renderSkillsMatrix(res.data.categories);
    renderDreamCompanyGapAnalysis('Google');
  }

  const companySelector = document.getElementById('gap-company-selector');
  if (companySelector) {
    companySelector.onchange = (e) => {
      renderDreamCompanyGapAnalysis(e.target.value);
    };
  }
}

function renderSkillsMatrix(categories) {
  const container = document.getElementById('skills-matrix-container');
  if (!container) return;

  container.innerHTML = categories.map(cat => `
    <div class="skills-category-box">
      <div class="skills-category-header">
        <i class="fas fa-code-branch" style="color:var(--primary-blue);"></i>
        <span>${cat.name}</span>
      </div>
      <div class="skills-items-grid">
        ${cat.skills.map(s => `
          <div class="skill-meter-card">
            <div class="skill-meter-title">
              <span style="color:#fff;">${s.name}</span>
              <span style="color:var(--accent-cyan);">${s.proficiency}% (${s.level})</span>
            </div>
            <div class="meter-track">
              <div class="meter-fill" style="width:${s.proficiency}%;"></div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `).join('');
}

async function renderDreamCompanyGapAnalysis(company) {
  const res = await api.getSkillGapAnalysis(company);
  if (!res.success) return;

  const container = document.getElementById('skill-gap-analysis-result');
  if (!container) return;

  const match = res.matchPercentage;
  const color = match >= 90 ? '#34d399' : match >= 80 ? '#60a5fa' : '#fbbf24';

  container.innerHTML = `
    <div style="background:var(--bg-card-alt);border:1px solid var(--border-subtle);border-radius:var(--radius-lg);padding:20px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:10px;">
        <div>
          <h4 style="font-size:1.1rem;color:#fff;">Target Role Match: ${company} SDE-1</h4>
          <div style="font-size:0.8rem;color:var(--text-secondary);">Benchmarked against current 2026 hiring criteria</div>
        </div>
        <div style="font-size:1.8rem;font-weight:700;color:${color};">
          ${match}% Match
        </div>
      </div>

      <div class="meter-track" style="height:10px;margin-bottom:16px;">
        <div class="meter-fill" style="width:${match}%;background:${color};"></div>
      </div>

      <div style="margin-bottom:14px;">
        <div style="font-size:0.8rem;font-weight:600;color:#fff;margin-bottom:6px;">
          <i class="fas fa-tools" style="color:#fbbf24;"></i> Recommended Skills to Strengthen:
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
          ${res.missingSkills.map(m => `<span class="pill-badge pill-amber">${m}</span>`).join('')}
        </div>
      </div>

      <div>
        <div style="font-size:0.8rem;font-weight:600;color:#fff;margin-bottom:6px;">
          <i class="fas fa-tasks" style="color:#34d399;"></i> Actionable Placement Roadmap:
        </div>
        <ul style="padding-left:18px;font-size:0.8rem;color:var(--text-secondary);line-height:1.6;">
          ${res.recommendations.map(r => `<li>${r}</li>`).join('')}
        </ul>
      </div>
    </div>
  `;
}

// ==========================================
// Tab 7: Hackathons & Competitions
// ==========================================
async function loadHackathonsTab() {
  const res = await api.getHackathons();
  if (res.success) {
    state.hackathons = res.data;
    renderHackathonsGrid(res.data);
    renderTeammateBoard(res.teammateBoard);
  }
}

function renderHackathonsGrid(hackathons) {
  const container = document.getElementById('hackathons-grid-container');
  if (!container) return;

  container.innerHTML = hackathons.map(hack => `
    <div class="hackathon-card">
      <div>
        <div style="display:flex;justify-content:space-between;margin-bottom:8px;align-items:center;">
          <span class="pill-badge pill-purple">${hack.badge}</span>
          <span style="font-size:0.75rem;color:var(--text-muted);"><i class="fas fa-clock"></i> Deadline: ${hack.dates.registrationDeadline}</span>
        </div>

        <h4 style="font-size:1.15rem;font-weight:700;color:#fff;margin-bottom:4px;">${hack.name}</h4>
        <div style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:10px;">Organized by: <strong style="color:#fff;">${hack.organizer}</strong></div>

        <div class="prize-pool-tag">
          <i class="fas fa-trophy"></i> ${hack.prizePool}
        </div>

        <p style="font-size:0.82rem;color:var(--text-secondary);margin-bottom:14px;line-height:1.5;">
          ${hack.description}
        </p>

        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px;">
          ${hack.themes.map(t => `<span class="tech-chip">${t}</span>`).join('')}
        </div>

        <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:14px;">
          <i class="fas fa-users"></i> Team Size: ${hack.teamSize} • ${hack.mode}
        </div>
      </div>

      <div style="display:flex;gap:10px;margin-top:12px;">
        ${hack.registered ? `
          <div style="background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);color:#34d399;padding:8px 12px;border-radius:var(--radius-md);width:100%;text-align:center;font-weight:600;font-size:0.8rem;">
            <i class="fas fa-check-circle"></i> Registered as ${hack.teamName}
          </div>
        ` : `
          <button class="btn btn-primary" style="flex:1;" onclick="registerForHackathon('${hack.id}')">
            <i class="fas fa-user-plus"></i> Register Team
          </button>
        `}
        <a href="${hack.directApplyUrl}" target="_blank" class="btn btn-outline" style="padding:8px 12px;" title="Official Portal">
          <i class="fas fa-external-link-alt"></i>
        </a>
      </div>
    </div>
  `).join('');
}

function renderTeammateBoard(posts) {
  const container = document.getElementById('teammates-board-container');
  if (!container || !posts) return;

  container.innerHTML = posts.map(post => `
    <div style="background:var(--bg-card-alt);border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:14px;margin-bottom:12px;">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
        <span style="font-weight:600;color:#fff;font-size:0.88rem;">${post.studentName}</span>
        <span class="pill-badge pill-blue">${post.hackathonName}</span>
      </div>
      <div style="font-size:0.82rem;color:var(--accent-cyan);font-weight:600;margin-bottom:4px;">
        Looking for: ${post.roleNeeded}
      </div>
      <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:8px;">${post.description}</p>
      <div style="font-size:0.75rem;color:var(--text-muted);">
        <i class="fas fa-envelope"></i> Contact: <a href="mailto:${post.contact}" style="color:#60a5fa;text-decoration:none;">${post.contact}</a>
      </div>
    </div>
  `).join('');
}

async function registerForHackathon(id) {
  const teamName = prompt("Enter your team name for registration:", "AlgoWarriors 2026");
  if (!teamName) return;

  const res = await api.registerHackathon(id, teamName);
  if (res.success) {
    showToast(res.message, "success");
    loadHackathonsTab();
  }
}

// ==========================================
// Tab 8: Portfolio & Student Profile Builder
// ==========================================
async function loadProfileTab() {
  const res = await api.getProfile();
  if (res.success) {
    state.profile = res.data;
    renderProfileDetails(res.data);
  }
}

function renderProfileDetails(p) {
  const container = document.getElementById('profile-content-container');
  if (!container) return;

  container.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 2fr;gap:24px;">
      <!-- Profile Card -->
      <div class="content-box">
        <div style="text-align:center;margin-bottom:18px;">
          <img src="${p.avatar}" style="width:100px;height:100px;border-radius:50%;border:3px solid var(--primary-blue);object-fit:cover;margin-bottom:12px;" />
          <h3 style="font-size:1.3rem;font-weight:700;color:#fff;">${p.fullName}</h3>
          <div style="font-size:0.85rem;color:var(--text-secondary);">${p.rollNumber} • ${p.usn}</div>
          <div style="font-size:0.8rem;color:var(--accent-cyan);margin-top:2px;">${p.degree} - ${p.department}</div>
          <div style="font-size:0.78rem;color:var(--text-muted);">${p.college}</div>
        </div>

        <div style="background:var(--bg-card-alt);padding:14px;border-radius:var(--radius-md);margin-bottom:18px;">
          <div style="font-size:0.75rem;color:var(--text-muted);text-transform:uppercase;">Overall Cumulative GPA</div>
          <div style="font-size:1.8rem;font-weight:700;color:#34d399;">${p.cgpa} / 10.0</div>
          <div style="font-size:0.72rem;color:var(--text-secondary);">Active Backlogs: <strong style="color:#34d399;">0</strong> • Dead: 0</div>
        </div>

        <div style="margin-bottom:18px;">
          <div style="font-size:0.8rem;font-weight:600;color:#fff;margin-bottom:8px;">Coding Profiles & Verified Ratings</div>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <a href="${p.leetcodeUrl}" target="_blank" class="btn btn-outline" style="justify-content:flex-start;">
              <i class="fas fa-code" style="color:#fbbf24;"></i> LeetCode: ${p.codingStats.leetcode.solved} Solved (Rating: ${p.codingStats.leetcode.rating})
            </a>
            <a href="${p.githubUrl}" target="_blank" class="btn btn-outline" style="justify-content:flex-start;">
              <i class="fab fa-github"></i> GitHub: ${p.codingStats.github.repos} Repos (${p.codingStats.github.stars} Stars)
            </a>
            <a href="${p.linkedinUrl}" target="_blank" class="btn btn-outline" style="justify-content:flex-start;">
              <i class="fab fa-linkedin" style="color:#60a5fa;"></i> LinkedIn Profile
            </a>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:10px;">
          <button class="btn btn-primary" onclick="openAtsAnalyzerModal()">
            <i class="fas fa-file-alt"></i> Run ATS Resume Audit
          </button>
          <button class="btn btn-outline" onclick="openPublicPortfolioModal()">
            <i class="fas fa-globe"></i> View Public Recruiter Portfolio
          </button>
        </div>
      </div>

      <!-- Right Column: Academic Breakdown & Bio -->
      <div>
        <div class="content-box">
          <div class="box-header">
            <h3><i class="fas fa-graduation-cap"></i> Semester Academic Trajectory</h3>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(110px, 1fr));gap:10px;margin-bottom:16px;">
            ${p.semesters.map(s => `
              <div style="background:var(--bg-card-alt);padding:10px;border-radius:var(--radius-sm);text-align:center;border:1px solid var(--border-subtle);">
                <div style="font-size:0.72rem;color:var(--text-muted);">${s.sem}</div>
                <div style="font-size:1.1rem;font-weight:700;color:#60a5fa;">${s.sgpa}</div>
                <div style="font-size:0.65rem;color:var(--text-muted);">${s.credits} Credits</div>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="content-box">
          <div class="box-header">
            <h3><i class="fas fa-certificate"></i> Verified Industry Certifications</h3>
          </div>
          <div style="display:flex;flex-direction:column;gap:12px;">
            ${p.certifications.map(c => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:12px;background:var(--bg-card-alt);border-radius:var(--radius-md);border:1px solid var(--border-subtle);">
                <div>
                  <div style="font-weight:600;color:#fff;font-size:0.88rem;">${c.title}</div>
                  <div style="font-size:0.75rem;color:var(--text-secondary);">${c.issuer} • Issued: ${c.date}</div>
                  <div style="font-size:0.7rem;color:var(--text-muted);font-family:var(--font-mono);">Credential ID: ${c.credentialId}</div>
                </div>
                <a href="${c.verifyUrl}" target="_blank" class="btn btn-sm btn-outline">
                  <i class="fas fa-check-circle" style="color:#34d399;"></i> Verified
                </a>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    </div>
  `;
}

// ==========================================
// ATS Resume Analyzer Modal
// ==========================================
async function openAtsAnalyzerModal() {
  const res = await api.calculateAtsScore('Amazon SDE-1');
  if (!res.success) return;

  const modal = document.getElementById('modal-ats-analyzer');
  if (!modal) return;

  document.getElementById('ats-score-display').textContent = `${res.score} / 100`;
  const bar = document.getElementById('ats-score-bar');
  if (bar) bar.style.width = `${res.score}%`;

  const feedbackList = document.getElementById('ats-feedback-list');
  if (feedbackList) {
    feedbackList.innerHTML = res.feedback.map(f => `
      <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;font-size:0.82rem;">
        <i class="fas ${f.type === 'positive' ? 'fa-check-circle' : 'fa-exclamation-triangle'}" style="color:${f.type === 'positive' ? '#34d399' : '#fbbf24'};margin-top:3px;"></i>
        <span style="color:var(--text-main);">${f.message}</span>
      </div>
    `).join('');
  }

  modal.classList.add('active');
}

// ==========================================
// Standalone Public Portfolio Modal View
// ==========================================
async function openPublicPortfolioModal() {
  const res = await api.getPublicPortfolio();
  if (!res.success) return;

  const modal = document.getElementById('modal-public-portfolio');
  if (!modal) return;

  const data = res.data;
  const container = document.getElementById('portfolio-modal-body');
  if (container) {
    container.innerHTML = `
      <div style="background:#070d18;padding:24px;border-radius:var(--radius-lg);border:1px solid var(--border-subtle);color:#fff;">
        <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-subtle);padding-bottom:18px;margin-bottom:20px;flex-wrap:wrap;gap:16px;">
          <div>
            <h2 style="font-size:1.6rem;font-weight:700;">${data.student.fullName}</h2>
            <div style="color:var(--accent-cyan);font-weight:600;font-size:0.9rem;">${data.student.degree} - ${data.student.college}</div>
            <div style="color:var(--text-secondary);font-size:0.8rem;margin-top:4px;">CGPA: ${data.student.cgpa} • Final Year SDE Candidate</div>
          </div>
          <div style="display:flex;gap:8px;">
            <a href="${data.student.links.github}" target="_blank" class="btn btn-sm btn-outline"><i class="fab fa-github"></i> GitHub</a>
            <a href="${data.student.links.linkedin}" target="_blank" class="btn btn-sm btn-primary"><i class="fab fa-linkedin"></i> LinkedIn</a>
            <a href="${data.student.links.leetcode}" target="_blank" class="btn btn-sm btn-amber"><i class="fas fa-code"></i> LeetCode</a>
          </div>
        </div>

        <div style="margin-bottom:24px;">
          <h4 style="font-size:1rem;color:#60a5fa;margin-bottom:6px;">Executive Summary</h4>
          <p style="font-size:0.85rem;color:var(--text-secondary);line-height:1.6;">${data.student.bio}</p>
        </div>

        <div style="margin-bottom:24px;">
          <h4 style="font-size:1rem;color:#60a5fa;margin-bottom:12px;">Featured 4th Year Engineering Projects</h4>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
            ${data.featuredProjects.map(p => `
              <div style="background:var(--bg-card);padding:14px;border-radius:var(--radius-md);border:1px solid var(--border-subtle);">
                <div style="font-weight:700;color:#fff;font-size:0.92rem;">${p.title}</div>
                <div style="font-size:0.75rem;color:var(--accent-emerald);margin-bottom:6px;">${p.metrics}</div>
                <p style="font-size:0.78rem;color:var(--text-secondary);margin-bottom:8px;">${p.solution}</p>
                <div class="tags-row">${p.technologies.slice(0, 4).map(t => `<span class="tech-chip">${t}</span>`).join('')}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  modal.classList.add('active');
}

// ==========================================
// Tab 9: Mock Placement Tests
// ==========================================
async function loadMockTestsTab() {
  const res = await api.getMockTests();
  if (res.success) {
    renderMockTestsList(res.data);
  }
}

function renderMockTestsList(tests) {
  const container = document.getElementById('mock-tests-list-container');
  if (!container) return;

  container.innerHTML = tests.map(test => `
    <div class="content-box" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;">
        <div>
          <span class="pill-badge pill-blue" style="margin-bottom:8px;">${test.category}</span>
          <h4 style="font-size:1.15rem;font-weight:700;color:#fff;margin-bottom:4px;">${test.title}</h4>
          <div style="font-size:0.8rem;color:var(--text-secondary);">
            <i class="fas fa-clock"></i> Duration: ${test.durationMins} Minutes • ${test.totalQuestions} Questions
          </div>
          <div style="font-size:0.75rem;color:var(--text-muted);margin-top:6px;">
            Targeted for: ${test.targetCompanies.join(', ')}
          </div>
        </div>
        <button class="btn btn-primary" onclick="startMockTest('${test.id}')">
          <i class="fas fa-play"></i> Start Assessment
        </button>
      </div>
    </div>
  `).join('');
}

async function startMockTest(testId) {
  try {
    const res = await api.getMockTestById(testId);
    if (!res.success) {
      showToast(res.error || "Could not load test questions", "error");
      return;
    }

    state.activeTest = res.data;
    state.testRemainingSeconds = (res.data.durationMins || 30) * 60;
    state.testUserAnswers = {};

    const modal = document.getElementById('modal-mock-test-runner');
    if (!modal) return;

    document.getElementById('test-runner-title').textContent = res.data.title;
    
    // Reset footer to active submission mode
    const footer = document.getElementById('mock-test-modal-footer');
    if (footer) {
      footer.innerHTML = `
        <button class="btn btn-outline modal-cancel-btn" onclick="quitMockTest()">Quit Test</button>
        <button class="btn btn-success" id="mock-test-submit-btn" onclick="submitMockTest()">
          <i class="fas fa-check"></i> Submit Assessment
        </button>
      `;
    }

    renderTestQuestions(res.data.questions);

    // Reset scroll to top
    const modalBox = modal.querySelector('.modal-box');
    if (modalBox) modalBox.scrollTop = 0;

    // Start countdown timer
    clearInterval(state.testTimer);
    updateTimerDisplay();
    state.testTimer = setInterval(() => {
      state.testRemainingSeconds--;
      updateTimerDisplay();
      if (state.testRemainingSeconds <= 0) {
        clearInterval(state.testTimer);
        showToast("Time is up! Submitting your assessment automatically...", "info");
        submitMockTest();
      }
    }, 1000);

    modal.classList.add('active');
  } catch (err) {
    console.error("Error starting test:", err);
    showToast("Error starting assessment: " + err.message, "error");
  }
}

function quitMockTest() {
  if (confirm("Are you sure you want to quit this assessment? Your progress will not be saved.")) {
    clearInterval(state.testTimer);
    document.getElementById('modal-mock-test-runner').classList.remove('active');
  }
}

function updateTimerDisplay() {
  const mins = Math.floor(state.testRemainingSeconds / 60);
  const secs = state.testRemainingSeconds % 60;
  const timerEl = document.getElementById('test-runner-timer');
  if (timerEl) {
    timerEl.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
}

function renderTestQuestions(questions) {
  const container = document.getElementById('test-questions-form');
  if (!container) return;

  container.innerHTML = questions.map((q, idx) => `
    <div style="background:var(--bg-card-alt);border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:18px;margin-bottom:16px;">
      <div style="font-weight:600;font-size:0.95rem;color:#fff;margin-bottom:12px;">
        <span style="color:var(--accent-cyan);">Q${idx + 1}.</span> ${q.question}
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;" id="q-options-wrap-${q.id}">
        ${q.options.map((opt, optIdx) => `
          <label style="display:flex;align-items:center;gap:12px;padding:10px 14px;background:var(--bg-dark);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);cursor:pointer;transition:all 0.15s ease;" id="label-${q.id}-${optIdx}">
            <input type="radio" name="test-q-${q.id}" value="${optIdx}" style="cursor:pointer;accent-color:var(--primary-blue);" onchange="selectTestOption('${q.id}', ${optIdx})" />
            <span style="font-size:0.85rem;color:var(--text-main);">${opt}</span>
          </label>
        `).join('')}
      </div>
    </div>
  `).join('');
}

function selectTestOption(qId, optionIdx) {
  state.testUserAnswers[qId] = Number(optionIdx);

  // Update visual selection borders
  const wrap = document.getElementById(`q-options-wrap-${qId}`);
  if (wrap) {
    wrap.querySelectorAll('label').forEach((lbl, idx) => {
      if (idx === optionIdx) {
        lbl.style.borderColor = 'var(--primary-blue)';
        lbl.style.background = 'rgba(37, 99, 235, 0.12)';
      } else {
        lbl.style.borderColor = 'var(--border-subtle)';
        lbl.style.background = 'var(--bg-dark)';
      }
    });
  }
}

function recordTestAnswer(qId, optionIdx) {
  state.testUserAnswers[qId] = Number(optionIdx);
}

async function submitMockTest() {
  clearInterval(state.testTimer);

  if (!state.activeTest) {
    showToast("No active test found to submit.", "error");
    return;
  }

  // Scrape all selected radio buttons from the DOM to ensure 100% capture
  const radios = document.querySelectorAll('#test-questions-form input[type="radio"]:checked');
  radios.forEach(r => {
    const qId = r.name.replace('test-q-', '');
    state.testUserAnswers[qId] = Number(r.value);
  });

  const submitBtn = document.getElementById('mock-test-submit-btn');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Scoring Assessment...`;
  }

  try {
    const res = await api.submitMockTest(state.activeTest.id, state.testUserAnswers);

    if (!res.success) {
      showToast(res.error || "Failed to submit assessment.", "error");
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `<i class="fas fa-check"></i> Submit Assessment`;
      }
      return;
    }

    // Stop timer & mark submitted
    const timerEl = document.getElementById('test-runner-timer');
    if (timerEl) {
      timerEl.textContent = "✓ Graded";
      timerEl.style.background = "var(--emerald-bg)";
      timerEl.style.color = "#34d399";
    }

    const resultContainer = document.getElementById('test-questions-form');
    if (resultContainer) {
      resultContainer.innerHTML = `
        <div style="text-align:center;padding:26px;background:var(--bg-card);border-radius:var(--radius-lg);margin-bottom:24px;border:1px solid var(--border-subtle);">
          <div style="font-size:0.8rem;text-transform:uppercase;color:var(--text-muted);font-weight:600;letter-spacing:0.05em;">Performance Evaluation</div>
          <h3 style="font-size:1.6rem;font-weight:700;color:#fff;margin:6px 0 10px;">${res.score.passed ? '🎉 Congratulations! You Passed!' : 'Assessment Completed'}</h3>
          
          <div style="font-size:3rem;font-weight:800;color:${res.score.passed ? '#34d399' : '#fb7185'};line-height:1;margin-bottom:12px;">
            ${res.score.percentage}%
          </div>

          <div style="display:flex;justify-content:center;gap:10px;margin-bottom:12px;flex-wrap:wrap;">
            <span class="pill-badge ${res.score.passed ? 'pill-emerald' : 'pill-amber'}" style="font-size:0.85rem;padding:6px 14px;">
              <i class="fas ${res.score.passed ? 'fa-check-circle' : 'fa-info-circle'}"></i> ${res.score.performanceBadge}
            </span>
            <span class="pill-badge pill-blue" style="font-size:0.85rem;padding:6px 14px;">
              ${res.score.correct} / ${res.score.total} Correct Answers
            </span>
          </div>

          <p style="font-size:0.82rem;color:var(--text-secondary);max-width:550px;margin:0 auto;">
            ${res.score.passed 
              ? 'Excellent performance! Your score indicates strong readiness for campus placement online assessments.' 
              : 'Review the step-by-step explanations below to strengthen your problem areas before the official drive.'}
          </p>
        </div>

        <h4 style="font-size:1.05rem;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:8px;">
          <i class="fas fa-clipboard-list" style="color:var(--primary-blue);"></i> Detailed Question Review & Solutions:
        </h4>

        ${res.review.map((r, i) => `
          <div style="background:var(--bg-card-alt);border:1px solid ${r.isCorrect ? 'rgba(16,185,129,0.35)' : 'rgba(244,63,94,0.35)'};border-radius:var(--radius-md);padding:16px;margin-bottom:14px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:8px;">
              <div style="font-weight:600;color:#fff;font-size:0.92rem;">
                <span style="color:var(--accent-cyan);">Q${i + 1}.</span> ${r.question}
              </div>
              <span class="pill-badge ${r.isCorrect ? 'pill-emerald' : 'pill-rose'}" style="white-space:nowrap;">
                ${r.isCorrect ? '✓ Correct' : (r.userSelected !== null ? '✗ Incorrect' : '⚪ Unanswered')}
              </span>
            </div>

            <div style="display:flex;flex-direction:column;gap:4px;font-size:0.8rem;margin-bottom:10px;">
              <div style="color:${r.isCorrect ? '#34d399' : '#fb7185'};">
                <strong>Your Answer:</strong> ${r.userSelected !== null ? r.options[r.userSelected] : '<span style="color:var(--text-muted);">None selected</span>'}
              </div>
              ${!r.isCorrect ? `
                <div style="color:#34d399;">
                  <strong>Correct Answer:</strong> ${r.options[r.correctIndex]}
                </div>
              ` : ''}
            </div>

            <div style="font-size:0.78rem;color:var(--text-secondary);background:var(--bg-dark);padding:10px 12px;border-radius:var(--radius-sm);border:1px solid rgba(255,255,255,0.05);line-height:1.5;">
              <strong style="color:var(--accent-cyan);"><i class="fas fa-lightbulb"></i> Explanation:</strong> ${r.explanation}
            </div>
          </div>
        `).join('')}
      `;
    }

    // Update modal footer to review mode
    const footer = document.getElementById('mock-test-modal-footer');
    if (footer) {
      footer.innerHTML = `
        <button class="btn btn-outline modal-cancel-btn" onclick="document.getElementById('modal-mock-test-runner').classList.remove('active');">
          <i class="fas fa-times"></i> Close Review
        </button>
        <button class="btn btn-primary" onclick="startMockTest('${state.activeTest.id}')">
          <i class="fas fa-redo"></i> Retake Assessment
        </button>
      `;
    }

    // Scroll modal to top
    const modalBox = document.querySelector('#modal-mock-test-runner .modal-box');
    if (modalBox) modalBox.scrollTop = 0;

    showToast(`Assessment submitted! Score: ${res.score.percentage}%`, "success");

  } catch (err) {
    console.error("Submission error:", err);
    showToast("Error submitting assessment: " + err.message, "error");
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = `<i class="fas fa-check"></i> Submit Assessment`;
    }
  }
}

// ==========================================
// Tab 10: TPO Admin & Recruiter View
// ==========================================
async function loadTpoAdminTab() {
  const [statsRes, drivesRes] = await Promise.all([
    api.getPlacementStats(),
    api.getDrives()
  ]);

  if (statsRes.success) {
    renderTpoStats(statsRes.data);
  }
  if (drivesRes.success) {
    renderTpoDrivesTable(drivesRes.data);
  }
}

function renderTpoStats(stats) {
  const container = document.getElementById('tpo-stats-cards');
  if (!container) return;

  container.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:16px;margin-bottom:24px;">
      <div class="metric-card">
        <div class="metric-data">
          <div class="label">Total Placed Students</div>
          <div class="value">${stats.studentsPlaced} / ${stats.totalEligibleStudents}</div>
          <div class="subtext">${stats.placementPercentage}% Batch Placed</div>
        </div>
      </div>
      <div class="metric-card">
        <div class="metric-data">
          <div class="label">Highest Package</div>
          <div class="value" style="color:#fbbf24;">${stats.highestPackage}</div>
          <div class="subtext">${stats.highestCompany}</div>
        </div>
      </div>
      <div class="metric-card">
        <div class="metric-data">
          <div class="label">Average CTC</div>
          <div class="value" style="color:#60a5fa;">${stats.averagePackage}</div>
          <div class="subtext">Median: ${stats.medianPackage}</div>
        </div>
      </div>
      <div class="metric-card">
        <div class="metric-data">
          <div class="label">Total Offers Made</div>
          <div class="value" style="color:#34d399;">${stats.totalOffers}</div>
          <div class="subtext">${stats.superDreamTierOffers} Super Dream Offers</div>
        </div>
      </div>
    </div>
  `;
}

function renderTpoDrivesTable(drives) {
  const container = document.getElementById('tpo-drives-table-body');
  if (!container) return;

  container.innerHTML = drives.map(d => `
    <tr>
      <td style="font-weight:600;color:#fff;">${d.company}</td>
      <td>${d.role}</td>
      <td style="color:#fbbf24;font-weight:600;">${d.ctcPackage}</td>
      <td>Min ${d.eligibility.minCgpa} CGPA</td>
      <td>${d.deadline}</td>
      <td><span class="pill-badge pill-emerald">${d.status}</span></td>
    </tr>
  `).join('');
}

// ==========================================
// Modals Setup & Form Handlers
// ==========================================
function setupModals() {
  // Close modals when clicking close button or background overlay
  document.querySelectorAll('.modal-close-btn, .modal-cancel-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
      clearInterval(state.testTimer);
    });
  });

  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('active');
        clearInterval(state.testTimer);
      }
    });
  });

  // Add Project Form
  const addProjectForm = document.getElementById('form-add-project');
  if (addProjectForm) {
    addProjectForm.onsubmit = async (e) => {
      e.preventDefault();
      const payload = {
        title: document.getElementById('proj-input-title').value,
        category: document.getElementById('proj-input-category').value,
        tagline: document.getElementById('proj-input-tagline').value,
        technologies: document.getElementById('proj-input-tech').value,
        solution: document.getElementById('proj-input-solution').value,
        metrics: document.getElementById('proj-input-metrics').value,
        githubUrl: document.getElementById('proj-input-github').value,
        liveDemoUrl: document.getElementById('proj-input-live').value,
        featured: document.getElementById('proj-input-featured').checked
      };

      const res = await api.addProject(payload);
      if (res.success) {
        showToast(res.message, "success");
        document.getElementById('modal-add-project').classList.remove('active');
        addProjectForm.reset();
        loadProjectsTab();
      }
    };
  }

  // Post Teammate Request Form
  const postTeammateForm = document.getElementById('form-post-teammate');
  if (postTeammateForm) {
    postTeammateForm.onsubmit = async (e) => {
      e.preventDefault();
      const payload = {
        hackathonName: document.getElementById('team-input-hack').value,
        roleNeeded: document.getElementById('team-input-role').value,
        description: document.getElementById('team-input-desc').value,
        contact: document.getElementById('team-input-contact').value
      };
      const res = await api.postTeammateRequest(payload);
      if (res.success) {
        showToast(res.message, "success");
        document.getElementById('modal-post-teammate').classList.remove('active');
        postTeammateForm.reset();
        loadHackathonsTab();
      }
    };
  }

  // TPO Post Drive Form
  const postDriveForm = document.getElementById('form-tpo-post-drive');
  if (postDriveForm) {
    postDriveForm.onsubmit = async (e) => {
      e.preventDefault();
      const payload = {
        company: document.getElementById('drive-input-company').value,
        role: document.getElementById('drive-input-role').value,
        ctcPackage: document.getElementById('drive-input-ctc').value,
        minCgpa: document.getElementById('drive-input-cgpa').value,
        eligibleBranches: document.getElementById('drive-input-branches').value,
        deadline: document.getElementById('drive-input-deadline').value,
        description: document.getElementById('drive-input-desc').value
      };
      const res = await api.createDrive(payload);
      if (res.success) {
        showToast(res.message, "success");
        document.getElementById('modal-tpo-post-drive').classList.remove('active');
        postDriveForm.reset();
        loadTpoAdminTab();
      }
    };
  }

  // Scratchpad Runner
  const runCodeBtn = document.getElementById('practice-run-btn');
  if (runCodeBtn) {
    runCodeBtn.onclick = () => {
      const outputEl = document.getElementById('practice-code-output');
      outputEl.innerHTML = `<span style="color:#34d399;">✓ Test Case 1: PASSED (Input: [2, 7, 11, 15], Target: 9 => Output: [0, 1])</span>\n<span style="color:#34d399;">✓ Test Case 2: PASSED (Edge Case: Duplicate Values)</span>\n<span style="color:#60a5fa;">Memory: 41.2 MB | Runtime: 56ms (Beats 94.2% of submissions)</span>`;
      showToast("Code executed successfully against company test cases!", "success");
    };
  }

  // Student Login with Student Register ID
  const loginForm = document.getElementById('form-auth-login');
  if (loginForm) {
    loginForm.onsubmit = async (e) => {
      e.preventDefault();
      const regId = document.getElementById('login-input-regid').value.trim();
      const pass = document.getElementById('login-input-pass').value;
      const res = await api.loginStudent(regId, pass);
      if (res.success) {
        state.currentStudent = res.data;
        state.profile = { ...state.profile, ...res.data };
        renderSidebarProfile(res.data);
        showToast(`Welcome back, ${res.data.fullName} (ID: ${res.data.registerId})!`, "success");
        document.getElementById('modal-student-auth').classList.remove('active');
        switchTab('feed');
      } else {
        showToast(res.error || "Authentication failed", "error");
      }
    };
  }

  // Student Register New Student ID
  const regForm = document.getElementById('form-auth-register');
  if (regForm) {
    regForm.onsubmit = async (e) => {
      e.preventDefault();
      const payload = {
        registerId: document.getElementById('reg-input-id').value.trim(),
        fullName: document.getElementById('reg-input-name').value.trim(),
        department: document.getElementById('reg-input-dept').value,
        cgpa: document.getElementById('reg-input-cgpa').value,
        headline: document.getElementById('reg-input-headline').value.trim(),
        activeBacklogs: document.getElementById('reg-input-backlogs').value,
        password: document.getElementById('reg-input-pass').value
      };
      const res = await api.registerStudent(payload);
      if (res.success) {
        state.currentStudent = res.data;
        state.profile = { ...state.profile, ...res.data };
        renderSidebarProfile(res.data);
        showToast(`Registered successfully! Logged in with Student ID: ${res.data.registerId}`, "success");
        document.getElementById('modal-student-auth').classList.remove('active');
        regForm.reset();
        switchTab('network');
      } else {
        showToast(res.error || "Registration failed", "error");
      }
    };
  }

  // Create LinkedIn Campus Post Form
  const createPostForm = document.getElementById('form-create-feed-post');
  if (createPostForm) {
    createPostForm.onsubmit = async (e) => {
      e.preventDefault();
      const author = state.currentStudent || state.profile;
      const payload = {
        authorId: author ? author.id : "std-2026-cse-042",
        authorName: author ? author.fullName : "Sindhuja Reddy",
        authorRegisterId: author ? (author.registerId || author.rollNumber) : "22BCE1042",
        authorHeadline: author ? author.headline : "Final Year CSE @ NITTE • Class of 2026",
        authorAvatar: author ? author.avatar : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
        tag: document.getElementById('post-input-tag').value,
        content: document.getElementById('post-input-content').value.trim()
      };
      const res = await api.createFeedPost(payload);
      if (res.success) {
        showToast(res.message, "success");
        document.getElementById('modal-create-post').classList.remove('active');
        createPostForm.reset();
        loadFeedTab();
      }
    };
  }
}

// Utility HTML escape
function escapeHtml(string) {
  const entityMap = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  };
  return String(string).replace(/[&<>"']/g, s => entityMap[s]);
}
