const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET all available mock placement tests
router.get('/', (req, res) => {
  try {
    const tests = db.getMockTests().map(t => ({
      id: t.id,
      title: t.title,
      durationMins: t.durationMins,
      totalQuestions: t.questions.length,
      category: t.category,
      targetCompanies: t.targetCompanies
    }));
    res.json({ success: true, data: tests });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET specific mock test by ID (without leaking answers)
router.get('/:id', (req, res) => {
  try {
    const test = db.getMockTests().find(t => t.id === req.params.id);
    if (!test) {
      return res.status(404).json({ success: false, error: "Mock test not found" });
    }

    // Strip out correctIndex before returning to student
    const sanitizedQuestions = test.questions.map(q => ({
      id: q.id,
      question: q.question,
      options: q.options
    }));

    res.json({
      success: true,
      data: {
        id: test.id,
        title: test.title,
        durationMins: test.durationMins,
        totalQuestions: test.questions.length,
        category: test.category,
        questions: sanitizedQuestions
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST submit answers and get instant assessment result
router.post('/:id/submit', (req, res) => {
  try {
    const test = db.getMockTests().find(t => t.id === req.params.id);
    if (!test) {
      return res.status(404).json({ success: false, error: "Mock test not found" });
    }

    const { userAnswers } = req.body; // e.g. { "q1": 1, "q2": 2 }
    let correctCount = 0;
    const review = test.questions.map(q => {
      const selected = userAnswers ? userAnswers[q.id] : undefined;
      const isCorrect = selected === q.correctIndex;
      if (isCorrect) correctCount++;
      return {
        id: q.id,
        question: q.question,
        options: q.options,
        userSelected: selected !== undefined ? selected : null,
        correctIndex: q.correctIndex,
        isCorrect,
        explanation: q.explanation
      };
    });

    const percentage = Math.round((correctCount / test.questions.length) * 100);
    const passed = percentage >= 60;

    res.json({
      success: true,
      score: {
        total: test.questions.length,
        correct: correctCount,
        percentage,
        passed,
        performanceBadge: percentage >= 80 ? "Exemplary (Day 1 Ready)" : percentage >= 60 ? "Proficient" : "Needs Practice"
      },
      review
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
