/**
 * Rich Initial Dataset for PlaceHub - 4th Year Student Placement Portal
 */

const initialData = {
  profile: {
    id: "std-2026-cse-042",
    fullName: "Sindhuja Reddy",
    rollNumber: "22BCE1042",
    usn: "1RV22CS142",
    college: "National Institute of Technology & Engineering",
    department: "Computer Science & Engineering",
    degree: "B.Tech (Honors)",
    batch: "2022 - 2026",
    graduationYear: 2026,
    currentSemester: 8,
    cgpa: 8.84,
    activeBacklogs: 0,
    deadBacklogs: 0,
    tenthPercentage: 94.2,
    twelfthPercentage: 92.8,
    email: "sindhuja.reddy2026@nitte.edu.in",
    personalEmail: "sindhujareddy.dev@gmail.com",
    phone: "+91 98452 71830",
    location: "Bengaluru, Karnataka, India",
    bio: "Final-year Computer Science undergraduate passionate about Distributed Systems, Full-Stack Architecture, and AI-driven applications. Solved 450+ LeetCode problems with a 1820 contest rating. Seeking challenging Software Development Engineer (SDE) roles starting Summer 2026.",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
    portfolioUrl: "https://sindhujareddy.dev",
    githubUrl: "https://github.com/sindhujareddy",
    linkedinUrl: "https://linkedin.com/in/sindhuja-reddy-cs",
    leetcodeUrl: "https://leetcode.com/sindhuja_r",
    codeforcesUrl: "https://codeforces.com/profile/sindhu_coder",
    resumeFilename: "Sindhuja_Reddy_SDE_Resume_2026.pdf",
    atsScore: 92,
    atsFeedback: [
      { type: "positive", message: "Strong action verbs and quantifiable metrics across all 4th year projects." },
      { type: "positive", message: "Key CS fundamentals (DSA, System Design, Concurrency) well emphasized." },
      { type: "positive", message: "Clean single-page standard format optimized for Workday, Greenhouse & Taleo ATS." },
      { type: "tip", message: "Consider highlighting AWS certification in the top header summary section." }
    ],
    semesters: [
      { sem: "Sem 1", sgpa: 8.60, credits: 21 },
      { sem: "Sem 2", sgpa: 8.75, credits: 21 },
      { sem: "Sem 3", sgpa: 8.90, credits: 24 },
      { sem: "Sem 4", sgpa: 8.80, credits: 24 },
      { sem: "Sem 5", sgpa: 9.10, credits: 22 },
      { sem: "Sem 6", sgpa: 8.95, credits: 22 },
      { sem: "Sem 7", sgpa: 9.20, credits: 20 },
      { sem: "Sem 8 (Mid)", sgpa: 9.15, credits: 16 }
    ],
    certifications: [
      { title: "AWS Certified Cloud Practitioner (CLF-C02)", issuer: "Amazon Web Services", date: "Jan 2025", credentialId: "AWS-CP-89210", verifyUrl: "https://aws.amazon.com/verification" },
      { title: "Meta Certified Front-End Developer Specialization", issuer: "Meta / Coursera", date: "Oct 2024", credentialId: "META-FED-4389", verifyUrl: "https://coursera.org/verify" },
      { title: "Algorithmic Toolbox & Data Structures Honors", issuer: "UC San Diego", date: "Aug 2024", credentialId: "UCSD-ALGO-1902", verifyUrl: "https://coursera.org/verify" }
    ],
    codingStats: {
      leetcode: { solved: 468, rating: 1824, globalRanking: "Top 4.2%", easy: 165, medium: 245, hard: 58 },
      github: { repos: 28, stars: 142, contributionsYear: 840 },
      codeforces: { maxRating: 1542, rank: "Specialist" }
    }
  },

  interviewQuestions: [
    {
      id: "iq-001",
      company: "Google",
      role: "Software Development Engineer (L3)",
      round: "Technical Round 1 (DSA & Problem Solving)",
      category: "Data Structures & Algorithms",
      topic: "Graphs & BFS/DFS",
      difficulty: "Hard",
      frequency: "High (Asked in 2025-26 Campus Drives)",
      title: "Word Ladder II - Shortest Transformation Sequences",
      question: "Given two words, beginWord and endWord, and a dictionary wordList, return all the shortest transformation sequences from beginWord to endWord, such that every adjacent pair differs by only one letter.",
      keyConcepts: ["Bidirectional BFS", "Backtracking / DFS", "Adjacency Hash Map"],
      timeComplexity: "O(N * 26 * L + α)",
      spaceComplexity: "O(N * L)",
      hints: [
        "Use BFS to find the shortest distance from beginWord to all reachable words and build a graph of parent pointers.",
        "Perform DFS/Backtracking starting from endWord using the shortest path graph to construct all optimal paths."
      ],
      solutionSnippet: `// Bidirectional BFS + DFS Backtracking in C++ / Java
unordered_map<string, vector<string>> adj;
unordered_map<string, int> dist;
// Step 1: BFS to calculate minimum distance from beginWord
// Step 2: DFS from beginWord to endWord following dist[neighbor] == dist[curr] + 1`,
      explanation: "By decoupling the distance calculation (via BFS) from the path reconstruction (via DFS), we avoid exponential branching and only traverse edges guaranteed to form minimal paths.",
      solved: true
    },
    {
      id: "iq-002",
      company: "Google",
      role: "Software Development Engineer (L3)",
      round: "Technical Round 2 (System Design & Concurrency)",
      category: "System Design",
      topic: "Distributed Systems & Caching",
      difficulty: "Medium",
      frequency: "Very High",
      title: "Design a High-Throughput Distributed Rate Limiter",
      question: "Design an API Rate Limiter capable of handling 500,000 requests per second across multiple regional microservices. Ensure fairness, low latency (< 2ms overhead), and resilience against Redis cluster failures.",
      keyConcepts: ["Token Bucket Algorithm", "Sliding Window Counter", "Redis Lua Scripting", "Distributed Consensus"],
      timeComplexity: "O(1) per check",
      spaceComplexity: "O(Active Users * Windows)",
      hints: [
        "Compare Token Bucket, Leaky Bucket, and Sliding Window Log algorithms.",
        "Use atomic Redis Lua scripts to prevent race conditions during concurrent requests from the same API token."
      ],
      solutionSnippet: `// Redis Lua Script for Sliding Window Rate Limiting
local key = KEYS[1]
local now = tonumber(ARGV[1])
local window = tonumber(ARGV[2])
local limit = tonumber(ARGV[3])
local clearBefore = now - window

redis.call('ZREMRANGEBYSCORE', key, 0, clearBefore)
local currentCount = redis.call('ZCARD', key)
if currentCount < limit then
    redis.call('ZADD', key, now, now)
    redis.call('EXPIRE', key, window / 1000)
    return 1
else
    return 0
end`,
      explanation: "Sliding window logs or sliding window counters implemented using Redis Sorted Sets (ZSET) guarantee strict compliance without edge-of-window spikes, with atomic Lua script execution.",
      solved: true
    },
    {
      id: "iq-003",
      company: "Amazon",
      role: "SDE-1 (Campus Placement 2026)",
      round: "Online Assessment & Technical Round",
      category: "Data Structures & Algorithms",
      topic: "Dynamic Programming & Monotonic Queue",
      difficulty: "Medium",
      frequency: "Top Amazon Question",
      title: "Optimization of Amazon Warehouse Fulfillment Route",
      question: "Given an integer array nums and an integer k, return the maximum sum of a non-empty subsequence such that for every two consecutive integers in the subsequence, nums[i] and nums[j], with i < j, the condition j - i <= k is satisfied.",
      keyConcepts: ["Sliding Window Maximum", "Monotonic Deque", "Dynamic Programming"],
      timeComplexity: "O(N)",
      spaceComplexity: "O(N)",
      hints: [
        "Notice that dp[i] = nums[i] + max(0, max_{i-k <= j < i}(dp[j])).",
        "A standard search over the last k elements takes O(k), making total runtime O(Nk). How can you find the sliding window max in O(1)?"
      ],
      solutionSnippet: `def constrainedSubsetSum(nums, k):
    from collections import deque
    dp = nums[:]
    dq = deque([0]) # stores indices with decreasing dp values
    for i in range(1, len(nums)):
        while dq and dq[0] < i - k:
            dq.popleft()
        dp[i] = max(dp[i], nums[i] + dp[dq[0]])
        while dq and dp[dq[-1]] <= dp[i]:
            dq.pop()
        dq.append(i)
    return max(dp)`,
      explanation: "A monotonic decreasing deque keeps the indices of the largest DP values within the sliding window of size k in O(1) amortized time per element.",
      solved: true
    },
    {
      id: "iq-004",
      company: "Amazon",
      role: "SDE-1",
      round: "Bar Raiser / Behavioral",
      category: "Behavioral & Leadership",
      topic: "Amazon Leadership Principles",
      difficulty: "Medium",
      frequency: "Mandatory in Every Amazon Interview",
      title: "Customer Obsession & Disagree and Commit in 4th Year Capstone",
      question: "Describe a situation during your engineering project or internship where you had a fundamental technical disagreement with your team lead or peer. How did you handle it and what was the outcome?",
      keyConcepts: ["STAR Method (Situation, Task, Action, Result)", "Data-driven negotiation", "Disagree and Commit"],
      timeComplexity: "Structured 3-minute response",
      spaceComplexity: "Clear measurable impact",
      hints: [
        "Do not say 'I convinced them I was right'. Show that you evaluated both options with benchmarks, prototypes, or user feedback.",
        "Emphasize the project deadline, business trade-offs, and how you united the team once the decision was made."
      ],
      solutionSnippet: `Structure:
1. Situation: During our 4th-year capstone, teammate wanted MongoDB while I proposed PostgreSQL.
2. Task: We needed to decide within 48 hours to meet the college sprint milestone.
3. Action: I built an automated benchmark measuring relational joins vs embedded documents on our schema with 100k test records.
4. Result: Showed 3.5x lower memory usage and ACID guarantees for user transactions. Team adopted Postgres seamlessly.`,
      explanation: "Amazon places equal weight on leadership principles. Always use data and customer impact rather than emotional opinions.",
      solved: false
    },
    {
      id: "iq-005",
      company: "Microsoft",
      role: "Software Engineer - Full Time",
      round: "Technical Round 1",
      category: "Data Structures & Algorithms",
      topic: "Binary Trees & Lowest Common Ancestor",
      difficulty: "Medium",
      frequency: "Very High",
      title: "Lowest Common Ancestor in Binary Tree with Parent Pointers & Without",
      question: "Given a binary tree, find the lowest common ancestor (LCA) of two given nodes in the tree without extra space, and explain the trade-offs when nodes have a direct reference to their parent.",
      keyConcepts: ["Post-order Traversal", "Two Pointers (like linked list intersection)", "Recursion Stack"],
      timeComplexity: "O(N) without parent, O(h) with parent",
      spaceComplexity: "O(h) recursive call stack",
      hints: [
        "If you have parent pointers, the problem reduces to finding the intersection of two linked lists.",
        "Without parent pointers, recursively search left and right subtrees. If both return non-null, the current node is the LCA."
      ],
      solutionSnippet: `TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
    if (!root || root == p || root == q) return root;
    TreeNode* left = lowestCommonAncestor(root->left, p, q);
    TreeNode* right = lowestCommonAncestor(root->right, p, q);
    if (left && right) return root;
    return left ? left : right;
}`,
      explanation: "Post-order bottom-up search bubbles up matches from leaf nodes. The first node where both subtrees report non-null results is the minimal ancestor.",
      solved: true
    },
    {
      id: "iq-006",
      company: "Microsoft",
      role: "Software Engineer",
      round: "Technical Round 2",
      category: "Operating Systems & Networking",
      topic: "Concurrency & Deadlocks",
      difficulty: "Medium",
      frequency: "High",
      title: "Coffman Deadlock Conditions & Mutex vs Spinlock in Multi-core Systems",
      question: "Explain the four Coffman conditions necessary for a deadlock. In a multicore kernel or high-performance C++ server, when would you choose a Spinlock over a Mutex?",
      keyConcepts: ["Mutual Exclusion", "Hold and Wait", "No Preemption", "Circular Wait", "Context Switch Overhead"],
      timeComplexity: "N/A",
      spaceComplexity: "N/A",
      hints: [
        "A mutex puts the thread to sleep, causing two context switches (sleep and wake).",
        "A spinlock busy-waits in a CPU loop. If the lock hold duration is less than the cost of two context switches (typically a few microseconds), spinlocks are faster."
      ],
      solutionSnippet: `Four Coffman Conditions:
1. Mutual Exclusion: Resources cannot be shared simultaneously.
2. Hold & Wait: Process holds one resource while requesting another.
3. No Preemption: Resources cannot be forcibly seized.
4. Circular Wait: A closed chain of processes each waiting for resource held by next.

Rule of Thumb: Spinlock is optimal when lock hold time < 2 * context switch latency and thread is not running on single CPU core.`,
      explanation: "Understanding OS internals is essential for Microsoft, Qualcomm, and Cisco engineering interviews.",
      solved: true
    },
    {
      id: "iq-007",
      company: "Goldman Sachs",
      role: "Engineering Analyst (Quantitative & Systems)",
      round: "Technical Round 1 & 2",
      category: "Data Structures & Algorithms",
      topic: "Heaps & Dynamic Medians",
      difficulty: "Hard",
      frequency: "Very High",
      title: "Continuous Running Median of High-Frequency Stock Ticker Data",
      question: "Design a data structure that receives a continuous stream of real-time stock prices and supports returning the median price at any moment in O(1) time.",
      keyConcepts: ["Two Heaps (Max-Heap & Min-Heap)", "Balancing Heap Invariants", "O(log N) Insert"],
      timeComplexity: "O(log N) insert, O(1) findMedian",
      spaceComplexity: "O(N)",
      hints: [
        "Divide numbers into two halves: the smaller half in a max-heap, and the larger half in a min-heap.",
        "Ensure the size difference between the two heaps never exceeds 1."
      ],
      solutionSnippet: `class MedianFinder {
    PriorityQueue<Integer> small = new PriorityQueue<>(Collections.reverseOrder()); // max-heap
    PriorityQueue<Integer> large = new PriorityQueue<>(); // min-heap
    
    public void addNum(int num) {
        small.offer(num);
        large.offer(small.poll());
        if (small.size() < large.size()) {
            small.offer(large.poll());
        }
    }
    public double findMedian() {
        return small.size() > large.size() ? small.peek() : (small.peek() + large.peek()) / 2.0;
    }
}`,
      explanation: "Balancing two priority queues allows instant access to the boundary elements dividing the lower and upper halves of sorted numbers.",
      solved: false
    },
    {
      id: "iq-008",
      company: "TCS Digital / Prime",
      role: "Digital & Prime Cadre (₹9.0 LPA)",
      round: "Advanced Coding Round",
      category: "Data Structures & Algorithms",
      topic: "Strings & Number Theory",
      difficulty: "Medium",
      frequency: "Asked in 2025 TCS NQT",
      title: "Minimum Swaps to Make Palindrome & Prime Frequency Analysis",
      question: "Given a string s, find the minimum number of adjacent swaps needed to turn it into a palindrome. If no palindrome can be formed, return -1.",
      keyConcepts: ["Two Pointers", "Greedy Swap", "Frequency Parity"],
      timeComplexity: "O(N^2)",
      spaceComplexity: "O(1)",
      hints: [
        "First check if at most one character has an odd frequency.",
        "Use two pointers from both ends; find the matching character closest to the right and greedily swap it into position."
      ],
      solutionSnippet: `// Greedily match leftmost char with the rightmost identical char
int left = 0, right = n - 1, swaps = 0;
while (left < right) {
    int k = right;
    while (k > left && s[k] != s[left]) k--;
    if (k == left) {
        // odd character, push to middle
        swap(s[left], s[left + 1]);
        swaps++;
        continue;
    }
    for (int j = k; j < right; j++) {
        swap(s[j], s[j + 1]);
        swaps++;
    }
    left++; right--;
}`,
      explanation: "Greedy matching ensures each matched pair is positioned with minimal adjacent shifts.",
      solved: true
    },
    {
      id: "iq-009",
      company: "Infosys",
      role: "Specialist Programmer (SP - ₹9.5 LPA)",
      round: "SP HackWithInfy / Coding Round",
      category: "Data Structures & Algorithms",
      topic: "Segment Trees & Range Queries",
      difficulty: "Hard",
      frequency: "High for SP Role",
      title: "Range GCD and Update Query on Large Sequences",
      question: "Given an array of size 10^5, perform 10^5 operations of two types: update value at index i to val, and find the Greatest Common Divisor (GCD) in range [L, R].",
      keyConcepts: ["Segment Tree", "Euclidean GCD Algorithm", "Point Updates"],
      timeComplexity: "O(log N * log(max_val)) per query",
      spaceComplexity: "O(4N)",
      hints: [
        "Since GCD is associative: gcd(a, gcd(b, c)) = gcd(gcd(a, b), c), it fits perfectly inside a segment tree.",
        "Build the tree in O(N log(val)) and update leaf nodes in O(log N)."
      ],
      solutionSnippet: `int tree[4 * MAXN];
int gcd(int a, int b) { return b == 0 ? a : gcd(b, a % b); }

void build(int node, int start, int end) {
    if (start == end) { tree[node] = arr[start]; return; }
    int mid = (start + end) / 2;
    build(2*node, start, mid);
    build(2*node+1, mid+1, end);
    tree[node] = gcd(tree[2*node], tree[2*node+1]);
}`,
      explanation: "Segment trees enable logarithmic updates and queries over any associative binary operator like GCD, sum, min, or max.",
      solved: false
    },
    {
      id: "iq-010",
      company: "Cisco",
      role: "Software Consulting / Core Network Engineer",
      round: "Technical Interview",
      category: "Computer Networks & OS",
      topic: "TCP Handshake & Subnetting",
      difficulty: "Medium",
      frequency: "Extremely Frequent",
      title: "Deep Dive into TCP 3-Way Handshake, TIME_WAIT State & CIDR Routing",
      question: "Explain the TCP 3-way handshake with SYN, SYN-ACK, ACK and Sequence Numbers. Why does the client linger in TIME_WAIT state for 2*MSL (Maximum Segment Lifetime)?",
      keyConcepts: ["TCP Flags", "Sequence & Acknowledgment Math", "TIME_WAIT vs CLOSE_WAIT", "Delayed Duplicates"],
      timeComplexity: "Conceptual",
      spaceComplexity: "Conceptual",
      hints: [
        "What happens if the final ACK sent by the client is lost in transit?",
        "How does TIME_WAIT prevent duplicate packets from an old connection reincarnating in a new connection with the exact same port tuple?"
      ],
      solutionSnippet: `Key Reasons for TIME_WAIT:
1. Reliable Connection Termination: If final ACK from client is dropped, server retransmits FIN. Client must be alive to resend ACK.
2. Quelling Delayed Packets: Prevents stale segments floating in routers from colliding with a new connection using identical IP:Port combination.`,
      explanation: "A standard question across Cisco, Arista, Juniper, and Akamai networking campus drives.",
      solved: true
    },
    {
      id: "iq-011",
      company: "Adobe",
      role: "Member Technical Staff (MTS-1)",
      round: "Technical Round 1",
      category: "Data Structures & Algorithms",
      topic: "Trie & String Autocomplete",
      difficulty: "Medium",
      frequency: "Top Adobe Question",
      title: "Design Search Autocomplete System with Frequency Ranking",
      question: "Design a search autocomplete system that recommends top 3 historical search sentences having the same prefix as the currently typed query, sorted by search frequency.",
      keyConcepts: ["Trie with Hash Map", "Min-Heap / Sorting", "Prefix Trees"],
      timeComplexity: "O(P + N log 3) where P is prefix length",
      spaceComplexity: "O(Total Characters)",
      hints: [
        "Store sentence frequencies at the terminal nodes of the Trie.",
        "To optimize lookup, cache top-3 suggestions directly at each intermediate prefix node!"
      ],
      solutionSnippet: `class TrieNode {
    Map<Character, TrieNode> children = new HashMap<>();
    Map<String, Integer> counts = new HashMap<>(); // sentence -> frequency
    boolean isEnd = false;
}`,
      explanation: "Caching top recommendations at each node reduces query time from O(Subtree) to O(1) at the expense of slight write-time overhead.",
      solved: true
    },
    {
      id: "iq-012",
      company: "Meta",
      role: "Software Engineer - Campus",
      round: "Technical Round",
      category: "Data Structures & Algorithms",
      topic: "Intervals & Greedy",
      difficulty: "Medium",
      frequency: "High",
      title: "Meeting Rooms II - Minimum Conference Rooms Required",
      question: "Given an array of meeting time intervals intervals where intervals[i] = [start_i, end_i], return the minimum number of conference rooms required.",
      keyConcepts: ["Chronological Ordering / Sweep-Line", "Min-Heap of End Times", "Two Arrays"],
      timeComplexity: "O(N log N)",
      spaceComplexity: "O(N)",
      hints: [
        "Separate start times and end times into two sorted arrays.",
        "Iterate through start times: if the earliest ending meeting has already finished, you can reuse that room; otherwise allocate a new room."
      ],
      solutionSnippet: `def minMeetingRooms(intervals):
    starts = sorted([i[0] for i in intervals])
    ends = sorted([i[1] for i in intervals])
    rooms = 0
    end_ptr = 0
    for s in starts:
        if s < ends[end_ptr]:
            rooms += 1
        else:
            end_ptr += 1
    return rooms`,
      explanation: "Sweep-line technique gives optimal linear space and clean O(N log N) sorting time.",
      solved: true
    }
  ],

  projects: [
    {
      id: "proj-001",
      title: "SentinelReview - AI Automated Code Review & Security Scanner",
      category: "Final Year Capstone Project",
      tagline: "High-throughput static code analysis bot powered by AST parsing and LLM security audits.",
      featured: true,
      technologies: ["Python", "FastAPI", "Docker", "Gemini 1.5 Pro", "Tree-Sitter", "PostgreSQL", "React", "TailwindCSS"],
      problemStatement: "Manual code reviews in large engineering teams introduce 36-hour PR latency bottlenecks and frequently overlook SQL injections and memory leaks.",
      solution: "Engineered a distributed GitHub webhook bot that parses abstract syntax trees (AST) to flag OWASP vulnerabilities, calculate cyclomatic complexity, and generate context-aware patch suggestions.",
      metrics: "Reduced PR review turnaround by 65%; flagged 14 security vulnerabilities across 120+ open source repositories.",
      githubUrl: "https://github.com/sindhujareddy/sentinel-review-ai",
      liveDemoUrl: "https://sentinel-review.fly.dev",
      role: "Lead Architect & Backend Engineer",
      teamSize: 3,
      starsCount: 142
    },
    {
      id: "proj-002",
      title: "PulseMetrics - Distributed Telemetry & Latency Profiler",
      category: "Systems & Cloud Infrastructure",
      tagline: "Sub-millisecond metric ingestion pipeline processing 25,000 events/second.",
      featured: true,
      technologies: ["Go (Golang)", "Kafka", "TimescaleDB", "Redis", "Docker", "Grafana", "gRPC"],
      problemStatement: "Cloud microservice monitoring tools generate prohibitive egress fees and struggle with real-time tail latency (p99) detection during traffic spikes.",
      solution: "Designed a lightweight Go daemon agent that streams ring-buffered performance metrics through Apache Kafka partitions into TimescaleDB with automated anomaly alerts.",
      metrics: "Sustained 25,000 metrics/sec at p99 latency < 4.2ms with only 48MB memory footprint.",
      githubUrl: "https://github.com/sindhujareddy/pulse-metrics-engine",
      liveDemoUrl: "https://pulse-metrics-demo.internal",
      role: "Solo Developer",
      teamSize: 1,
      starsCount: 89
    },
    {
      id: "proj-003",
      title: "CampusSphere - 4th Year Placement & Peer Mentorship Platform",
      category: "Full-Stack Web Application",
      tagline: "Collaborative portal connecting 1,200+ final year engineering students with alumni mentors.",
      featured: false,
      technologies: ["React 18", "Node.js", "Express", "MongoDB", "Socket.io", "TailwindCSS"],
      problemStatement: "Students lack unified campus-specific interview archives, verified senior referral channels, and live mock interview coordination.",
      solution: "Built a campus-exclusive network with real-time peer coding boards, encrypted referral chats, and automated TPO drive notifications.",
      metrics: "Adopted by 1,200+ students in College placement season with 4.8/5 satisfaction rating.",
      githubUrl: "https://github.com/sindhujareddy/campus-sphere-portal",
      liveDemoUrl: "https://campussphere.nitte.edu.in",
      role: "Full-Stack Developer",
      teamSize: 2,
      starsCount: 65
    },
    {
      id: "proj-004",
      title: "MediTrack - Decentralized Medicine Supply Chain Verifier",
      category: "Blockchain & Smart Contracts",
      tagline: "Smart India Hackathon Finalist project preventing counterfeit pharmaceutical shipments.",
      featured: false,
      technologies: ["Solidity", "Ethereum", "Ethers.js", "IPFS", "Hardhat", "React"],
      problemStatement: "Over 10% of medical supplies in developing nations are counterfeit, resulting in critical healthcare risks.",
      solution: "Implemented an ERC-721 tokenized batch tracking protocol with tamper-proof QR verification on IPFS and Polygon testnet.",
      metrics: "Smart India Hackathon 2024 Top 5 Finalist out of 8,500+ nationwide team submissions.",
      githubUrl: "https://github.com/sindhujareddy/meditrack-supply-chain",
      liveDemoUrl: "https://meditrack-verify.web.app",
      role: "Smart Contract Developer",
      teamSize: 4,
      starsCount: 94
    }
  ],

  skills: {
    categories: [
      {
        name: "Programming Languages",
        skills: [
          { name: "Java (Core & Advanced)", level: "Advanced", proficiency: 92, verified: true },
          { name: "C++ (STL & OOP)", level: "Advanced", proficiency: 90, verified: true },
          { name: "Python 3", level: "Advanced", proficiency: 88, verified: true },
          { name: "JavaScript (ES6+)", level: "Advanced", proficiency: 86, verified: true },
          { name: "TypeScript", level: "Intermediate", proficiency: 80, verified: true },
          { name: "SQL", level: "Advanced", proficiency: 90, verified: true }
        ]
      },
      {
        name: "Data Structures & Core CS",
        skills: [
          { name: "Data Structures & Algorithms", level: "Expert", proficiency: 94, verified: true },
          { name: "Object Oriented Design (LLD)", level: "Advanced", proficiency: 88, verified: true },
          { name: "System Design Basics (HLD)", level: "Intermediate", proficiency: 82, verified: true },
          { name: "Operating Systems (Concurrency/Paging)", level: "Advanced", proficiency: 88, verified: true },
          { name: "Database Management (RDBMS & NoSQL)", level: "Advanced", proficiency: 90, verified: true },
          { name: "Computer Networks (TCP/IP, HTTP/3)", level: "Advanced", proficiency: 86, verified: true }
        ]
      },
      {
        name: "Frameworks & Full-Stack",
        skills: [
          { name: "React.js & Next.js", level: "Advanced", proficiency: 88, verified: true },
          { name: "Node.js & Express", level: "Advanced", proficiency: 86, verified: true },
          { name: "Spring Boot Basics", level: "Intermediate", proficiency: 75, verified: false },
          { name: "FastAPI / Flask", level: "Advanced", proficiency: 85, verified: true },
          { name: "TailwindCSS & UI Frameworks", level: "Expert", proficiency: 95, verified: true },
          { name: "REST & GraphQL APIs", level: "Advanced", proficiency: 90, verified: true }
        ]
      },
      {
        name: "Cloud, DevOps & Tools",
        skills: [
          { name: "Git & GitHub Actions (CI/CD)", level: "Advanced", proficiency: 92, verified: true },
          { name: "Docker & Containerization", level: "Intermediate", proficiency: 82, verified: true },
          { name: "AWS (S3, EC2, Lambda, RDS)", level: "Intermediate", proficiency: 78, verified: true },
          { name: "PostgreSQL & Redis Caching", level: "Advanced", proficiency: 88, verified: true },
          { name: "Linux / Shell Scripting", level: "Advanced", proficiency: 85, verified: true }
        ]
      },
      {
        name: "Professional & Soft Skills",
        skills: [
          { name: "Analytical Problem Solving", level: "Expert", proficiency: 95, verified: true },
          { name: "Technical Communication", level: "Advanced", proficiency: 90, verified: true },
          { name: "Cross-Functional Collaboration", level: "Advanced", proficiency: 88, verified: true },
          { name: "STAR Method Behavioral Storytelling", level: "Advanced", proficiency: 86, verified: true }
        ]
      }
    ],
    dreamCompanyBenchmarks: {
      "Google": { match: 91, missing: ["Distributed Spanner internals", "Advanced DP on Trees"] },
      "Amazon": { match: 94, missing: ["Deep AWS DynamoDB modeling", "Amazon LPs articulation"] },
      "Microsoft": { match: 92, missing: ["C# / .NET Core basics", "Azure Cloud Services"] },
      "Goldman Sachs": { match: 86, missing: ["Multithreading synchronization deep dive", "Financial math"] },
      "Cisco": { match: 89, missing: ["Advanced BGP/OSPF Routing", "Socket programming in C"] }
    }
  },

  drives: [
    {
      id: "drv-001",
      company: "Google India",
      role: "Software Development Engineer (SWE) - University Graduate 2026",
      logo: "https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg",
      ctcPackage: "₹38.5 LPA (Base: ₹18.0L + Bonus + RSUs)",
      stipend: "₹1,15,000 / month (Pre-placement intern)",
      type: "Full-Time + 6M Internship",
      category: "Super Dream (> ₹25 LPA)",
      location: "Bengaluru / Hyderabad",
      deadline: "2026-11-20",
      driveDate: "2026-11-28",
      status: "Open - Applications Live",
      eligibility: {
        minCgpa: 8.0,
        allowedBacklogs: 0,
        eligibleBranches: ["CSE", "IT", "ECE", "AI & DS"],
        min10th: 80.0,
        min12th: 80.0
      },
      selectionProcess: [
        { round: "Round 1", name: "Google Online Challenge (GOC)", duration: "90 Mins", format: "2 LeetCode Medium/Hard DSA Questions" },
        { round: "Round 2", name: "Virtual Technical Interview 1", duration: "45 Mins", format: "Algorithms & Complex Data Structures" },
        { round: "Round 3", name: "Virtual Technical Interview 2", duration: "45 Mins", format: "System Design / Scalability / Problem Solving" },
        { round: "Round 4", name: "Googleyness & Leadership", duration: "45 Mins", format: "Behavioral & Cultural Alignment" }
      ],
      description: "Join Google engineering to develop large-scale software solutions affecting billions of global users. Work on Search, Cloud, Android, or YouTube infrastructure.",
      requirements: [
        "Strong foundation in Algorithms, Data Structures, and Software Design.",
        "Proficiency in Java, C++, Python, or Go.",
        "Demonstrated ability to write clean, testable, and maintainable production code.",
        "Excellent analytical and collaborative communication skills."
      ],
      applied: true,
      applicationStatus: "Shortlisted for Online Assessment",
      applicationDate: "2026-11-01"
    },
    {
      id: "drv-002",
      company: "Amazon India",
      role: "Software Development Engineer - 1 (SDE-1)",
      logo: "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg",
      ctcPackage: "₹32.0 LPA (Base: ₹16.5L + Sign-on: ₹6L + RSUs)",
      stipend: "₹85,000 / month",
      type: "Full-Time Offer",
      category: "Super Dream (> ₹25 LPA)",
      location: "Bengaluru / Hyderabad / Chennai",
      deadline: "2026-11-18",
      driveDate: "2026-11-25",
      status: "Open - Closing Soon",
      eligibility: {
        minCgpa: 7.5,
        allowedBacklogs: 0,
        eligibleBranches: ["CSE", "IT", "ECE", "EEE", "Mech"],
        min10th: 75.0,
        min12th: 75.0
      },
      selectionProcess: [
        { round: "Round 1", name: "Amazon OA on HackerRank", duration: "105 Mins", format: "2 Coding Qs + Work Style Assessment" },
        { round: "Round 2", name: "Technical Round 1", duration: "60 Mins", format: "DSA + Amazon Leadership Principles" },
        { round: "Round 3", name: "Technical Round 2", duration: "60 Mins", format: "Object Oriented Design & Concurrency" },
        { round: "Round 4", name: "Bar Raiser Interview", duration: "60 Mins", format: "Deep Behavioral & Complex Problem Solving" }
      ],
      description: "Build cutting-edge distributed services powering Amazon Retail, Prime Video, and AWS Cloud services.",
      requirements: [
        "Expertise with OOP in Java, C++, or Python.",
        "Deep understanding of Big-O analysis and memory constraints.",
        "Familiarity with Amazon 16 Leadership Principles."
      ],
      applied: true,
      applicationStatus: "OA Cleared - Technical Round Scheduled",
      applicationDate: "2026-10-28"
    },
    {
      id: "drv-003",
      company: "Microsoft",
      role: "Software Engineer (Full-Time 2026 Batch)",
      logo: "https://upload.wikimedia.org/wikipedia/commons/9/96/Microsoft_logo_%282012%29.svg",
      ctcPackage: "₹42.0 LPA (Base: ₹18.0L + Stock: ₹16L + Benefits)",
      stipend: "₹1,00,000 / month",
      type: "Full-Time Offer",
      category: "Super Dream (> ₹25 LPA)",
      location: "Bengaluru / Hyderabad / Noida",
      deadline: "2026-11-22",
      driveDate: "2026-11-30",
      status: "Open - Applications Live",
      eligibility: {
        minCgpa: 8.0,
        allowedBacklogs: 0,
        eligibleBranches: ["CSE", "IT", "ECE"],
        min10th: 80.0,
        min12th: 80.0
      },
      selectionProcess: [
        { round: "Round 1", name: "Codility Online Assessment", duration: "75 Mins", format: "3 Problem Solving Questions" },
        { round: "Round 2", name: "Technical Interview 1", duration: "45 Mins", format: "Data Structures & Code Correctness" },
        { round: "Round 3", name: "Technical Interview 2", duration: "45 Mins", format: "System Architecture, OS & Concurrency" },
        { round: "Round 4", name: "Director / AA Round", duration: "45 Mins", format: "Culture, Vision & Growth Mindset" }
      ],
      description: "Empower every person and organization on the planet to achieve more with Microsoft Azure, Office 365, and AI Copilots.",
      requirements: [
        "Passionate problem solver with solid CS fundamentals.",
        "Strong debugging skills and understanding of systems code."
      ],
      applied: false,
      applicationStatus: "Not Applied",
      applicationDate: null
    },
    {
      id: "drv-004",
      company: "Goldman Sachs",
      role: "Engineering Analyst - Quantitative Architecture & Platforms",
      logo: "https://upload.wikimedia.org/wikipedia/commons/6/61/Goldman_Sachs.svg",
      ctcPackage: "₹28.0 LPA (Base: ₹18.0L + Performance Bonus)",
      stipend: "₹90,000 / month",
      type: "Full-Time + 6M Intern",
      category: "Super Dream (> ₹25 LPA)",
      location: "Bengaluru",
      deadline: "2026-11-24",
      driveDate: "2026-12-04",
      status: "Open - Applications Live",
      eligibility: {
        minCgpa: 8.0,
        allowedBacklogs: 0,
        eligibleBranches: ["CSE", "IT", "ECE", "EEE"],
        min10th: 75.0,
        min12th: 75.0
      },
      selectionProcess: [
        { round: "Round 1", name: "Aptitude & Coding Assessment", duration: "105 Mins", format: "Math/Quant + 2 Coding + CS MCQs" },
        { round: "Round 2", name: "Technical Interview 1", duration: "60 Mins", format: "DSA, Heaps, Trees & Complexity" },
        { round: "Round 3", name: "Technical Interview 2", duration: "60 Mins", format: "Low-level system architecture & Threads" }
      ],
      description: "Build robust, low-latency financial settlement and algorithmic trading systems handling trillions of dollars daily.",
      requirements: [
        "Exceptional algorithmic problem-solving and mathematical aptitude.",
        "Proficiency in modern Java, C++, or Python with concurrency models."
      ],
      applied: false,
      applicationStatus: "Not Applied",
      applicationDate: null
    },
    {
      id: "drv-005",
      company: "Cisco Systems",
      role: "Software Engineer - Enterprise Networking & Cloud Security",
      logo: "https://upload.wikimedia.org/wikipedia/commons/0/08/Cisco_logo_blue_2016.svg",
      ctcPackage: "₹24.5 LPA (Base: ₹15.0L + Joining Bonus: ₹3L + Stocks)",
      stipend: "₹65,000 / month",
      type: "Full-Time Offer",
      category: "Dream Tier (₹10 - ₹25 LPA)",
      location: "Bengaluru",
      deadline: "2026-11-15",
      driveDate: "2026-11-21",
      status: "Open - Closing Very Soon",
      eligibility: {
        minCgpa: 7.5,
        allowedBacklogs: 0,
        eligibleBranches: ["CSE", "IT", "ECE", "Telecom", "EEE"],
        min10th: 70.0,
        min12th: 70.0
      },
      selectionProcess: [
        { round: "Round 1", name: "Online Aptitude & Code Test", duration: "90 Mins", format: "Networks + OS + 2 Coding Qs" },
        { round: "Round 2", name: "Technical Interview 1", duration: "45 Mins", format: "Networking Protocols, Linux, C/C++/Java" },
        { round: "Round 3", name: "Managerial & HR", duration: "30 Mins", format: "Project discussion & Culture Fit" }
      ],
      description: "Shape the future of internet routing, software-defined WAN (SD-WAN), and zero-trust cloud security platforms.",
      requirements: [
        "In-depth grasp of TCP/IP, Routing Protocols, and Linux Internals.",
        "Hands-on coding in C, C++, Python, or Java."
      ],
      applied: true,
      applicationStatus: "Offer Extended - Under Review",
      applicationDate: "2026-10-15"
    },
    {
      id: "drv-006",
      company: "Adobe",
      role: "Member Technical Staff - 1 (MTS-1)",
      logo: "https://upload.wikimedia.org/wikipedia/commons/8/8d/Adobe_Corporate_Logo.png",
      ctcPackage: "₹34.0 LPA (Base: ₹17.5L + RSUs + Benefits)",
      stipend: "₹80,000 / month",
      type: "Full-Time Offer",
      category: "Super Dream (> ₹25 LPA)",
      location: "Noida / Bengaluru",
      deadline: "2026-11-25",
      driveDate: "2026-12-05",
      status: "Open - Applications Live",
      eligibility: {
        minCgpa: 8.2,
        allowedBacklogs: 0,
        eligibleBranches: ["CSE", "IT"],
        min10th: 80.0,
        min12th: 80.0
      },
      selectionProcess: [
        { round: "Round 1", name: "HackerRank OA", duration: "90 Mins", format: "3 Advanced DSA Questions" },
        { round: "Round 2", name: "Technical Round 1", duration: "60 Mins", format: "Data Structures, Trie, Strings & DP" },
        { round: "Round 3", name: "Technical Round 2", duration: "60 Mins", format: "Graphics / Web Engine / High Performance" }
      ],
      description: "Engineer world-class creative tools like Photoshop, Illustrator, Premiere Pro, and Adobe Firefly Generative AI.",
      requirements: [
        "Superior knowledge of Data Structures and Algorithms.",
        "Demonstrated mastery of C++ or Modern Web Architectures."
      ],
      applied: false,
      applicationStatus: "Not Applied",
      applicationDate: null
    },
    {
      id: "drv-007",
      company: "TCS (Tata Consultancy Services)",
      role: "TCS Prime & Digital Engineer (4th Year NQT)",
      logo: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Tata_Consultancy_Services_Logo.svg",
      ctcPackage: "₹9.0 LPA (Prime) / ₹7.2 LPA (Digital)",
      stipend: "N/A (Direct FTE)",
      type: "Full-Time Offer",
      category: "Standard / Mass Premium",
      location: "Pan India (Bengaluru, Pune, Hyderabad, Chennai)",
      deadline: "2026-11-12",
      driveDate: "2026-11-19",
      status: "Open - High Volume",
      eligibility: {
        minCgpa: 6.5,
        allowedBacklogs: 1,
        eligibleBranches: ["All Engineering Branches"],
        min10th: 60.0,
        min12th: 60.0
      },
      selectionProcess: [
        { round: "Round 1", name: "TCS National Qualifier Test (NQT)", duration: "120 Mins", format: "Cognitive + Advanced Technical + 2 Coding" },
        { round: "Round 2", name: "Unified Interview", duration: "45 Mins", format: "Technical + Managerial + HR" }
      ],
      description: "Premier enterprise technology consultancy serving Global 2000 clients across banking, retail, aerospace, and telecom.",
      requirements: [
        "Consistent academic track record without unresolved backlogs.",
        "Good foundational understanding of programming and databases."
      ],
      applied: true,
      applicationStatus: "Selected - Prime Cadre Offer Secured",
      applicationDate: "2026-10-10"
    }
  ],

  hackathons: [
    {
      id: "hack-001",
      name: "Smart India Hackathon (SIH) 2026",
      organizer: "Ministry of Education & AICTE",
      badge: "National Level Premier",
      prizePool: "₹1,00,000 Per Problem Statement + Incubation Grants",
      dates: { registrationDeadline: "2026-11-25", hackathonDates: "2026-12-18 to 2026-12-20" },
      mode: "36-Hour Offline Finale at Nodal Centers",
      teamSize: "6 Members (Mandatory 1+ Female Member)",
      themes: ["Smart Automation", "Clean & Green Tech", "Disaster Management", "Heritage & Fintech", "Smart Healthcare"],
      description: "World's biggest open innovation model bringing college students to solve pressing real-world challenges faced by Central Ministries and Premier Enterprises.",
      eligibility: "Enrolled undergraduate students in recognized Indian universities.",
      registered: true,
      teamName: "Team AlgoVanguard",
      directApplyUrl: "https://sih.gov.in"
    },
    {
      id: "hack-002",
      name: "Google Solution Challenge 2026",
      organizer: "Google Developer Student Clubs (GDSC)",
      badge: "Global Flagship",
      prizePool: "$12,000 + Google Mentorship + Global Feature",
      dates: { registrationDeadline: "2026-12-15", hackathonDates: "2027-01-10 to 2027-02-15" },
      mode: "Virtual Global Competition",
      teamSize: "1 to 4 Members",
      themes: ["UN 17 Sustainable Development Goals", "AI for Good", "Accessibility", "Climate Action"],
      description: "Build an impactful software application using one or more Google technologies (Flutter, Firebase, Gemini API, Google Cloud) that advances one of the United Nations SDGs.",
      eligibility: "Active 4th year and university students globally.",
      registered: false,
      teamName: null,
      directApplyUrl: "https://developers.google.com/community/gdsc-solution-challenge"
    },
    {
      id: "hack-003",
      name: "Flipkart GRiD 6.0 - Campus Technical Challenge",
      organizer: "Flipkart India",
      badge: "Direct PPIs & Job Offers",
      prizePool: "₹5,25,000 Cash + Direct Pre-Placement Interviews (SDE-1)",
      dates: { registrationDeadline: "2026-11-19", hackathonDates: "2026-11-26 to 2026-12-10" },
      mode: "Multi-Stage Online + Offline Bengaluru Finale",
      teamSize: "2 to 3 Members (Final & Pre-Final Year)",
      themes: ["Smart E-Commerce Logistics", "Generative AI Catalog Search", "Robotics & Warehouse Optimization"],
      description: "Flipkart's prestigious engineering contest for engineering colleges across India. Top ranking teams bypass standard screening for direct SDE interviews.",
      eligibility: "B.Tech/B.E. 3rd and 4th year students with minimum 7.0 CGPA.",
      registered: true,
      teamName: "ByteRush 2026",
      directApplyUrl: "https://unstop.com/hackathons/flipkart-grid"
    },
    {
      id: "hack-004",
      name: "ETHIndia 2026 - World's Largest Web3 Hackathon",
      organizer: "Devfolio & Ethereum Foundation",
      badge: "International Web3 Leader",
      prizePool: "$150,000+ Track Bounties & Seed Grants",
      dates: { registrationDeadline: "2026-11-28", hackathonDates: "2026-12-08 to 2026-12-10" },
      mode: "In-Person 36-Hour Hackathon (KTPO, Bengaluru)",
      teamSize: "2 to 4 Members",
      themes: ["Layer 2 Scaling", "Zero Knowledge Proofs (ZKP)", "DeFi 3.0", "Decentralized Physical Infrastructure (DePIN)"],
      description: "Premier blockchain builder summit uniting top university programmers with global Web3 protocol founders and venture capitalists.",
      eligibility: "Open to all passionate developers and college student teams.",
      registered: false,
      teamName: null,
      directApplyUrl: "https://ethindia.co"
    }
  ],

  mockTests: [
    {
      id: "test-001",
      title: "Campus OA Mock: TCS NQT & Cognizant Quantitative Aptitude",
      durationMins: 30,
      totalQuestions: 10,
      category: "Aptitude & Logical Reasoning",
      targetCompanies: ["TCS", "Infosys", "Wipro", "Capgemini", "Accenture"],
      questions: [
        {
          id: "q1",
          question: "A train running at 54 km/hr crosses a platform of length 250 meters in 30 seconds. What is the length of the train?",
          options: ["150 meters", "200 meters", "250 meters", "300 meters"],
          correctIndex: 1,
          explanation: "Speed = 54 * (5/18) = 15 m/s. Total distance in 30s = 15 * 30 = 450m. Train length = 450 - 250 = 200 meters."
        },
        {
          id: "q2",
          question: "Pipe A can fill a tank in 12 hours and Pipe B can empty it in 18 hours. If both pipes are opened simultaneously, in how many hours will the tank be full?",
          options: ["24 hours", "30 hours", "36 hours", "42 hours"],
          correctIndex: 2,
          explanation: "Net rate per hour = (1/12) - (1/18) = (3 - 2) / 36 = 1/36. Therefore, it takes 36 hours to fill."
        },
        {
          id: "q3",
          question: "In how many different ways can the letters of the word 'LEADER' be arranged?",
          options: ["720", "360", "120", "180"],
          correctIndex: 1,
          explanation: "Total letters = 6. Letter 'E' appears twice. Total arrangements = 6! / 2! = 720 / 2 = 360."
        },
        {
          id: "q4",
          question: "If 15 men can complete a software project in 20 days working 8 hours a day, how many men are required to finish the project in 10 days working 12 hours a day?",
          options: ["18 men", "20 men", "22 men", "25 men"],
          correctIndex: 1,
          explanation: "M1 * D1 * H1 = M2 * D2 * H2 => 15 * 20 * 8 = M2 * 10 * 12 => 2400 = 120 * M2 => M2 = 20 men."
        },
        {
          id: "q5",
          question: "Find the missing term in the sequence: 4, 9, 25, 49, 121, ?",
          options: ["144", "169", "196", "225"],
          correctIndex: 1,
          explanation: "The terms are squares of consecutive prime numbers: 2^2=4, 3^2=9, 5^2=25, 7^2=49, 11^2=121. Next prime is 13, so 13^2 = 169."
        }
      ]
    },
    {
      id: "test-002",
      title: "Product Engineering OA: Amazon & Google Core CS Fundamentals",
      durationMins: 25,
      totalQuestions: 8,
      category: "OS, DBMS, Computer Networks & OOP",
      targetCompanies: ["Google", "Amazon", "Microsoft", "Goldman Sachs"],
      questions: [
        {
          id: "cs1",
          question: "Which of the following scheduling algorithms is strictly non-preemptive?",
          options: ["Round Robin", "First-Come First-Served (FCFS)", "Shortest Remaining Time First (SRTF)", "Priority Preemptive"],
          correctIndex: 1,
          explanation: "FCFS executes processes in arrival order until completion or I/O block, without preemptive interruption."
        },
        {
          id: "cs2",
          question: "In relational database design, what anomaly does Boyce-Codd Normal Form (BCNF) eliminate that 3NF does not?",
          options: [
            "Transitive dependencies",
            "Partial key dependencies",
            "Anomalies arising when a determinant is not a superkey",
            "Multi-valued dependencies"
          ],
          correctIndex: 2,
          explanation: "In BCNF, for every functional dependency X -> Y, X MUST be a candidate/super key. 3NF allows Y to be a prime attribute even if X is not a superkey."
        },
        {
          id: "cs3",
          question: "What is the worst-case time complexity of searching an element in a Red-Black Tree with N nodes?",
          options: ["O(1)", "O(log N)", "O(N)", "O(N log N)"],
          correctIndex: 1,
          explanation: "Red-Black Trees guarantee max height <= 2 * log2(N + 1), ensuring strict O(log N) search, insertion, and deletion."
        },
        {
          id: "cs4",
          question: "Which TCP header flag is used to abruptly reject or terminate an invalid packet sequence?",
          options: ["FIN", "SYN", "RST (Reset)", "URG"],
          correctIndex: 2,
          explanation: "The RST flag resets the TCP connection immediately in response to unassigned ports or security anomalies."
        }
      ]
    }
  ],

  announcements: [
    {
      id: "ann-001",
      title: "Google Online Challenge (GOC 2026) Hall Ticket & Shortlist Released",
      author: "Prof. K. Venkatesh - Head of Training & Placement",
      date: "2026-11-05",
      badge: "Urgent Action Required",
      category: "Drive Update",
      content: "The shortlisted list of 142 students for the Google University Graduate SWE Drive has been published on the bulletin. The test will be administered on the HackerEarth platform on Nov 28 at 10:00 AM. Please verify your camera and mic in the CSE lab."
    },
    {
      id: "ann-002",
      title: "Amazon SDE-1 Pre-Placement Talk (PPT) & Technical Prep Session",
      author: "TPO Placement Cell",
      date: "2026-11-04",
      badge: "Mandatory for Registered Students",
      category: "Session",
      content: "Amazon Talent Acquisition team will conduct a virtual PPT on Nov 18, 5:30 PM. Focus areas include 16 Leadership Principles, coding round breakdown, and live Q&A with alumni currently working at AWS."
    },
    {
      id: "ann-003",
      title: "College Placement Policy: Super Dream Offer & No Active Backlog Rules",
      author: "Dean of Academic & Corporate Relations",
      date: "2026-10-25",
      badge: "Policy Reminder",
      category: "Guidelines",
      content: "Students holding an offer in the Standard/Mass tier (up to ₹8 LPA) remain eligible for Dream (> ₹10 LPA) and Super Dream (> ₹20 LPA) tiers. Once a Super Dream offer is secured, the student is marked as 'Placed - Exited Pool' as per TPO charter."
    }
  ],

  placementStats: {
    totalEligibleStudents: 480,
    studentsPlaced: 412,
    placementPercentage: 85.83,
    highestPackage: "₹44.5 LPA",
    highestCompany: "Google India",
    averagePackage: "₹11.2 LPA",
    medianPackage: "₹9.4 LPA",
    totalOffers: 564,
    dreamTierOffers: 198,
    superDreamTierOffers: 72,
    branchStats: [
      { branch: "Computer Science (CSE)", total: 180, placed: 168, percentage: 93.3 },
      { branch: "Information Technology (IT)", total: 120, placed: 108, percentage: 90.0 },
      { branch: "Electronics & Comm (ECE)", total: 100, placed: 84, percentage: 84.0 },
      { branch: "Electrical (EEE)", total: 45, placed: 32, percentage: 71.1 },
      { branch: "Mechanical & Civil", total: 35, placed: 20, percentage: 57.1 }
    ],
    topRecruiters: [
      { name: "Google", count: 8, avgCtc: "₹38.5 LPA" },
      { name: "Amazon", count: 24, avgCtc: "₹32.0 LPA" },
      { name: "Microsoft", count: 12, avgCtc: "₹42.0 LPA" },
      { name: "Cisco", count: 28, avgCtc: "₹24.5 LPA" },
      { name: "Goldman Sachs", count: 14, avgCtc: "₹28.0 LPA" },
      { name: "TCS Prime & Digital", count: 140, avgCtc: "₹8.4 LPA" },
      { name: "Infosys SP", count: 65, avgCtc: "₹9.5 LPA" }
    ]
  },

  students: [
    {
      id: "std-2026-cse-042",
      registerId: "22BCE1042",
      fullName: "Sindhuja Reddy",
      headline: "Final Year CSE @ NITTE | Incoming SDE @ Google | LeetCode 1824 | Distributed Systems",
      college: "National Institute of Technology & Engineering",
      department: "Computer Science & Engineering",
      batch: "Class of 2026",
      cgpa: 8.84,
      activeBacklogs: 0,
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
      banner: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80",
      placedAt: "Google India (₹38.5 LPA)",
      isPlaced: true,
      connectionsCount: 384,
      isConnected: false,
      isCurrentUser: true,
      about: "Final-year Computer Science undergraduate passionate about Distributed Systems, Full-Stack Architecture, and AI-driven applications. Solved 450+ LeetCode problems with a 1820 contest rating.",
      skills: ["Data Structures & Algorithms", "System Design", "React", "Go", "Distributed Systems", "PostgreSQL"],
      endorsementsCount: 94,
      email: "sindhuja.reddy2026@nitte.edu.in",
      password: "password123"
    },
    {
      id: "std-2026-cse-089",
      registerId: "22BCE1089",
      fullName: "Rahul Verma",
      headline: "Final Year CSE | Placed SDE-1 @ Amazon India | AWS Certified | Graph Algorithms",
      college: "National Institute of Technology & Engineering",
      department: "Computer Science & Engineering",
      batch: "Class of 2026",
      cgpa: 8.92,
      activeBacklogs: 0,
      avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80",
      banner: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80",
      placedAt: "Amazon India (₹32.0 LPA)",
      isPlaced: true,
      connectionsCount: 412,
      isConnected: true,
      isCurrentUser: false,
      about: "Incoming SDE-1 at Amazon. Passionate about cloud scalability, distributed caches, and mentoring juniors for campus placement rounds.",
      skills: ["Java", "Spring Boot", "AWS DynamoDB", "System Design", "Microservices"],
      endorsementsCount: 82,
      email: "rahul.verma@nitte.edu.in",
      password: "password123"
    },
    {
      id: "std-2026-it-015",
      registerId: "22BIT1015",
      fullName: "Ananya Sen",
      headline: "4th Year IT | Placed Software Engineer @ Microsoft | Open Source Contributor | React & C++",
      college: "National Institute of Technology & Engineering",
      department: "Information Technology",
      batch: "Class of 2026",
      cgpa: 9.15,
      activeBacklogs: 0,
      avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80",
      banner: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80",
      placedAt: "Microsoft (₹42.0 LPA)",
      isPlaced: true,
      connectionsCount: 520,
      isConnected: true,
      isCurrentUser: false,
      about: "Passionate about building inclusive, accessible software. Winner of 3 national hackathons and incoming Microsoft Azure engineer.",
      skills: ["C++", "TypeScript", "React", "Docker", "Algorithms", "Azure"],
      endorsementsCount: 110,
      email: "ananya.sen@nitte.edu.in",
      password: "password123"
    },
    {
      id: "std-2026-ece-044",
      registerId: "22BEC1044",
      fullName: "Karthik Subramanian",
      headline: "4th Year ECE | Network Engineer @ Cisco Systems | Linux Internals & Socket Programming",
      college: "National Institute of Technology & Engineering",
      department: "Electronics & Communication",
      batch: "Class of 2026",
      cgpa: 8.65,
      activeBacklogs: 0,
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80",
      banner: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1200&q=80",
      placedAt: "Cisco Systems (₹24.5 LPA)",
      isPlaced: true,
      connectionsCount: 290,
      isConnected: false,
      isCurrentUser: false,
      about: "Networking geek. Deep dive into TCP/IP, Linux kernel packet filtering (eBPF), and routing protocols.",
      skills: ["C", "Computer Networks", "Linux Kernel", "Wireshark", "Python"],
      endorsementsCount: 65,
      email: "karthik.s@nitte.edu.in",
      password: "password123"
    },
    {
      id: "std-2026-cse-112",
      registerId: "22BCE1112",
      fullName: "Priya Sharma",
      headline: "Final Year CSE | Smart India Hackathon Finalist | Full-Stack & Generative AI Builder",
      college: "National Institute of Technology & Engineering",
      department: "Computer Science & Engineering",
      batch: "Class of 2026",
      cgpa: 8.78,
      activeBacklogs: 0,
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80",
      banner: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80",
      placedAt: "Actively Interviewing (Goldman Sachs & Adobe)",
      isPlaced: false,
      connectionsCount: 310,
      isConnected: false,
      isCurrentUser: false,
      about: "Building AI-assisted web apps. Currently preparing for Day 1 Dream Tier rounds with focus on dynamic programming.",
      skills: ["Python", "FastAPI", "React", "Machine Learning", "SQL"],
      endorsementsCount: 58,
      email: "priya.sharma@nitte.edu.in",
      password: "password123"
    }
  ],

  feed: [
    {
      id: "feed-001",
      authorId: "std-2026-cse-089",
      authorName: "Rahul Verma",
      authorRegisterId: "22BCE1089",
      authorHeadline: "Placed SDE-1 @ Amazon India • Class of 2026",
      authorAvatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80",
      timestamp: "2 hours ago",
      tag: "#OfferCelebration",
      badge: "Placement Verified",
      content: "🎉 Thrilled and incredibly humbled to announce that I have accepted a full-time offer as Software Development Engineer 1 (SDE-1) at Amazon India!\n\nTo my 4th year batchmates actively preparing for the Day-1 drives: focus deeply on Sliding Window problems, Monotonic Queues, and the 16 Amazon Leadership Principles. Big shoutout to our TPO cell and alumni mentors for conducting realistic mock Bar Raiser sessions. Let's conquer campus placements 2026 together! 🚀💼",
      reactions: { likes: 168, celebrates: 84, loves: 52 },
      userReacted: true,
      comments: [
        {
          id: "c1",
          authorName: "Sindhuja Reddy",
          authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
          text: "Huge congratulations Rahul! Thoroughly deserved. Your consistency on LeetCode really paid off! 👏",
          timestamp: "1 hour ago"
        },
        {
          id: "c2",
          authorName: "Prof. K. Venkatesh (TPO Head)",
          authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80",
          text: "Proud moment for the CSE department. Wishing you stellar success at Amazon!",
          timestamp: "45 mins ago"
        }
      ]
    },
    {
      id: "feed-002",
      authorId: "std-2026-it-015",
      authorName: "Ananya Sen",
      authorRegisterId: "22BIT1015",
      authorHeadline: "Software Engineer @ Microsoft • Class of 2026",
      authorAvatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80",
      timestamp: "5 hours ago",
      tag: "#InterviewExperience",
      badge: "Campus Debrief",
      content: "📝 My Microsoft Campus Technical Round 2 Debrief:\n\nThe interviewer focused 70% on CS Fundamentals rather than pure LeetCode! We discussed:\n1. Mutex vs Spinlock in Linux multicore systems.\n2. Why TCP needs TIME_WAIT state (2*MSL).\n3. Designing a distributed key-value store with eventual consistency.\n\nTip: Don't neglect your OS, DBMS, and Networking syllabi from 5th & 6th sem! Added the exact questions into the 'Interview Questions' tab on PlaceHub.",
      reactions: { likes: 215, celebrates: 96, loves: 41 },
      userReacted: false,
      comments: [
        {
          id: "c3",
          authorName: "Karthik Subramanian",
          authorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80",
          text: "Super valuable tips Ananya. OS concurrency is definitely a recurring favorite across all tier-1 interviews.",
          timestamp: "3 hours ago"
        }
      ]
    },
    {
      id: "feed-003",
      authorId: "std-2026-cse-042",
      authorName: "Sindhuja Reddy",
      authorRegisterId: "22BCE1042",
      authorHeadline: "Incoming SWE @ Google • 4th Year CSE",
      authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
      timestamp: "1 day ago",
      tag: "#Hackathon",
      badge: "SIH 2026 Finalist",
      content: "🚀 Our 4th year capstone project 'SentinelReview' has qualified for the Grand Finale of Smart India Hackathon 2026! We're building automated LLM-based AST security audits for open-source repositories.\n\nLooking for 1 final year teammate with strong React and WebSockets experience. Check our teammate request on the Hackathon board or drop me a direct message! 💻",
      reactions: { likes: 189, celebrates: 62, loves: 74 },
      userReacted: true,
      comments: []
    }
  ],

  messages: [
    {
      id: "msg-1",
      senderId: "std-2026-cse-089",
      senderName: "Rahul Verma",
      recipientId: "std-2026-cse-042",
      text: "Hey Sindhuja! Are you free for a 30-min peer mock interview on Dynamic Programming this evening?",
      timestamp: "Yesterday 6:30 PM"
    },
    {
      id: "msg-2",
      senderId: "std-2026-cse-042",
      senderName: "Sindhuja Reddy",
      recipientId: "std-2026-cse-089",
      text: "Hey Rahul! Absolutely, let's connect at 8 PM. I have 2 Google Graphs questions prepared for you.",
      timestamp: "Yesterday 6:45 PM"
    }
  ]
};

module.exports = initialData;
