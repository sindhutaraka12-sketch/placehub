#!/usr/bin/env bash
# PlaceHub - 4th Year Student Placement Platform Launcher

echo "====================================================================="
echo "          PlaceHub - 4th Year Student Placement Platform"
echo "       Class of 2026 Campus Recruitment & Career Launch Portal"
echo "====================================================================="
echo ""

if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not installed. Please install Node.js from https://nodejs.org/"
    exit 1
fi

echo "🚀 Starting PlaceHub Full-Stack Server on http://localhost:5000 ..."
node backend/server.js
