const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET student applications tracker pipeline
router.get('/', (req, res) => {
  try {
    const drives = db.getDrives();
    const applied = drives.filter(d => d.applied);

    const stages = [
      { id: "applied", name: "Applied / Under Review", count: 0, drives: [] },
      { id: "oa", name: "Online Assessment Scheduled", count: 0, drives: [] },
      { id: "interview", name: "Technical Interview", count: 0, drives: [] },
      { id: "hr", name: "HR / Bar Raiser", count: 0, drives: [] },
      { id: "offered", name: "Offer Extended / Placed", count: 0, drives: [] }
    ];

    applied.forEach(drive => {
      const statusLower = (drive.applicationStatus || '').toLowerCase();
      if (statusLower.includes("offer") || statusLower.includes("selected") || statusLower.includes("placed")) {
        stages[4].count++;
        stages[4].drives.push(drive);
      } else if (statusLower.includes("bar raiser") || statusLower.includes("managerial") || statusLower.includes("hr")) {
        stages[3].count++;
        stages[3].drives.push(drive);
      } else if (statusLower.includes("technical") || statusLower.includes("cleared")) {
        stages[2].count++;
        stages[2].drives.push(drive);
      } else if (statusLower.includes("shortlisted") || statusLower.includes("oa") || statusLower.includes("assessment")) {
        stages[1].count++;
        stages[1].drives.push(drive);
      } else {
        stages[0].count++;
        stages[0].drives.push(drive);
      }
    });

    res.json({
      success: true,
      totalApplied: applied.length,
      pipeline: stages,
      rawList: applied
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT update application status (e.g., student advances in rounds)
router.put('/:driveId/stage', (req, res) => {
  try {
    const { status } = req.body;
    const drive = db.getDrives().find(d => d.id === req.params.driveId);
    if (!drive) {
      return res.status(404).json({ success: false, error: "Drive not found" });
    }
    drive.applicationStatus = status || "In Progress";
    db.persist();
    res.json({
      success: true,
      data: drive,
      message: `Status updated to '${drive.applicationStatus}'`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
