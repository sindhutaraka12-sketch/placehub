const express = require('express');
const router = express.Router();
const db = require('../models/db');

// Helper to evaluate student eligibility against a drive
function evaluateEligibility(student, drive) {
  const cgpaOk = student.cgpa >= drive.eligibility.minCgpa;
  const backlogsOk = student.activeBacklogs <= drive.eligibility.allowedBacklogs;
  const tenthOk = !drive.eligibility.min10th || student.tenthPercentage >= drive.eligibility.min10th;
  const twelfthOk = !drive.eligibility.min12th || student.twelfthPercentage >= drive.eligibility.min12th;
  
  // Branch check
  const branchOk = drive.eligibility.eligibleBranches.some(b => 
    b.toLowerCase().includes("all") || 
    student.department.toLowerCase().includes(b.toLowerCase()) ||
    (b === "CSE" && student.department.includes("Computer Science")) ||
    (b === "IT" && student.department.includes("Information")) ||
    (b === "ECE" && student.department.includes("Electronics"))
  );

  const isEligible = cgpaOk && backlogsOk && branchOk && tenthOk && twelfthOk;
  const reasons = [];
  if (!cgpaOk) reasons.push(`Requires minimum CGPA of ${drive.eligibility.minCgpa} (Current: ${student.cgpa})`);
  if (!backlogsOk) reasons.push(`Requires max ${drive.eligibility.allowedBacklogs} active backlogs (Current: ${student.activeBacklogs})`);
  if (!branchOk) reasons.push(`Branch not eligible (Requires: ${drive.eligibility.eligibleBranches.join(', ')})`);
  if (!tenthOk) reasons.push(`10th standard cutoff not met (Req: ${drive.eligibility.min10th}%)`);
  if (!twelfthOk) reasons.push(`12th standard cutoff not met (Req: ${drive.eligibility.min12th}%)`);

  return {
    isEligible,
    reasons: reasons.length ? reasons : ["All academic qualifications and criteria fulfilled!"]
  };
}

// GET all drives with student qualification status
router.get('/', (req, res) => {
  try {
    const student = db.getProfile();
    const drives = db.getDrives();
    const categoryFilter = req.query.category;

    let filtered = drives;
    if (categoryFilter && categoryFilter !== 'All') {
      filtered = filtered.filter(d => d.category.toLowerCase().includes(categoryFilter.toLowerCase()));
    }

    const enhanced = filtered.map(drive => {
      const evalResult = evaluateEligibility(student, drive);
      return {
        ...drive,
        qualificationStatus: evalResult
      };
    });

    res.json({
      success: true,
      data: enhanced,
      summary: {
        totalDrives: drives.length,
        eligibleCount: drives.filter(d => evaluateEligibility(student, d).isEligible).length,
        appliedCount: drives.filter(d => d.applied).length
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET complete eligibility matrix comparison
router.get('/eligibility-matrix', (req, res) => {
  try {
    const student = db.getProfile();
    const drives = db.getDrives();

    const matrix = drives.map(drive => {
      const evalResult = evaluateEligibility(student, drive);
      return {
        driveId: drive.id,
        company: drive.company,
        role: drive.role,
        ctc: drive.ctcPackage,
        criteria: {
          minCgpa: drive.eligibility.minCgpa,
          studentCgpa: student.cgpa,
          cgpaPassed: student.cgpa >= drive.eligibility.minCgpa,
          allowedBacklogs: drive.eligibility.allowedBacklogs,
          studentBacklogs: student.activeBacklogs,
          backlogsPassed: student.activeBacklogs <= drive.eligibility.allowedBacklogs,
          branches: drive.eligibility.eligibleBranches
        },
        isEligible: evalResult.isEligible,
        reasons: evalResult.reasons,
        applied: drive.applied,
        applicationStatus: drive.applicationStatus
      };
    });

    res.json({
      success: true,
      studentOverview: {
        name: student.fullName,
        cgpa: student.cgpa,
        department: student.department,
        backlogs: student.activeBacklogs,
        tenth: student.tenthPercentage,
        twelfth: student.twelfthPercentage
      },
      matrix
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST 1-Click apply to drive
router.post('/:id/apply', (req, res) => {
  try {
    const student = db.getProfile();
    const drive = db.getDrives().find(d => d.id === req.params.id);

    if (!drive) {
      return res.status(404).json({ success: false, error: "Placement drive not found." });
    }

    const evalResult = evaluateEligibility(student, drive);
    if (!evalResult.isEligible) {
      return res.status(400).json({
        success: false,
        error: "Eligibility criteria not met for this drive.",
        details: evalResult.reasons
      });
    }

    const appliedDrive = db.applyToDrive(req.params.id);

    res.json({
      success: true,
      data: appliedDrive,
      message: `Successfully applied to ${drive.company} (${drive.role})!`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST TPO create new drive
router.post('/', (req, res) => {
  try {
    const { company, role, ctcPackage, stipend, category, location, deadline, driveDate, minCgpa, eligibleBranches } = req.body;
    if (!company || !role || !ctcPackage) {
      return res.status(400).json({ success: false, error: "Company, role, and package are required." });
    }

    const newDrive = {
      id: `drv-${Date.now()}`,
      company,
      role,
      logo: req.body.logo || "https://upload.wikimedia.org/wikipedia/commons/a/ac/Default_pfp.svg",
      ctcPackage,
      stipend: stipend || "Competitive Stipend",
      type: req.body.type || "Full-Time Offer",
      category: category || "Dream Tier (₹10 - ₹25 LPA)",
      location: location || "Bengaluru / Pan India",
      deadline: deadline || "2026-12-15",
      driveDate: driveDate || "2026-12-20",
      status: "Open - Applications Live",
      eligibility: {
        minCgpa: Number(minCgpa) || 7.0,
        allowedBacklogs: Number(req.body.allowedBacklogs) || 0,
        eligibleBranches: eligibleBranches ? eligibleBranches.split(',').map(b => b.trim()) : ["CSE", "IT", "ECE"],
        min10th: Number(req.body.min10th) || 60.0,
        min12th: Number(req.body.min12th) || 60.0
      },
      selectionProcess: [
        { round: "Round 1", name: "Online Aptitude & Code Test", duration: "90 Mins", format: "MCQs + Coding" },
        { round: "Round 2", name: "Technical Interview", duration: "45 Mins", format: "Core CS & DSA" },
        { round: "Round 3", name: "HR / Fitment Interview", duration: "30 Mins", format: "Culture & Compensation" }
      ],
      description: req.body.description || "Exciting engineering role at a tier-1 technology leader.",
      requirements: req.body.requirements || [
        "Strong problem solving abilities and foundational CS skills.",
        "Team player with passion for technology."
      ],
      applied: false,
      applicationStatus: "Not Applied",
      applicationDate: null
    };

    db.data.drives.unshift(newDrive);
    db.persist();

    res.status(201).json({
      success: true,
      data: newDrive,
      message: `New campus drive for ${company} published successfully!`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
