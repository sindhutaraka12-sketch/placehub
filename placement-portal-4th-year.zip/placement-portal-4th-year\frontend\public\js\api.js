/**
 * PlaceHub Client API Service
 * Handles communication with the Express backend REST API
 */

const API_BASE = '/api';

const api = {
  // LinkedIn Auth & Student Register ID
  async registerStudent(studentData) {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(studentData)
    });
    return await res.json();
  },

  async loginStudent(registerId, password) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ registerId, password })
    });
    return await res.json();
  },

  // LinkedIn Student & Alumni Network
  async getStudents(filters = {}) {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.branch && filters.branch !== 'All') params.append('branch', filters.branch);
    if (filters.placed) params.append('placed', 'true');
    const res = await fetch(`${API_BASE}/students?${params.toString()}`);
    return await res.json();
  },

  async toggleConnectStudent(studentId) {
    const res = await fetch(`${API_BASE}/students/${studentId}/connect`, { method: 'POST' });
    return await res.json();
  },

  // LinkedIn Campus Feed
  async getFeed() {
    const res = await fetch(`${API_BASE}/feed`);
    return await res.json();
  },

  async createFeedPost(postData) {
    const res = await fetch(`${API_BASE}/feed`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(postData)
    });
    return await res.json();
  },

  async reactToPost(postId, reaction = 'likes') {
    const res = await fetch(`${API_BASE}/feed/${postId}/react`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reaction })
    });
    return await res.json();
  },

  async commentOnPost(postId, commentData) {
    const res = await fetch(`${API_BASE}/feed/${postId}/comment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(commentData)
    });
    return await res.json();
  },

  // Direct Peer Messaging
  async getMessages(partnerId) {
    const res = await fetch(`${API_BASE}/messages/${partnerId}`);
    return await res.json();
  },

  async sendMessage(partnerId, text, sender) {
    const res = await fetch(`${API_BASE}/messages/${partnerId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, sender })
    });
    return await res.json();
  },

  // Profile
  async getProfile() {
    const res = await fetch(`${API_BASE}/profile`);
    return await res.json();
  },

  async updateProfile(updates) {
    const res = await fetch(`${API_BASE}/profile`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    return await res.json();
  },

  async calculateAtsScore(targetCompany = 'Amazon SDE-1') {
    const res = await fetch(`${API_BASE}/profile/calculate-ats`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetCompany })
    });
    return await res.json();
  },

  async getPublicPortfolio() {
    const res = await fetch(`${API_BASE}/profile/portfolio`);
    return await res.json();
  },

  // Interview Questions
  async getQuestions(filters = {}) {
    const params = new URLSearchParams();
    if (filters.company && filters.company !== 'All') params.append('company', filters.company);
    if (filters.category && filters.category !== 'All') params.append('category', filters.category);
    if (filters.difficulty && filters.difficulty !== 'All') params.append('difficulty', filters.difficulty);
    if (filters.search) params.append('search', filters.search);

    const res = await fetch(`${API_BASE}/questions?${params.toString()}`);
    return await res.json();
  },

  async getQuestionFilters() {
    const res = await fetch(`${API_BASE}/questions/meta/filters`);
    return await res.json();
  },

  async toggleQuestionSolve(id) {
    const res = await fetch(`${API_BASE}/questions/${id}/toggle-solve`, { method: 'POST' });
    return await res.json();
  },

  async addQuestion(questionData) {
    const res = await fetch(`${API_BASE}/questions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(questionData)
    });
    return await res.json();
  },

  // Drives & Qualifications
  async getDrives(category = 'All') {
    const params = category !== 'All' ? `?category=${encodeURIComponent(category)}` : '';
    const res = await fetch(`${API_BASE}/drives${params}`);
    return await res.json();
  },

  async getEligibilityMatrix() {
    const res = await fetch(`${API_BASE}/drives/eligibility-matrix`);
    return await res.json();
  },

  async applyToDrive(driveId) {
    const res = await fetch(`${API_BASE}/drives/${driveId}/apply`, { method: 'POST' });
    return await res.json();
  },

  async createDrive(driveData) {
    const res = await fetch(`${API_BASE}/drives`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(driveData)
    });
    return await res.json();
  },

  // Projects
  async getProjects() {
    const res = await fetch(`${API_BASE}/projects`);
    return await res.json();
  },

  async addProject(projectData) {
    const res = await fetch(`${API_BASE}/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(projectData)
    });
    return await res.json();
  },

  async toggleProjectFeatured(id) {
    const res = await fetch(`${API_BASE}/projects/${id}/toggle-featured`, { method: 'POST' });
    return await res.json();
  },

  async deleteProject(id) {
    const res = await fetch(`${API_BASE}/projects/${id}`, { method: 'DELETE' });
    return await res.json();
  },

  // Skills
  async getSkills() {
    const res = await fetch(`${API_BASE}/skills`);
    return await res.json();
  },

  async addSkill(skillData) {
    const res = await fetch(`${API_BASE}/skills`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(skillData)
    });
    return await res.json();
  },

  async getSkillGapAnalysis(company) {
    const res = await fetch(`${API_BASE}/skills/gap-analysis?company=${encodeURIComponent(company)}`);
    return await res.json();
  },

  // Hackathons
  async getHackathons() {
    const res = await fetch(`${API_BASE}/hackathons`);
    return await res.json();
  },

  async registerHackathon(id, teamName) {
    const res = await fetch(`${API_BASE}/hackathons/${id}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ teamName })
    });
    return await res.json();
  },

  async postTeammateRequest(postData) {
    const res = await fetch(`${API_BASE}/hackathons/find-teammates`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(postData)
    });
    return await res.json();
  },

  // Applications
  async getApplicationsPipeline() {
    const res = await fetch(`${API_BASE}/applications`);
    return await res.json();
  },

  // Announcements
  async getAnnouncements() {
    const res = await fetch(`${API_BASE}/announcements`);
    return await res.json();
  },

  async addAnnouncement(announcementData) {
    const res = await fetch(`${API_BASE}/announcements`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(announcementData)
    });
    return await res.json();
  },

  // Stats
  async getPlacementStats() {
    const res = await fetch(`${API_BASE}/stats`);
    return await res.json();
  },

  // Mock Tests
  async getMockTests() {
    const res = await fetch(`${API_BASE}/mock-tests`);
    return await res.json();
  },

  async getMockTestById(id) {
    const res = await fetch(`${API_BASE}/mock-tests/${id}`);
    return await res.json();
  },

  async submitMockTest(id, userAnswers) {
    const res = await fetch(`${API_BASE}/mock-tests/${id}/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userAnswers })
    });
    return await res.json();
  },

  // Reset database
  async resetDatabase() {
    const res = await fetch(`${API_BASE}/reset`, { method: 'POST' });
    return await res.json();
  }
};
