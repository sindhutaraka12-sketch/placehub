const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET all interview questions with query filters
router.get('/', (req, res) => {
  try {
    const { company, category, difficulty, search } = req.query;
    const questions = db.getInterviewQuestions({ company, category, difficulty, search });
    
    // Summary metrics
    const total = questions.length;
    const solvedCount = questions.filter(q => q.solved).length;

    res.json({
      success: true,
      data: questions,
      meta: {
        total,
        solvedCount,
        progressPercentage: total > 0 ? Math.round((solvedCount / total) * 100) : 0
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET distinct companies and categories
router.get('/meta/filters', (req, res) => {
  try {
    const all = db.getInterviewQuestions();
    const companies = [...new Set(all.map(q => q.company))];
    const categories = [...new Set(all.map(q => q.category))];
    const topics = [...new Set(all.map(q => q.topic))];

    const companyStats = companies.map(comp => ({
      company: comp,
      count: all.filter(q => q.company === comp).length,
      solved: all.filter(q => q.company === comp && q.solved).length
    }));

    res.json({
      success: true,
      companies,
      categories,
      topics,
      companyStats
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST toggle solved status
router.post('/:id/toggle-solve', (req, res) => {
  try {
    const question = db.toggleQuestionSolved(req.params.id);
    if (!question) {
      return res.status(404).json({ success: false, error: "Question not found" });
    }
    res.json({
      success: true,
      data: question,
      message: question.solved ? "Marked as Mastered!" : "Marked as Unsolved"
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST add new interview question
router.post('/', (req, res) => {
  try {
    const { company, role, category, topic, difficulty, title, question, keyConcepts, solutionSnippet, explanation } = req.body;
    if (!company || !title || !question) {
      return res.status(400).json({ success: false, error: "Missing required fields (company, title, question)" });
    }

    const newQuestion = {
      id: `iq-${Date.now()}`,
      company,
      role: role || "Software Engineer",
      round: req.body.round || "Technical Interview",
      category: category || "Data Structures & Algorithms",
      topic: topic || "General Problem Solving",
      difficulty: difficulty || "Medium",
      frequency: "Recently Added by Placement Cell",
      title,
      question,
      keyConcepts: keyConcepts || ["Algorithms", "Problem Solving"],
      timeComplexity: req.body.timeComplexity || "O(N)",
      spaceComplexity: req.body.spaceComplexity || "O(1)",
      hints: req.body.hints || ["Break the problem into smaller subproblems."],
      solutionSnippet: solutionSnippet || "// Solution code",
      explanation: explanation || "Detailed step-by-step breakdown.",
      solved: false
    };

    db.data.interviewQuestions.unshift(newQuestion);
    db.persist();

    res.status(201).json({ success: true, data: newQuestion, message: "Interview question added successfully!" });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
