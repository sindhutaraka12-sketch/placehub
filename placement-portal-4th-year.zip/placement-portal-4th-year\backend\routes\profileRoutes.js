const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET full student profile
router.get('/', (req, res) => {
  try {
    const profile = db.getProfile();
    const projects = db.getProjects();
    const questions = db.getInterviewQuestions();
    const drives = db.getDrives();

    // Dynamically computed stats
    const totalSolved = questions.filter(q => q.solved).length;
    const appliedDrives = drives.filter(d => d.applied).length;
    const eligibleDrives = drives.filter(d => {
      return (
        profile.cgpa >= d.eligibility.minCgpa &&
        profile.activeBacklogs <= d.eligibility.allowedBacklogs
      );
    }).length;

    res.json({
      success: true,
      data: {
        ...profile,
        metricsSummary: {
          totalSolvedQuestions: totalSolved,
          totalProjects: projects.length,
          appliedDrivesCount: appliedDrives,
          eligibleDrivesCount: eligibleDrives,
          readinessScore: 94
        }
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT update student profile
router.put('/', (req, res) => {
  try {
    const updated = db.updateProfile(req.body);
    res.json({ success: true, data: updated, message: "Profile successfully updated." });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST ATS Resume Analyzer
router.post('/calculate-ats', (req, res) => {
  try {
    const profile = db.getProfile();
    const projects = db.getProjects();
    const skillsData = db.getSkills();

    let score = 70;
    const feedback = [];

    // Check project metrics
    const hasMetrics = projects.some(p => p.metrics && /\d+%|\d+x|\d+ms/i.test(p.metrics));
    if (hasMetrics) {
      score += 10;
      feedback.push({ type: "positive", message: "Quantifiable project metrics detected (percentages, latency, throughput)." });
    } else {
      feedback.push({ type: "warning", message: "Add quantifiable impact (e.g. 'Reduced latency by 40%') to projects." });
    }

    // Check Core CS fundamentals
    const hasCoreCS = skillsData.categories.some(c => c.name.includes("Core CS") && c.skills.length >= 4);
    if (hasCoreCS) {
      score += 8;
      feedback.push({ type: "positive", message: "Essential CS fundamentals (OS, DBMS, Networks, OOP) present." });
    }

    // Check coding profiles
    if (profile.leetcodeUrl && profile.githubUrl && profile.linkedinUrl) {
      score += 7;
      feedback.push({ type: "positive", message: "All essential recruiter links verified (LeetCode, GitHub, LinkedIn)." });
    }

    score = Math.min(score, 98);

    db.updateProfile({ atsScore: score, atsFeedback: feedback });

    res.json({
      success: true,
      score,
      feedback,
      targetCompany: req.body.targetCompany || "Amazon SDE-1"
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET public shareable portfolio data
router.get('/portfolio', (req, res) => {
  try {
    const profile = db.getProfile();
    const projects = db.getProjects();
    const skills = db.getSkills();

    res.json({
      success: true,
      data: {
        student: {
          fullName: profile.fullName,
          degree: profile.degree,
          college: profile.college,
          cgpa: profile.cgpa,
          bio: profile.bio,
          avatar: profile.avatar,
          links: {
            portfolio: profile.portfolioUrl,
            github: profile.githubUrl,
            linkedin: profile.linkedinUrl,
            leetcode: profile.leetcodeUrl
          }
        },
        featuredProjects: projects.filter(p => p.featured),
        allProjects: projects,
        skillsMatrix: skills.categories,
        certifications: profile.certifications,
        academicHistory: profile.semesters
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
