const express = require('express');
const router = express.Router();
const db = require('../models/db');

// Teammate matchmaking posts in memory
let teammatePosts = [
  {
    id: "team-post-1",
    studentName: "Aditya Sharma (CSE - 8th Sem)",
    hackathonName: "Smart India Hackathon 2026",
    roleNeeded: "Frontend / React + UI Specialist",
    description: "Building an automated AI water leakage detection system. We have ML model ready, looking for React + Mapbox developer.",
    contact: "aditya.sharma@nitte.edu.in",
    date: "2026-11-04"
  },
  {
    id: "team-post-2",
    studentName: "Pooja Hegde (IT - 8th Sem)",
    hackathonName: "Google Solution Challenge 2026",
    roleNeeded: "Cloud & Firebase / Backend Developer",
    description: "Designing an accessible voice-guided shopping assistant for visually impaired users. Need 1 backend engineer.",
    contact: "pooja.h@nitte.edu.in",
    date: "2026-11-03"
  }
];

// GET all hackathons
router.get('/', (req, res) => {
  try {
    const hackathons = db.getHackathons();
    res.json({
      success: true,
      data: hackathons,
      teammateBoard: teammatePosts
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST register for hackathon
router.post('/:id/register', (req, res) => {
  try {
    const { teamName } = req.body;
    const hackathon = db.registerHackathon(req.params.id, teamName);
    if (!hackathon) {
      return res.status(404).json({ success: false, error: "Hackathon not found" });
    }
    res.json({
      success: true,
      data: hackathon,
      message: `Team '${hackathon.teamName}' registered for ${hackathon.name}!`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST submit teammate finder post
router.post('/find-teammates', (req, res) => {
  try {
    const { hackathonName, roleNeeded, description, contact } = req.body;
    const student = db.getProfile();
    const newPost = {
      id: `team-post-${Date.now()}`,
      studentName: `${student.fullName} (${student.department.split(' ')[0]} - 8th Sem)`,
      hackathonName: hackathonName || "Smart India Hackathon 2026",
      roleNeeded: roleNeeded || "Full-Stack Developer",
      description: description || "Looking for committed teammate to build top-tier hackathon prototype.",
      contact: contact || student.email,
      date: new Date().toISOString().split('T')[0]
    };
    teammatePosts.unshift(newPost);
    res.status(201).json({ success: true, data: newPost, message: "Teammate request published on campus board!" });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
