@echo off
title PlaceHub - 4th Year Placement Platform
color 0B

echo =====================================================================
echo           PlaceHub - 4th Year Student Placement Platform
echo        Class of 2026 Campus Recruitment ^& Career Launch Portal
echo =====================================================================
echo.

:: Check Node.js installation
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not found in system PATH.
    echo Please install Node.js from https://nodejs.org/ to launch the server.
    pause
    exit /b 1
)

echo [1/2] Node.js detected. Launching PlaceHub Full-Stack Server...
echo [2/2] Opening application in browser at http://localhost:5000 ...
echo.

start http://localhost:5000
node backend/server.js

pause
