const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET all TPO announcements
router.get('/', (req, res) => {
  try {
    const announcements = db.getAnnouncements();
    res.json({ success: true, data: announcements });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST new announcement (TPO Admin)
router.post('/', (req, res) => {
  try {
    const { title, content, badge, category } = req.body;
    if (!title || !content) {
      return res.status(400).json({ success: false, error: "Title and content are required." });
    }

    const created = db.addAnnouncement({
      title,
      author: req.body.author || "Placement Office (TPO)",
      badge: badge || "Important Notice",
      category: category || "Announcement",
      content
    });

    res.status(201).json({ success: true, data: created, message: "Announcement broadcasted to 4th year batch!" });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
