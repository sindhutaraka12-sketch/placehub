# 🎓 PlaceHub — 4th Year Student Placement & Career Launch Platform

> A comprehensive, full-stack campus recruitment and placement platform designed specifically for **4th-year (Final Year) Engineering and Degree students** entering campus placements, off-campus recruitment drives, and competitive corporate hiring.

---

## 🌟 Key Modules & Features

### 1. 🏢 Top Companies Interview Questions
- **Company Categorization**: Curated technical questions from **Google**, **Amazon**, **Microsoft**, **Goldman Sachs**, **Cisco**, **TCS Digital/Prime**, **Infosys SP**, **Adobe**, and **Meta**.
- **Topic Filtering**: Data Structures & Algorithms, System Design, Operating Systems, DBMS, Computer Networks, and Behavioral STAR method.
- **Difficulty Badges**: Easy, Medium, and Hard with frequency indicators (e.g. *"Asked in 2025–26 Campus Drives"*).
- **Code & Solutions**: Expandable optimal code snippets (C++, Java, Python), time/space complexity analysis, and pro hints.
- **Interactive Practice Scratchpad**: Built-in code editor simulator with real-time test case verification.
- **Mastery Tracker**: Toggle questions as solved with live progress bar.

### 2. 🎯 Qualifications & Eligibility Criteria Engine
- **Automated Eligibility Checker**: Real-time evaluation against student's CGPA, active backlogs, 10th & 12th percentages, and branch.
- **Company Eligibility Matrix**: Side-by-side comparative table showing minimum cutoff vs student's scores with instant status pills:
  - `Eligible - Ready to Apply`
  - `Ineligible (CGPA Cutoff Mismatch)`
- **College Placement Charter Rules**: Clear explanation of Super Dream (&gt; ₹25 LPA), Dream (₹10–₹25 LPA), and Standard/Mass tier recruitment guidelines.

### 3. 🚀 Your Projects Showcase Hub
- **4th-Year Capstone Showcase**: Designed specifically for final-year engineering projects, distributed systems, and full-stack applications.
- **Quantifiable Impact Metrics**: Emphasizes ATS-critical metrics (*"Reduced PR review turnaround by 65%"*, *"Sustained 25,000 req/sec"*).
- **Tech Stack Chips & Links**: Displays architecture badges, GitHub repository links, and live demo buttons.
- **Pin to Resume**: Toggle projects to feature on placement resume and public portfolio.
- **Add/Delete Modal**: Easily submit new projects directly from the portal.

### 4. ⚡ Skills Matrix & Dream Company Gap Analysis
- **Categorized Proficiencies**: Programming Languages, Core CS Fundamentals (OS/DBMS/CN/OOP), Full-Stack, and Cloud/DevOps.
- **Interactive Visual Meters**: Animated proficiency bars and verification badges.
- **Dream Company Benchmark Analyzer**: Select target company (**Google SDE L3**, **Amazon SDE-1**, **Microsoft**, etc.) to get an instant match percentage, identify missing skill competencies, and view an actionable roadmap.

### 5. 💼 Placement Drives & Internship Requirements
- **Active Campus Drives**: Job postings for Full-Time Offers (FTE) and 6-Month Pre-Placement Internships.
- **Complete CTC & Stipend Breakdown**: Base package, joining bonuses, RSUs, and monthly internship stipend.
- **Eligibility Validation**: Instant check preventing students with backlogs or CGPA below cutoff from applying.
- **1-Click Apply**: Direct application modal verifying student credentials and attached resume.

### 6. 🏆 Hackathons & National Challenges
- **Premier Hackathons**: National and global events including **Smart India Hackathon (SIH) 2026**, **Google Solution Challenge**, **Flipkart GRiD 6.0**, and **ETHIndia**.
- **Prize Pools & PPIs**: Highlights cash prizes, venture grants, and direct Pre-Placement Interviews.
- **Campus Teammate Matchmaking Board**: Post and discover teammates for hackathons and 4th-year capstone projects.
- **Team Registration**: One-click team registration tracking.

### 7. 👤 Student Profile & Recruiter Portfolio
- **Comprehensive Academic Record**: Roll Number, USN, Degree, Department, 8-Semester SGPA breakdown, and verified credentials.
- **Coding Profiles**: LeetCode contest rating, GitHub repository counters, and LinkedIn.
- **ATS Resume Auditor**: Simulates Applicant Tracking System (ATS) score with actionable feedback on formatting, metrics, and CS fundamentals.
- **Public Recruiter Portfolio Mode**: A dedicated, sleek standalone view for sharing with external recruiters and hiring managers.

### 8. 📝 Mock Placement Tests (OA Simulator)
- **Campus OA Mock**: Aptitude, logical reasoning, and quant practice.
- **Product Engineering OA**: Core CS MCQs (Operating Systems, Normalization, Networks, Tree complexity).
- **Real-Time Countdown Timer & Instant Auto-Grading**: Generates percentage scores, performance badges, and detailed question-by-question explanations.

### 9. 🏛️ TPO Placement Officer & Recruiter Mode
- **Role Switcher**: Switch between Student View and Placement Officer (TPO) View in one click.
- **Campus Analytics Dashboard**: Batch placement rate, average CTC, highest CTC, and branch breakdown.
- **Publish Drives & Alerts**: TPO can publish new campus recruitment drives and urgent announcements.

---

## 🎨 Career-Focused Color Palette

Designed specifically for ambitious students, corporate recruiters, and placement officers:

| Role | Color Name | Hex Code | Visual Application |
|---|---|---|---|
| **Background Darker** | Executive Midnight Navy | `#070d18` | Base background & code editors |
| **Background Surface** | Slate Navy | `#0f172a` | App body background |
| **Card Surface** | Corporate Blue-Slate | `#182235` | Content boxes, questions, drives |
| **Primary Action** | Electric Cobalt Blue | `#2563eb` | Primary CTA buttons, focus states, brand icon |
| **Cyan Accent** | Neon Cyan | `#06b6d4` | Subtitles, ticker badges, active meters |
| **Success / Offers** | Emerald Mint | `#10b981` | Eligible badges, placed status, high ATS scores |
| **Prestige / Packages** | Amber Gold | `#f59e0b` | Super Dream CTC, SIH prizes, star pins |
| **Innovation Accent** | Electric Purple | `#8b5cf6` | Hackathons, capstone projects |

---

## 🚀 Quickstart & Setup

### Prerequisites
- **Node.js** (v16.0 or higher recommended, tested on Node v24).
- **Zero External Dependencies Required**: The server uses native Node.js standard libraries (`http`, `fs`, `path`, `url`), eliminating any npm installation or permission issues.

### 1. Launching on Windows
Double-click `start.bat` or run in PowerShell / Command Prompt:
```powershell
node backend/server.js
```
Open your browser and navigate to:
```
http://localhost:5000
```

### 2. Launching on macOS / Linux
```bash
chmod +x start.sh
./start.sh
```

---

## 📁 Project Structure

```
placement-portal-4th-year/
├── backend/
│   ├── data/
│   │   ├── initialData.js      # Rich 4th-year placement dataset
│   │   └── database.json       # Persistent JSON storage with auto-recovery
│   ├── models/
│   │   └── db.js               # Database manager and query helpers
│   ├── routes/
│   │   ├── announcementsRoutes.js
│   │   ├── applicationsRoutes.js
│   │   ├── drivesRoutes.js
│   │   ├── hackathonsRoutes.js
│   │   ├── mockTestRoutes.js
│   │   ├── profileRoutes.js
│   │   ├── projectsRoutes.js
│   │   ├── questionsRoutes.js
│   │   ├── skillsRoutes.js
│   │   └── statsRoutes.js
│   └── server.js               # Zero-dependency HTTP REST API & static server
├── frontend/
│   └── public/
│       ├── css/
│       │   └── style.css       # Career-focused palette, glassmorphism, responsive grid
│       ├── js/
│       │   ├── api.js          # REST API client
│       │   └── app.js          # Interactive SPA controller & quiz runner
│       └── index.html          # Semantic responsive HTML5 single-page application
├── package.json                # Project manifest and scripts
├── start.bat                   # One-click Windows launcher
├── start.sh                    # One-click Unix launcher
└── README.md                   # Complete documentation
```

---

## 📡 REST API Endpoints Overview

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Service health status and timestamp |
| `GET` | `/api/profile` | Student profile, CGPA, backlogs & metrics |
| `PUT` | `/api/profile` | Update profile information |
| `POST` | `/api/profile/calculate-ats` | Run automated ATS resume score analysis |
| `GET` | `/api/profile/portfolio` | Standalone recruiter portfolio view data |
| `GET` | `/api/questions` | Filter interview questions by company & topic |
| `POST` | `/api/questions/:id/toggle-solve` | Toggle question mastered status |
| `GET` | `/api/drives` | Campus drives with automated qualification status |
| `GET` | `/api/drives/eligibility-matrix` | Company-by-company student eligibility comparison |
| `POST` | `/api/drives/:id/apply` | 1-click apply with eligibility validation |
| `GET` | `/api/projects` | 4th-year student project showcase list |
| `POST` | `/api/projects` | Add a new project with tech stack & metrics |
| `POST` | `/api/projects/:id/toggle-featured` | Pin/unpin project on resume |
| `DELETE` | `/api/projects/:id` | Delete project from portfolio |
| `GET` | `/api/skills` | Categorized skill matrices & benchmarks |
| `GET` | `/api/skills/gap-analysis?company=Google` | Company-specific skill gap analysis |
| `GET` | `/api/hackathons` | National hackathons & teammate board |
| `POST` | `/api/hackathons/:id/register` | Register team for hackathon |
| `POST` | `/api/hackathons/find-teammates` | Post teammate request on campus board |
| `GET` | `/api/applications` | Pipeline Kanban tracking stages |
| `GET` | `/api/announcements` | Verified TPO placement notices |
| `GET` | `/api/stats` | Batch placement statistics & insights |
| `GET` | `/api/mock-tests` | Available online assessment mock tests |
| `POST` | `/api/mock-tests/:id/submit` | Submit answers for auto-grading & explanations |
| `POST` | `/api/reset` | Reset database to pristine 4th-year state |

---

## 🎓 Designed For Class of 2026
Built to empower final-year engineering students with all necessary resources to navigate campus placements, crack high-paying dream offers, and launch successful engineering careers!
