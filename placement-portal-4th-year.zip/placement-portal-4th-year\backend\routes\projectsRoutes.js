const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET all student projects
router.get('/', (req, res) => {
  try {
    const projects = db.getProjects();
    res.json({ success: true, data: projects });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST create new project
router.post('/', (req, res) => {
  try {
    const { title, category, tagline, technologies, problemStatement, solution, metrics, githubUrl, liveDemoUrl, role } = req.body;
    if (!title || !technologies) {
      return res.status(400).json({ success: false, error: "Title and technologies are required." });
    }

    const techArray = Array.isArray(technologies) 
      ? technologies 
      : technologies.split(',').map(t => t.trim()).filter(Boolean);

    const created = db.addProject({
      title,
      category: category || "Independent Engineering Project",
      tagline: tagline || "Engineered scalable solution solving real-world challenge.",
      technologies: techArray,
      problemStatement: problemStatement || "High latency and lack of centralized architecture.",
      solution: solution || "Built full-stack microservices architecture.",
      metrics: metrics || "Optimized response time by 45%.",
      githubUrl: githubUrl || "https://github.com",
      liveDemoUrl: liveDemoUrl || "",
      role: role || "Lead Developer",
      teamSize: Number(req.body.teamSize) || 1,
      featured: Boolean(req.body.featured)
    });

    res.status(201).json({ success: true, data: created, message: "Project successfully added to your showcase!" });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT update project
router.put('/:id', (req, res) => {
  try {
    const updated = db.updateProject(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, error: "Project not found" });
    }
    res.json({ success: true, data: updated, message: "Project updated." });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST toggle featured / pinned status
router.post('/:id/toggle-featured', (req, res) => {
  try {
    const projects = db.getProjects();
    const proj = projects.find(p => p.id === req.params.id);
    if (!proj) {
      return res.status(404).json({ success: false, error: "Project not found" });
    }
    proj.featured = !proj.featured;
    db.persist();
    res.json({
      success: true,
      data: proj,
      message: proj.featured ? "Pinned to Resume & Featured Portfolio" : "Unpinned from Featured"
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE project
router.delete('/:id', (req, res) => {
  try {
    const deleted = db.deleteProject(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, error: "Project not found" });
    }
    res.json({ success: true, message: "Project deleted from portfolio." });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
