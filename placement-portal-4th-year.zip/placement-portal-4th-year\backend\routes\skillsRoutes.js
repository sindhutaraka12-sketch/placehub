const express = require('express');
const router = express.Router();
const db = require('../models/db');

// GET skills and dream company matches
router.get('/', (req, res) => {
  try {
    const skills = db.getSkills();
    res.json({ success: true, data: skills });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST add new skill
router.post('/', (req, res) => {
  try {
    const { category, name, level, proficiency } = req.body;
    if (!category || !name) {
      return res.status(400).json({ success: false, error: "Category and skill name are required." });
    }

    const updatedCategory = db.addSkill(category, {
      name,
      level: level || "Intermediate",
      proficiency: Number(proficiency) || 80
    });

    if (!updatedCategory) {
      return res.status(404).json({ success: false, error: `Category '${category}' not found.` });
    }

    res.status(201).json({
      success: true,
      data: updatedCategory,
      message: `Added '${name}' under ${category}.`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET skill gap analysis for a target company
router.get('/gap-analysis', (req, res) => {
  try {
    const company = req.query.company || "Google";
    const skills = db.getSkills();
    const benchmark = skills.dreamCompanyBenchmarks[company] || {
      match: 85,
      missing: ["High-scale distributed systems", "Advanced tree algorithms"]
    };

    res.json({
      success: true,
      targetCompany: company,
      matchPercentage: benchmark.match,
      missingSkills: benchmark.missing,
      recommendations: [
        `Complete 5 Hard problems on ${benchmark.missing[0] || 'System Design'}.`,
        `Review past interview experiences for ${company} in the Interview Questions tab.`,
        `Take the timed Mock Assessment to test OA readiness.`
      ]
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
